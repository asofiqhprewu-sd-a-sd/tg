from __future__ import annotations

import asyncio
import logging
import subprocess
import sys
from pathlib import Path

# Auto-delegate to project .venv if run with global system Python
try:
    import aiogram  # noqa: F401
    import telethon  # noqa: F401
except ImportError:
    venv_py = Path(__file__).resolve().parent / ".venv" / "Scripts" / "python.exe"
    if venv_py.exists() and Path(sys.executable).resolve() != venv_py.resolve():
        raise SystemExit(subprocess.call([str(venv_py), "-u", __file__, *sys.argv[1:]]))
    raise

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramNetworkError, TelegramUnauthorizedError
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from aiohttp import web

from app.bot.context import AppContext
from app.bot.handlers import admin, assistant, common, inbox
from app.bot.middlewares import CallbackBanMiddleware, TopicTrackingMiddleware
from app.bot.telethon_bot import (
    TelethonBotShim,
    build_telethon_client,
    configure_telethon_commands,
    register_telethon_handlers,
)
from app.config import StaticConfig
from app.db import Database
from app.llm.client import OpenAICompatibleClient
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient, get_windows_system_proxy
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService
from app.web.server import create_web_app

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("bot")


async def _run_aiogram_loop(bot: Bot, dp: Dispatcher, ctx: AppContext) -> None:
    """Connect to Telegram Bot API via aiogram and poll, retrying gracefully on network drops."""
    while True:
        try:
            me = await bot.get_me(request_timeout=12)
            ctx.bot_username = me.username or ""
            ctx.bot_id = me.id
            logger.info("Connected to Telegram (aiogram) as @%s (id=%s)", ctx.bot_username, ctx.bot_id)

            try:
                await bot.set_my_commands(
                    [
                        BotCommand(command="start", description="Выбор языка (RU/EN) и старт"),
                        BotCommand(command="setup", description="Создать/проверить ветку Входящие"),
                        BotCommand(command="admin", description="Панель администратора"),
                        BotCommand(command="set_system", description="Задать системный промпт"),
                        BotCommand(command="topics", description="Список веток группы"),
                        BotCommand(command="find", description="Поиск по базе знаний"),
                        BotCommand(command="ask", description="Спросить ИИ в ветке"),
                        BotCommand(command="search", description="Поиск в интернете + ответ ИИ"),
                        BotCommand(command="digest", description="Дайджест ветки или всей группы (/digest all)"),
                        BotCommand(command="compare", description="Сравнить 2 ссылки / репозитория"),
                        BotCommand(command="index", description="Навигатор по веткам"),
                        BotCommand(command="export", description="Экспорт базы знаний (.md)"),
                        BotCommand(command="test_net", description="Проверить интернет из песочницы"),
                        BotCommand(command="ban", description="Заблокировать пользователя"),
                        BotCommand(command="tempban", description="Временный бан пользователя"),
                        BotCommand(command="unban", description="Разблокировать пользователя"),
                        BotCommand(command="bans", description="Список блокировок"),
                    ]
                )
            except Exception as exc:
                logger.warning("Could not set bot commands: %s", exc)

            await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
            return
        except TelegramUnauthorizedError:
            logger.error("Telegram отверг BOT_TOKEN (401 Unauthorized). Проверьте токен в .env.")
            return
        except (TelegramNetworkError, OSError) as exc:
            logger.warning(
                "Telegram API недоступен (%s). Web-админка продолжает работать локально; "
                "повтор подключения через 15с...",
                exc,
            )
            await asyncio.sleep(15)
        except Exception as exc:
            logger.warning(
                "Ошибка подключения к Telegram (%s: %s). Повтор через 15с...",
                type(exc).__name__,
                exc,
            )
            await asyncio.sleep(15)


async def _run_telethon_loop(cfg: StaticConfig, ctx: AppContext, bot_shim: TelethonBotShim) -> None:
    """Connect to Telegram via Telethon MTProto (supports tg-ws-proxy) and handle updates."""
    if not cfg.telegram_api_id or not cfg.telegram_api_hash:
        logger.error(
            "Для запуска Telethon через MTProto / tg-ws-proxy укажите TELEGRAM_API_ID и TELEGRAM_API_HASH "
            "в .env (получить бесплатно на https://my.telegram.org -> API development tools). "
            "Web-админка остаётся доступной локально."
        )
        await asyncio.Event().wait()
        return

    client = bot_shim.client
    register_telethon_handlers(client, bot_shim, ctx)

    while True:
        try:
            await client.start(bot_token=cfg.bot_token)
            me = await client.get_me()
            ctx.bot_username = getattr(me, "username", "") or ""
            ctx.bot_id = int(getattr(me, "id", 0) or 0)
            logger.info("Connected to Telegram (Telethon MTProto) as @%s (id=%s)", ctx.bot_username, ctx.bot_id)
            await configure_telethon_commands(client)
            await client.run_until_disconnected()
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning(
                "Ошибка MTProto-подключения Telethon (%s: %s). Повтор через 15с...",
                type(exc).__name__,
                exc,
            )
            try:
                await client.disconnect()
            except Exception:
                pass
            await asyncio.sleep(15)


def _select_transport(cfg: StaticConfig) -> str:
    if cfg.telegram_transport in {"telethon", "aiogram"}:
        return cfg.telegram_transport
    if cfg.telegram_api_id and cfg.telegram_api_hash:
        return "telethon"
    return "aiogram"


async def main() -> None:
    cfg = StaticConfig.from_env()
    if not cfg.bot_token or "replace-with" in cfg.bot_token:
        logger.error("BOT_TOKEN is not configured. Copy .env.example to .env and set BOT_TOKEN.")
        sys.exit(1)

    db = Database(cfg.db_path)
    await db.connect(cfg)

    http = SandboxHttpClient(
        timeout_seconds=cfg.sandbox_timeout_seconds,
        max_download_bytes=cfg.sandbox_max_download_bytes,
    )
    repos = RepoInspector(http, github_token=cfg.github_token)
    files = FileSandbox(cfg.sandbox_work_dir, max_file_bytes=cfg.sandbox_max_download_bytes)
    llm = OpenAICompatibleClient()
    analyzer = InboxAnalyzer(
        http_client=http,
        repo_inspector=repos,
        file_sandbox=files,
        llm_client=llm,
    )
    router_svc = TopicRouterService(db)
    assistant_svc = AssistantService(db=db, llm=llm, http=http, repos=repos)

    ctx = AppContext(
        static_cfg=cfg,
        db=db,
        llm=llm,
        http=http,
        repos=repos,
        files=files,
        analyzer=analyzer,
        router_svc=router_svc,
        assistant=assistant_svc,
    )

    transport = _select_transport(cfg)
    logger.info("Selected Telegram transport: %s", transport)

    web_runner: web.AppRunner | None = None
    aiogram_bot: Bot | None = None
    telethon_shim: TelethonBotShim | None = None

    try:
        if transport == "telethon":
            tl_client = build_telethon_client(cfg)
            telethon_shim = TelethonBotShim(tl_client)
            web_bot_ref: Any = telethon_shim
        else:
            tg_proxy = cfg.telegram_proxy_url or get_windows_system_proxy() or None
            if tg_proxy:
                logger.info("Using Telegram HTTP/SOCKS proxy: %s", tg_proxy)
            session = AiohttpSession(proxy=tg_proxy)
            aiogram_bot = Bot(
                token=cfg.bot_token,
                session=session,
                default=DefaultBotProperties(parse_mode=ParseMode.HTML),
            )
            web_bot_ref = aiogram_bot

        if cfg.web_admin_enabled:
            settings = await db.get_settings()
            if not settings.admin_domain or not settings.admin_path:
                domain, path, token = await db.rotate_admin_site_access()
            else:
                domain, path, token = settings.admin_domain, settings.admin_path, settings.web_admin_token
            web_app = create_web_app(ctx, web_bot_ref)
            web_runner = web.AppRunner(web_app)
            await web_runner.setup()
            site = web.TCPSite(web_runner, host=cfg.web_admin_host, port=cfg.web_admin_port)
            await site.start()
            if cfg.web_admin_host == "127.0.0.1":
                try:
                    site_v6 = web.TCPSite(web_runner, host="::1", port=cfg.web_admin_port)
                    await site_v6.start()
                except OSError:
                    pass
            logger.info(
                "Admin Grant Site running at http://%s:%s%s/?token=%s",
                domain,
                cfg.web_admin_port,
                path,
                token,
            )

        if transport == "telethon":
            assert telethon_shim is not None
            await _run_telethon_loop(cfg, ctx, telethon_shim)
        else:
            assert aiogram_bot is not None
            dp = Dispatcher(storage=MemoryStorage())
            dp["ctx"] = ctx
            dp.message.outer_middleware(TopicTrackingMiddleware(ctx))
            dp.callback_query.outer_middleware(CallbackBanMiddleware(ctx))
            dp.include_router(admin.router)
            dp.include_router(common.router)
            dp.include_router(assistant.router)
            dp.include_router(inbox.router)
            await _run_aiogram_loop(aiogram_bot, dp, ctx)
    finally:
        if web_runner is not None:
            await web_runner.cleanup()
        if aiogram_bot is not None:
            await aiogram_bot.session.close()
        if telethon_shim is not None:
            try:
                await telethon_shim.client.disconnect()
            except Exception:
                pass
        await db.close()


if __name__ == "__main__":
    if sys.platform == "win32" and hasattr(asyncio, "WindowsSelectorEventLoopPolicy"):
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
