from __future__ import annotations

import io
import zipfile
from pathlib import Path

from app.sandbox.files import FileSandbox


def test_file_sandbox_inspects_code_and_cleans_workdir(tmp_path: Path):
    work = tmp_path / "sandbox"
    sb = FileSandbox(work)
    res = sb.inspect_bytes("hello.py", b"def greet():\n    return 'hi'\n")
    assert res.kind == "text"
    assert "def greet" in res.extracted_text
    assert res.error == ""
    assert len(res.sha256) == 64
    # Sandbox work directory must have zero leftover task folders
    assert list(work.iterdir()) == []


def test_file_sandbox_inspects_zip_and_blocks_zipslip(tmp_path: Path):
    work = tmp_path / "sandbox"
    sb = FileSandbox(work)

    good_buf = io.BytesIO()
    with zipfile.ZipFile(good_buf, "w") as zf:
        zf.writestr("README.md", "# Demo Project\nUseful tool.")
        zf.writestr("src/app.py", "print('ok')")

    good_res = sb.inspect_bytes("project.zip", good_buf.getvalue())
    assert good_res.kind == "zip"
    assert "Demo Project" in good_res.extracted_text
    assert "src/app.py" in good_res.extracted_text
    assert list(work.iterdir()) == []

    evil_buf = io.BytesIO()
    with zipfile.ZipFile(evil_buf, "w") as zf:
        zf.writestr("../../outside.txt", "pwned")

    evil_res = sb.inspect_bytes("evil.zip", evil_buf.getvalue())
    assert "ZipSlip" in evil_res.error
    assert list(work.iterdir()) == []


def test_file_sandbox_reads_docx(tmp_path: Path):
    sb = FileSandbox(tmp_path / "sandbox")
    buf = io.BytesIO()
    xml_doc = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        "<w:body><w:p><w:r><w:t>Architecture Spec</w:t></w:r></w:p></w:body>"
        "</w:document>"
    )
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("word/document.xml", xml_doc)

    res = sb.inspect_bytes("spec.docx", buf.getvalue())
    assert res.kind == "docx"
    assert "Architecture Spec" in res.extracted_text
