from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.bot.keyboards import digest_publish_keyboard, routed_item_keyboard
from app.config import RuntimeSettings, StaticConfig
from app.db import Database
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient, normalize_url
from app.sandbox.youtube import YouTubeInspector, extract_youtube_video_id, parse_caption_xml
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService


def test_youtube_id_and_canonical_dedup():
    assert extract_youtube_video_id("https://youtu.be/dQw4w9WgXcQ?t=15") == "dQw4w9WgXcQ"
    assert extract_youtube_video_id("https://www.youtube.com/watch?v=dQw4w9WgXcQ&si=xyz") == "dQw4w9WgXcQ"
    assert extract_youtube_video_id("https://youtube.com/shorts/dQw4w9WgXcQ") == "dQw4w9WgXcQ"
    assert extract_youtube_video_id("https://example.com/watch?v=123") is None

    u1 = normalize_url("https://youtu.be/dQw4w9WgXcQ?si=123")
    u2 = normalize_url("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=99s")
    u3 = normalize_url("https://youtube.com/shorts/dQw4w9WgXcQ")
    assert u1 == u2 == u3 == "https://youtube.com/watch?v=dQw4w9WgXcQ"


def test_parse_caption_xml():
    xml = '<transcript><text start="0" dur="2">Привет &amp; добро пожаловать</text><text start="2" dur="2">в разбор архитектуры.</text></transcript>'
    assert parse_caption_xml(xml) == "Привет & добро пожаловать в разбор архитектуры."


class _FakeYouTubeHttp(SandboxHttpClient):
    async def fetch_raw(self, url: str, settings: RuntimeSettings, **kwargs):
        if "youtube.com/watch" in url:
            player = {
                "videoDetails": {
                    "title": "Microservices Patterns",
                    "author": "TechChannel",
                    "shortDescription": "Deep dive into event-driven architecture.",
                    "lengthSeconds": "615",
                    "viewCount": "120000",
                },
                "captions": {
                    "playerCaptionsTracklistRenderer": {
                        "captionTracks": [
                            {"languageCode": "en", "kind": "asr", "baseUrl": "https://www.youtube.com/api/timedtext?lang=en"},
                            {"languageCode": "ru", "baseUrl": "https://www.youtube.com/api/timedtext?lang=ru"},
                        ]
                    }
                },
            }
            html_body = f"<html><script>var ytInitialPlayerResponse = {json.dumps(player)};</script></html>"
            return url, 200, {"content-type": "text/html"}, html_body.encode("utf-8")
        if "timedtext?lang=ru" in url:
            xml = '<transcript><text start="0">Сегодня разберём брокеры сообщений и Kafka.</text></transcript>'
            return url, 200, {"content-type": "text/xml"}, xml.encode("utf-8")
        return url, 200, {"content-type": "text/html"}, b"<html><title>Page</title><body><p>Body text</p></body></html>"


class _StubChatLLM:
    def __init__(self) -> None:
        self.last_messages: list[dict] = []

    async def chat(self, settings, messages, **kwargs):
        self.last_messages = messages
        return "Generated AI response"

    async def complete_json(self, settings, messages, **kwargs):
        self.last_messages = messages
        return {
            "title": "Microservices Talk",
            "summary": "Video about Kafka & event-driven systems.",
            "why_needed": "Useful for our backend architecture.",
            "target_thread_id": None,
            "target_topic_name": "⚙️ Backend",
            "create_new_topic": True,
            "tags": ["kafka", "architecture"],
        }


@pytest.mark.asyncio
async def test_youtube_inspector_and_bonus_services(tmp_path: Path):
    http = _FakeYouTubeHttp()
    yt = YouTubeInspector(http)
    settings = RuntimeSettings(openai_api_key="sk-test")

    res = await yt.inspect("https://youtu.be/dQw4w9WgXcQ", settings)
    assert res is not None
    assert res.title == "Microservices Patterns"
    assert res.author == "TechChannel"
    assert res.transcript_lang == "ru"
    assert "Kafka" in res.transcript

    analyzer = InboxAnalyzer(
        http_client=http,
        repo_inspector=RepoInspector(http),
        file_sandbox=FileSandbox(tmp_path / "sb"),
        llm_client=_StubChatLLM(),  # type: ignore[arg-type]
        youtube_inspector=yt,
    )
    payload = await analyzer.extract_payload(text="Посмотрите https://youtu.be/dQw4w9WgXcQ", settings=settings)
    assert payload.item_kind == "video"
    assert "Kafka" in payload.context_text

    # Test cross-topic KB search in /ask, spec, review, compare, and group digest
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids={1},
        openai_api_key="sk-test",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "bonus.db",
        sandbox_work_dir=tmp_path / "sb2",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="tok",
    )
    db = Database(cfg.db_path)
    await db.connect(cfg)
    try:
        llm = _StubChatLLM()
        assistant = AssistantService(db=db, llm=llm, http=http, repos=RepoInspector(http), youtube=yt)  # type: ignore[arg-type]
        item = await db.save_routed_item(
            chat_id=-1001,
            source_message_id=10,
            source_thread_id=5,
            target_thread_id=55,
            target_message_id=100,
            target_topic_name="⚙️ Backend",
            author_id=1,
            author_name="Alice",
            item_kind="video",
            title="Kafka Architecture Video",
            url="https://youtu.be/dQw4w9WgXcQ",
            normalized_url="https://youtube.com/watch?v=dQw4w9WgXcQ",
            file_hash="",
            summary="Talk about Kafka brokers.",
            why_needed="Helps scale async workers.",
            tags=["kafka"],
        )

        # Cross-topic /ask from a DIFFERENT thread_id=99 still finds Kafka item from thread_id=55!
        ans = await assistant.answer_question(
            chat_id=-1001,
            thread_id=99,
            user_name="Bob",
            question="Что у нас есть про Kafka?",
            settings=settings,
            lang="ru",
        )
        assert ans == "Generated AI response"
        assert "Kafka Architecture Video" in llm.last_messages[-1]["content"]

        # Spec & Review generation
        spec = await assistant.generate_item_spec(item, settings, lang="ru")
        assert spec == "Generated AI response"
        assert "Kafka Architecture Video" in llm.last_messages[-1]["content"]

        review = await assistant.generate_item_review(item, settings, lang="ru")
        assert review == "Generated AI response"

        # Compare two URLs
        cmp_res = await assistant.compare_urls("https://youtu.be/dQw4w9WgXcQ", "https://example.org/a", settings, lang="ru")
        assert cmp_res == "Generated AI response"
        assert "Microservices Patterns" in llm.last_messages[-1]["content"]

        # Group-wide digest + ensure_named_topic ("📢 Дайджесты")
        dig = await assistant.build_digest(chat_id=-1001, thread_id=0, settings=settings, lang="ru", group_wide=True)
        assert dig == "Generated AI response"
        assert "Kafka Architecture Video" in llm.last_messages[-1]["content"]

        class _FakeBot:
            async def create_forum_topic(self, chat_id: int, name: str):
                return SimpleNamespace(message_thread_id=888, name=name)

        router = TopicRouterService(db)
        d_topic = await router.ensure_named_topic(_FakeBot(), -1001, "📢 Дайджесты")  # type: ignore[arg-type]
        assert d_topic.thread_id == 888
    finally:
        await db.close()

    kb = routed_item_keyboard(12, "ru")
    cb_data = [b.callback_data for row in kb.inline_keyboard for b in row]
    assert cb_data == ["item:spec:12", "item:review:12", "reroute:menu:12"]

    dkb = digest_publish_keyboard(55, "ru")
    assert dkb.inline_keyboard[0][0].callback_data == "digest:pub:55"
