from __future__ import annotations

import pytest

from app.config import RuntimeSettings
from app.sandbox.net import (
    SandboxAccessError,
    extract_urls,
    is_public_ip,
    normalize_url,
    parse_html_content,
    validate_url_target,
)


def test_extract_and_normalize_urls():
    text = "Глянь сюда: https://www.Example.com/docs/intro/?utm_source=tg&fbclid=1&keep=yes), а ещё http://github.com/tiangolo/fastapi."
    urls = extract_urls(text)
    assert urls == [
        "https://www.Example.com/docs/intro/?utm_source=tg&fbclid=1&keep=yes",
        "http://github.com/tiangolo/fastapi",
    ]
    assert normalize_url(urls[0]) == "https://example.com/docs/intro?keep=yes"


def test_public_ip_checks():
    assert is_public_ip("8.8.8.8") is True
    assert is_public_ip("1.1.1.1") is True
    assert is_public_ip("127.0.0.1") is False
    assert is_public_ip("10.0.0.5") is False
    assert is_public_ip("172.16.10.2") is False
    assert is_public_ip("192.168.1.1") is False
    assert is_public_ip("169.254.169.254") is False
    assert is_public_ip("::1") is False


@pytest.mark.asyncio
async def test_validate_url_blocks_ssrf_and_policies():
    settings = RuntimeSettings(sandbox_internet_enabled=True)

    with pytest.raises(SandboxAccessError):
        await validate_url_target("file:///etc/passwd", settings)

    with pytest.raises(SandboxAccessError):
        await validate_url_target("http://localhost:8080/secret", settings)

    with pytest.raises(SandboxAccessError):
        await validate_url_target("http://127.0.0.1:9000", settings)

    with pytest.raises(SandboxAccessError):
        await validate_url_target("http://169.254.169.254/latest/meta-data/", settings)

    disabled = RuntimeSettings(sandbox_internet_enabled=False)
    with pytest.raises(SandboxAccessError):
        await validate_url_target("https://8.8.8.8/", disabled)

    blocked = RuntimeSettings(sandbox_internet_enabled=True, sandbox_blocked_domains="evil.com")
    with pytest.raises(SandboxAccessError):
        await validate_url_target("https://sub.evil.com/path", blocked)

    allow_only = RuntimeSettings(sandbox_internet_enabled=True, sandbox_allowed_domains="github.com")
    with pytest.raises(SandboxAccessError):
        await validate_url_target("https://example.org/test", allow_only)


def test_parse_html_content():
    html = """
    <html>
      <head>
        <title>FastAPI Docs</title>
        <meta name="description" content="Modern Python web framework">
        <script>console.log("secret")</script>
      </head>
      <body>
        <main><h1>FastAPI</h1><p>FastAPI is fast and easy to use.</p></main>
      </body>
    </html>
    """
    title, desc, body = parse_html_content(html)
    assert title == "FastAPI Docs"
    assert desc == "Modern Python web framework"
    assert "FastAPI is fast" in body
    assert "console.log" not in body
