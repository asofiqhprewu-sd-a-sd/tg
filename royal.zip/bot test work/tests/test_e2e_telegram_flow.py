from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.bot.context import AppContext
from app.bot.handlers.admin import cmd_set_system, cmd_test_net
from app.bot.handlers.assistant import cmd_export, cmd_find, cmd_index, on_pin_index
from app.bot.handlers.common import cmd_setup
from app.bot.handlers.inbox import on_duplicate_force, on_inbox_message, on_reroute_callback
from app.config import StaticConfig
from app.db import Database
from app.llm.client import OpenAICompatibleClient, _strip_image_parts
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import FetchedWebPage, SandboxAccessError, SandboxHttpClient
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService


class _FakeE2EBot:
    def __init__(self) -> None:
        self.next_thread_id = 100
        self.next_msg_id = 1000
        self.created_topics: list[tuple[int, str, int]] = []
        self.sent_messages: list[dict] = []
        self.deleted_messages: list[tuple[int, int]] = []
        self.pinned_messages: list[tuple[int, int]] = []
        self.downloaded_files: list[bytes] = []

    async def get_chat_member(self, chat_id: int, user_id: int):
        return SimpleNamespace(status="administrator")

    async def create_forum_topic(self, chat_id: int, name: str):
        tid = self.next_thread_id
        self.next_thread_id += 100
        self.created_topics.append((chat_id, name, tid))
        return SimpleNamespace(message_thread_id=tid, name=name)

    async def send_message(self, chat_id: int, text: str, message_thread_id: int = 0, **kwargs):
        mid = self.next_msg_id
        self.next_msg_id += 1
        self.sent_messages.append(
            {"chat_id": chat_id, "thread_id": message_thread_id, "message_id": mid, "text": text, **kwargs}
        )
        return SimpleNamespace(message_id=mid)

    async def delete_message(self, chat_id: int, message_id: int):
        self.deleted_messages.append((chat_id, message_id))

    async def pin_chat_message(self, chat_id: int, message_id: int, disable_notification: bool = True):
        self.pinned_messages.append((chat_id, message_id))

    async def copy_message(self, **kwargs):
        return SimpleNamespace(message_id=9999)

    async def download(self, file_obj, destination):
        destination.write(b"\x89PNG\r\n\x1a\nfake-png-bytes")


class _StubSandboxHttp(SandboxHttpClient):
    async def fetch_raw(self, url: str, settings, **kwargs):
        if "127.0.0.1" in url:
            raise SandboxAccessError("Blocked loopback IP 127.0.0.1")
        if url.endswith("/zen"):
            return url, 200, {"content-type": "text/plain"}, b"Design for failure."
        if url.endswith("/repos/acme/router"):
            return url, 200, {}, json.dumps(
                {"description": "Fast router", "stargazers_count": 100, "language": "Python"}
            ).encode()
        return url, 404, {}, b""

    async def fetch_webpage(self, url: str, settings, **kwargs):
        if "127.0.0.1" in url:
            return FetchedWebPage(url=url, final_url=url, status=0, content_type="", error="Blocked")
        return FetchedWebPage(
            url=url,
            final_url=url,
            status=200,
            content_type="text/plain",
            title="GitHub Zen",
            text="Keep it logically awesome.",
        )


class _StubLLM(OpenAICompatibleClient):
    def __init__(self) -> None:
        super().__init__()
        self.calls: list[list[dict]] = []

    async def complete_json(self, settings, messages, **kwargs):
        self.calls.append(messages)
        user_msg = messages[-1]["content"]
        has_image = isinstance(user_msg, list)
        return {
            "title": "Screenshot Analysis" if has_image else "Acme Router Library",
            "summary": "Analyzed image content." if has_image else "Python async router for services.",
            "why_needed": "Speeds up backend API development.",
            "target_thread_id": None,
            "target_topic_name": "⚙️ Backend",
            "create_new_topic": True,
            "new_topic_description": "Backend tools and libraries",
            "tags": ["python", "backend"],
        }


class _FakeTelegramMessage:
    def __init__(
        self,
        *,
        bot: _FakeE2EBot,
        chat_id: int,
        message_id: int,
        thread_id: int = 0,
        user_id: int = 1,
        text: str = "",
        photo=None,
    ) -> None:
        self.bot = bot
        self.chat = SimpleNamespace(id=chat_id, type="supergroup", title="Test Group", is_forum=True)
        self.message_id = message_id
        self.message_thread_id = thread_id
        self.from_user = SimpleNamespace(id=user_id, full_name="Tester", username="tester", is_bot=False)
        self.text = text
        self.caption = ""
        self.document = None
        self.photo = photo
        self.video = None
        self.audio = None
        self.voice = None
        self.forward_origin = None
        self.forum_topic_created = None
        self.forum_topic_edited = None
        self.forum_topic_closed = None
        self.forum_topic_reopened = None
        self.new_chat_members = None
        self.left_chat_member = None
        self.pinned_message = None
        self.reply_to_message = None
        self.replies: list[_FakeTelegramMessage] = []
        self.documents_sent: list[tuple[bytes, str]] = []
        self.edited_texts: list[str] = []
        self.edited_markups: list = []

    async def reply(self, text: str, **kwargs):
        m = _FakeTelegramMessage(
            bot=self.bot,
            chat_id=self.chat.id,
            message_id=self.message_id + 500 + len(self.replies),
            thread_id=self.message_thread_id,
            text=text,
        )
        m.last_kwargs = kwargs  # type: ignore[attr-defined]
        self.replies.append(m)
        return m

    async def edit_text(self, text: str, **kwargs):
        self.text = text
        self.edited_texts.append(text)
        return self

    async def edit_reply_markup(self, reply_markup=None):
        self.edited_markups.append(reply_markup)
        return self

    async def reply_document(self, document, caption: str = ""):
        self.documents_sent.append((document.data, document.filename))
        return self


@pytest.mark.asyncio
async def test_full_telegram_e2e_flow(tmp_path: Path):
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids={1},
        openai_api_key="sk-test",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "e2e.db",
        sandbox_work_dir=tmp_path / "sb",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=5 * 1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="tok",
    )
    db = Database(cfg.db_path)
    await db.connect(cfg)
    bot = _FakeE2EBot()
    http = _StubSandboxHttp()
    repos = RepoInspector(http)
    files = FileSandbox(cfg.sandbox_work_dir)
    llm = _StubLLM()
    ctx = AppContext(
        static_cfg=cfg,
        db=db,
        llm=llm,
        http=http,
        repos=repos,
        files=files,
        analyzer=InboxAnalyzer(http_client=http, repo_inspector=repos, file_sandbox=files, llm_client=llm),
        router_svc=TopicRouterService(db),
        assistant=AssistantService(db=db, llm=llm, http=http, repos=repos),
        bot_username="test_helper_bot",
        bot_id=999,
    )

    chat_id = -100555666
    try:
        # 1. /setup creates Inbox topic (thread_id=100)
        setup_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=1, text="/setup")
        await cmd_setup(setup_msg, ctx)  # type: ignore[arg-type]
        assert bot.created_topics[0][1] == "📥 Входящие"
        inbox_tid = bot.created_topics[0][2]

        # 2. Admin sets custom system prompt via /set_system
        sys_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=2, text="/set_system Будь кратким архитектором")
        await cmd_set_system(sys_msg, SimpleNamespace(args="Будь кратким архитектором"), ctx)  # type: ignore[arg-type]
        assert (await db.get_settings()).system_prompt == "Будь кратким архитектором"

        # 3. User drops a GitHub repo link into Inbox -> routed to new topic "⚙️ Backend"
        inbox_msg = _FakeTelegramMessage(
            bot=bot,
            chat_id=chat_id,
            message_id=10,
            thread_id=inbox_tid,
            text="Посмотрите https://github.com/acme/router",
        )
        await on_inbox_message(inbox_msg, ctx)  # type: ignore[arg-type]
        assert len(bot.created_topics) == 2
        assert bot.created_topics[1][1] == "⚙️ Backend"
        assert "Будь кратким архитектором" in llm.calls[-1][0]["content"]
        assert "Распределено в ветку" in inbox_msg.replies[0].edited_texts[-1]
        assert "Acme Router Library" in bot.sent_messages[-1]["text"]

        # 4. Duplicate URL with tracking param -> duplicate warning -> force override
        dup_msg = _FakeTelegramMessage(
            bot=bot,
            chat_id=chat_id,
            message_id=11,
            thread_id=inbox_tid,
            text="https://github.com/acme/router?utm_source=telegram",
        )
        await on_inbox_message(dup_msg, ctx)  # type: ignore[arg-type]
        assert "уже было" in dup_msg.replies[0].edited_texts[-1]

        force_cb = SimpleNamespace(
            data="inbox:force:11",
            message=dup_msg.replies[0],
            from_user=dup_msg.from_user,
            bot=bot,
            answer=lambda *a, **kw: _async_noop(),
        )
        await on_duplicate_force(force_cb, ctx)  # type: ignore[arg-type]
        assert "Распределено в ветку" in dup_msg.replies[0].edited_texts[-1]

        # 5. Re-route item to another topic
        await db.upsert_topic(chat_id, 777, "🤖 AI")
        items = await db.list_routed_items(chat_id)
        item_id = items[0].id
        card_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=items[0].target_message_id or 1005, thread_id=200)
        reroute_cb = SimpleNamespace(
            data=f"reroute:to:{item_id}:777",
            message=card_msg,
            from_user=inbox_msg.from_user,
            bot=bot,
            answer=lambda *a, **kw: _async_noop(),
        )
        await on_reroute_callback(reroute_cb, ctx)  # type: ignore[arg-type]
        updated_item = await db.get_routed_item(item_id)
        assert updated_item is not None and updated_item.target_thread_id == 777

        # 6. Vision photo in Inbox passes image_url multimodal payload + strip helper works
        photo_msg = _FakeTelegramMessage(
            bot=bot,
            chat_id=chat_id,
            message_id=12,
            thread_id=inbox_tid,
            photo=[SimpleNamespace(file_unique_id="img1", file_size=500)],
        )
        await on_inbox_message(photo_msg, ctx)  # type: ignore[arg-type]
        assert isinstance(llm.calls[-1][-1]["content"], list)
        stripped = _strip_image_parts(llm.calls[-1])
        assert isinstance(stripped[-1]["content"], str)

        # 7. /find, /index (+ pin), /export (.md file), /test_net inside Telegram
        find_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=20)
        await cmd_find(find_msg, SimpleNamespace(args="Router"), ctx)  # type: ignore[arg-type]
        assert "Acme Router Library" in find_msg.replies[0].text

        idx_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=21)
        await cmd_index(idx_msg, ctx)  # type: ignore[arg-type]
        assert "Навигатор по веткам" in idx_msg.replies[0].text
        pin_cb = SimpleNamespace(
            data="idx:pin",
            message=idx_msg.replies[0],
            from_user=idx_msg.from_user,
            bot=bot,
            answer=lambda *a, **kw: _async_noop(),
        )
        await on_pin_index(pin_cb, ctx)  # type: ignore[arg-type]
        assert (chat_id, idx_msg.replies[0].message_id) in bot.pinned_messages

        exp_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=22)
        await cmd_export(exp_msg, ctx)  # type: ignore[arg-type]
        assert exp_msg.documents_sent[0][1] == "knowledge_base.md"
        assert b"Acme Router Library" in exp_msg.documents_sent[0][0]

        net_msg = _FakeTelegramMessage(bot=bot, chat_id=chat_id, message_id=23)
        await cmd_test_net(net_msg, SimpleNamespace(args="https://api.github.com/zen"), ctx)  # type: ignore[arg-type]
        assert "Выход в интернет работает" in net_msg.replies[0].edited_texts[-1]
        assert "SSRF-защита работает" in net_msg.replies[0].edited_texts[-1]
    finally:
        await db.close()


async def _async_noop():
    return None
