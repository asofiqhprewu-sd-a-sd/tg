from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app.config import RuntimeSettings, StaticConfig
from app.db import Database
from app.i18n import t
from app.llm.client import extract_json_object
from app.models import TopicRecord
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient
from app.services.analyzer import ExtractedPayload, InboxAnalyzer
from app.services.router import TopicRouterService


def test_extract_json_object_variants():
    assert extract_json_object('{"a": 1}') == {"a": 1}
    assert extract_json_object('```json\n{"a": 2, "b": "ok"}\n```') == {"a": 2, "b": "ok"}
    assert extract_json_object('Here is result:\n{"target_topic_name": "Backend"}\nThanks!') == {
        "target_topic_name": "Backend"
    }


def test_i18n_ru_and_en():
    assert "Выберите язык" in t("ru", "choose_lang")
    assert "English" in t("en", "lang_updated")
    assert "Русский" in t("ru", "lang_updated")


class _StubLLM:
    def __init__(self, response: dict) -> None:
        self.response = response
        self.last_messages = []

    async def complete_json(self, settings, messages, **kwargs):
        self.last_messages = messages
        return self.response


@pytest.mark.asyncio
async def test_analyzer_matches_existing_topic_case_and_emoji_insensitive(tmp_path: Path):
    llm = _StubLLM(
        {
            "title": "PostgreSQL Tuning Guide",
            "summary": "Practical guide for database indexing.",
            "why_needed": "Helps optimize slow queries.",
            "target_thread_id": None,
            "target_topic_name": "Backend",
            "create_new_topic": True,
            "tags": ["postgres", "#sql"],
        }
    )
    http = SandboxHttpClient()
    analyzer = InboxAnalyzer(
        http_client=http,
        repo_inspector=RepoInspector(http),
        file_sandbox=FileSandbox(tmp_path),
        llm_client=llm,  # type: ignore[arg-type]
    )
    topics = [TopicRecord(id=1, chat_id=-1001, thread_id=55, name="⚙️ Backend")]
    payload = ExtractedPayload(item_kind="link", primary_url="https://pg.dev", normalized_url="https://pg.dev")

    decision = await analyzer.analyze_and_classify(
        payload=payload,
        author_name="Bob",
        existing_topics=topics,
        settings=RuntimeSettings(system_prompt="Custom prompt"),
        lang="en",
    )
    assert decision.target_thread_id == 55
    assert decision.target_topic_name == "⚙️ Backend"
    assert decision.create_new_topic is False
    assert decision.tags == ["postgres", "sql"]
    assert "Custom prompt" in llm.last_messages[0]["content"]
    assert "ENGLISH" in llm.last_messages[0]["content"]


class _FakeBot:
    def __init__(self) -> None:
        self.created_topics = []
        self.sent_messages = []

    async def create_forum_topic(self, chat_id: int, name: str):
        tid = 900 + len(self.created_topics)
        self.created_topics.append((chat_id, name, tid))
        return SimpleNamespace(message_thread_id=tid, name=name)

    async def send_message(self, chat_id: int, text: str, message_thread_id: int = 0, **kwargs):
        self.sent_messages.append((chat_id, message_thread_id, text))
        return SimpleNamespace(message_id=500 + len(self.sent_messages))


@pytest.mark.asyncio
async def test_router_ensure_inbox_topic_ru_and_en(tmp_path: Path):
    db = Database(tmp_path / "router.db")
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids=set(),
        openai_api_key="sk",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "router.db",
        sandbox_work_dir=tmp_path / "sb",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="tok",
    )
    await db.connect(cfg)
    try:
        router = TopicRouterService(db)
        bot = _FakeBot()
        res = await router.ensure_inbox_topic(bot, -100777, "Dev Group", await db.get_settings(), lang="en")  # type: ignore[arg-type]
        assert res.ok is True
        assert res.created is True
        assert res.topic is not None
        assert res.topic.name == "📥 Inbox"
        assert bot.created_topics[0][1] == "📥 Inbox"

        # Calling again returns existing without recreating
        res2 = await router.ensure_inbox_topic(bot, -100777, "Dev Group", await db.get_settings(), lang="en")  # type: ignore[arg-type]
        assert res2.created is False
        assert len(bot.created_topics) == 1
    finally:
        await db.close()
