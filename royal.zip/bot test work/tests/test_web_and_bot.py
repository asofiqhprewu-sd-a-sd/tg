from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
from aiohttp.test_utils import TestClient, TestServer

import run  # noqa: F401
from app.bot.context import AppContext, is_user_admin
from app.bot.handlers.common import cmd_start, on_language_selected
from app.config import StaticConfig
from app.db import Database
from app.llm.client import OpenAICompatibleClient
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService
from app.web.server import create_web_app


async def _build_ctx(tmp_path: Path) -> AppContext:
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids={42},
        openai_api_key="sk-test",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "webtest.db",
        sandbox_work_dir=tmp_path / "sb",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=2 * 1024 * 1024,
        web_admin_enabled=True,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="adm-tok-123",
    )
    db = Database(cfg.db_path)
    await db.connect(cfg)
    http = SandboxHttpClient()
    repos = RepoInspector(http)
    files = FileSandbox(cfg.sandbox_work_dir)
    llm = OpenAICompatibleClient()
    return AppContext(
        static_cfg=cfg,
        db=db,
        llm=llm,
        http=http,
        repos=repos,
        files=files,
        analyzer=InboxAnalyzer(http_client=http, repo_inspector=repos, file_sandbox=files, llm_client=llm),
        router_svc=TopicRouterService(db),
        assistant=AssistantService(db=db, llm=llm, http=http, repos=repos),
    )


@pytest.mark.asyncio
async def test_web_admin_grant_revoke_and_dynamic_domain(tmp_path: Path):
    ctx = await _build_ctx(tmp_path)
    await ctx.db.upsert_known_user(user_id=777, username="bob", full_name="Bob Tester", last_chat_id=-1001)
    app = create_web_app(ctx)

    try:
        async with TestClient(TestServer(app)) as client:
            # Unauthorized without token
            r_unauth = await client.get("/api/admins")
            assert r_unauth.status == 401

            headers = {"X-Admin-Token": "adm-tok-123"}
            r_list = await client.get("/api/admins", headers=headers)
            assert r_list.status == 200
            data = await r_list.json()
            assert any(u["user_id"] == 777 and not u["is_admin"] for u in data["users"])

            # Grant admin via toggle
            r_grant = await client.post(
                "/api/admins/toggle",
                headers=headers,
                json={"user_id": 777, "enabled": True, "username": "bob", "full_name": "Bob Tester"},
            )
            assert r_grant.status == 200
            assert await is_user_admin(SimpleNamespace(), 777, "private", 777, ctx.static_cfg, ctx.db) is True  # type: ignore[arg-type]

            # Revoke admin via toggle ("забирательство") — blocks even in groups
            r_revoke = await client.post(
                "/api/admins/toggle",
                headers=headers,
                json={"user_id": 777, "enabled": False},
            )
            assert r_revoke.status == 200

            class _GrpBot:
                async def get_chat_member(self, cid, uid):
                    return SimpleNamespace(status="administrator")

            assert await is_user_admin(_GrpBot(), -1001, "supergroup", 777, ctx.static_cfg, ctx.db) is False  # type: ignore[arg-type]

            # Rotate domain & path (simulating admin_generate.bat)
            domain1, path1, tok1 = await ctx.db.rotate_admin_site_access()
            domain2, path2, tok2 = await ctx.db.rotate_admin_site_access()
            assert domain1 != domain2
            assert path1 != path2
            assert tok1 != tok2
            assert domain2.endswith(".localhost")

            # Old Host (127.0.0.1) is now forbidden (403)
            r_old_host = await client.get(f"{path2}/api/admins", headers={"X-Admin-Token": tok2})
            assert r_old_host.status == 403

            # Matching new Host + wrong path -> 404
            r_bad_path = await client.get("/api/admins", headers={"Host": f"{domain2}:8080", "X-Admin-Token": tok2})
            assert r_bad_path.status == 404

            # Matching new Host + new path + query token -> 200 OK
            r_ok = await client.get(
                f"{path2}/api/admins?token={tok2}",
                headers={"Host": f"{domain2}:8080"},
            )
            assert r_ok.status == 200
    finally:
        await ctx.db.close()


@pytest.mark.asyncio
async def test_start_language_selection_flow(tmp_path: Path):
    ctx = await _build_ctx(tmp_path)
    try:
        replies = []

        class _FakeMsg:
            chat = SimpleNamespace(id=42, type="private", title="", is_forum=False)
            from_user = SimpleNamespace(id=42)

            async def reply(self, text, **kwargs):
                replies.append((text, kwargs))

            async def edit_text(self, text, **kwargs):
                replies.append((text, kwargs))

        msg = _FakeMsg()
        await cmd_start(msg, ctx)  # type: ignore[arg-type]
        assert len(replies) == 1
        kb = replies[0][1]["reply_markup"]
        buttons = [btn.callback_data for row in kb.inline_keyboard for btn in row]
        assert buttons == ["lang:set:ru", "lang:set:en"]

        class _FakeCb:
            data = "lang:set:en"
            message = msg
            from_user = SimpleNamespace(id=42)
            bot = SimpleNamespace()

            async def answer(self, text="", **kwargs):
                return None

        await on_language_selected(_FakeCb(), ctx)  # type: ignore[arg-type]
        assert await ctx.db.get_effective_language(42) == "en"
        assert "English (EN)" in replies[-1][0]
    finally:
        await ctx.db.close()
