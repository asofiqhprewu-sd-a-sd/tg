from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
from telethon.network.connection import ConnectionTcpMTProxyRandomizedIntermediate
from telethon.tl.types import MessageActionTopicCreate

from app.bot.context import AppContext
from app.bot.keyboards import language_select_keyboard
from app.bot.telethon_bot import (
    TelethonBotShim,
    build_telethon_client,
    extract_thread_id,
    markup_to_telethon_buttons,
    parse_command,
)
from app.config import StaticConfig
from app.db import Database
from app.llm.client import OpenAICompatibleClient
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService


def test_telethon_helpers():
    msg_topic = SimpleNamespace(reply_to=SimpleNamespace(forum_topic=True, reply_to_top_id=42, reply_to_msg_id=99))
    assert extract_thread_id(msg_topic) == 42

    msg_direct_reply = SimpleNamespace(reply_to=SimpleNamespace(forum_topic=True, reply_to_top_id=None, reply_to_msg_id=42))
    assert extract_thread_id(msg_direct_reply) == 42

    msg_general = SimpleNamespace(reply_to=SimpleNamespace(forum_topic=False, reply_to_msg_id=10))
    assert extract_thread_id(msg_general) == 0

    assert parse_command("/start", "my_bot") == ("start", "")
    assert parse_command("/ask@my_bot how?", "my_bot") == ("ask", "how?")
    assert parse_command("/ask@other_bot how?", "my_bot") is None

    btns = markup_to_telethon_buttons(language_select_keyboard())
    assert btns is not None and len(btns) == 1 and len(btns[0]) == 2
    assert btns[0][0].type.data == b"lang:set:ru"
    assert btns[0][1].type.data == b"lang:set:en"


def test_build_telethon_client_with_mtproto_proxy(tmp_path: Path):
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids=set(),
        openai_api_key="",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "b.db",
        sandbox_work_dir=tmp_path / "sb",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="tok",
        telegram_transport="telethon",
        telegram_api_id=12345,
        telegram_api_hash="0123456789abcdef0123456789abcdef",
        telethon_session_path=str(tmp_path / "tl.session"),
        mtproto_proxy_host="127.0.0.1",
        mtproto_proxy_port=1443,
        mtproto_proxy_secret="ddc6565bf98e8dbcf65187f5c3efa6c4c4",
    )
    client = build_telethon_client(cfg)
    assert client._connection is ConnectionTcpMTProxyRandomizedIntermediate
    assert client._proxy == ("127.0.0.1", 1443, "ddc6565bf98e8dbcf65187f5c3efa6c4c4")


class _FakeTelethonClient:
    def __init__(self) -> None:
        self.sent: list[dict] = []
        self.calls: list[object] = []

    async def get_input_entity(self, chat_id: int):
        return f"peer:{chat_id}"

    async def __call__(self, req):
        self.calls.append(req)
        name = type(req).__name__
        if name == "CreateForumTopicRequest":
            msg = SimpleNamespace(
                id=321,
                action=MessageActionTopicCreate(title=req.title, icon_color=0),
            )
            return SimpleNamespace(updates=[SimpleNamespace(message=msg)])
        if name == "GetForumTopicsRequest":
            return SimpleNamespace(
                topics=[
                    SimpleNamespace(id=50, title="⚙️ Backend", closed=False),
                    SimpleNamespace(id=10, title="📥 Входящие", closed=False),
                ]
            )
        return SimpleNamespace()

    async def send_message(self, chat_id, text, **kwargs):
        self.sent.append({"chat_id": chat_id, "text": text, **kwargs})
        return SimpleNamespace(id=700 + len(self.sent))


@pytest.mark.asyncio
async def test_telethon_shim_sync_and_ensure_inbox(tmp_path: Path):
    db = Database(tmp_path / "tl.db")
    cfg = StaticConfig(
        bot_token="123:test",
        admin_user_ids=set(),
        openai_api_key="",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "tl.db",
        sandbox_work_dir=tmp_path / "sb",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="tok",
    )
    await db.connect(cfg)
    try:
        fake_client = _FakeTelethonClient()
        shim = TelethonBotShim(fake_client)  # type: ignore[arg-type]
        http = SandboxHttpClient()
        repos = RepoInspector(http)
        files = FileSandbox(cfg.sandbox_work_dir)
        llm = OpenAICompatibleClient()
        ctx = AppContext(
            static_cfg=cfg,
            db=db,
            llm=llm,
            http=http,
            repos=repos,
            files=files,
            analyzer=InboxAnalyzer(http_client=http, repo_inspector=repos, file_sandbox=files, llm_client=llm),
            router_svc=TopicRouterService(db),
            assistant=AssistantService(db=db, llm=llm, http=http, repos=repos),
        )

        # Sync finds existing topics created before bot joined
        await db.upsert_chat(-100888, "TL Group", True)
        await shim.sync_forum_topics(-100888, ctx)
        topics = await db.list_topics(-100888, include_inbox=True)
        assert {tp.name for tp in topics} == {"⚙️ Backend", "📥 Входящие"}

        # Creating new topic via shim works cleanly
        created = await shim.create_forum_topic(-100888, "🤖 AI")
        assert created.message_thread_id == 321
        assert created.name == "🤖 AI"
    finally:
        await db.close()
