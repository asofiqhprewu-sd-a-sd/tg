from __future__ import annotations

from pathlib import Path

import pytest

from app.config import StaticConfig
from app.db import Database


def _make_static_cfg(tmp_path: Path) -> StaticConfig:
    return StaticConfig(
        bot_token="123:test",
        admin_user_ids={1},
        openai_api_key="sk-test",
        openai_base_url="https://api.openai.com/v1",
        openai_model="gpt-4o-mini",
        github_token="",
        inbox_topic_name="📥 Входящие",
        db_path=tmp_path / "test.db",
        sandbox_work_dir=tmp_path / "sandbox",
        sandbox_internet_enabled=True,
        sandbox_proxy_url="",
        sandbox_timeout_seconds=10,
        sandbox_max_download_bytes=5 * 1024 * 1024,
        web_admin_enabled=False,
        web_admin_host="127.0.0.1",
        web_admin_port=8080,
        web_admin_token="secret-token",
    )


@pytest.mark.asyncio
async def test_db_settings_topics_duplicates_and_fts(tmp_path: Path):
    db = Database(tmp_path / "test.db")
    await db.connect(_make_static_cfg(tmp_path))
    try:
        s = await db.get_settings()
        assert s.openai_model == "gpt-4o-mini"
        assert s.language == "ru"

        await db.update_settings({"system_prompt": "New prompt", "language": "en"})
        s2 = await db.get_settings()
        assert s2.system_prompt == "New prompt"
        assert s2.language == "en"

        await db.upsert_chat(-1001234567890, "Test Forum", True)
        await db.set_chat_language(-1001234567890, "ru")
        assert await db.get_effective_language(-1001234567890) == "ru"

        await db.upsert_topic(-1001234567890, 10, "📥 Входящие", is_inbox=True)
        await db.upsert_topic(-1001234567890, 20, "⚙️ Backend", description="Python & Go")

        item = await db.save_routed_item(
            chat_id=-1001234567890,
            source_message_id=101,
            source_thread_id=10,
            target_thread_id=20,
            target_message_id=202,
            target_topic_name="⚙️ Backend",
            author_id=77,
            author_name="Alice",
            item_kind="repo",
            title="FastAPI Web Framework",
            url="https://github.com/tiangolo/fastapi",
            normalized_url="https://github.com/tiangolo/fastapi",
            file_hash="",
            summary="Async Python API framework",
            why_needed="Great for REST microservices",
            tags=["python", "api"],
        )
        assert item.id > 0

        dup = await db.find_duplicate_item(-1001234567890, normalized_url="https://github.com/tiangolo/fastapi")
        assert dup is not None
        assert dup.id == item.id

        found = await db.search_items(-1001234567890, "FastAPI")
        assert len(found) == 1
        assert found[0].title == "FastAPI Web Framework"
    finally:
        await db.close()
