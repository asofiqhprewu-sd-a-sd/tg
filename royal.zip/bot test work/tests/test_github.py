from __future__ import annotations

import base64
import json

import pytest

from app.config import RuntimeSettings
from app.sandbox.github import RepoInspector, parse_repo_url


def test_parse_repo_url():
    assert parse_repo_url("https://github.com/tiangolo/fastapi") == ("github", "tiangolo/fastapi")
    assert parse_repo_url("https://github.com/tiangolo/fastapi.git") == ("github", "tiangolo/fastapi")
    assert parse_repo_url("https://github.com/tiangolo/fastapi/issues/123") is None
    assert parse_repo_url("https://gitlab.com/org/sub/service/-/tree/main") == ("gitlab", "org/sub/service")
    assert parse_repo_url("https://example.com/blog/post") is None


class _FakeHttp:
    async def fetch_raw(self, url: str, settings: RuntimeSettings, **kwargs):
        if url.endswith("/repos/acme/bot"):
            payload = {
                "description": "Telegram group bot",
                "stargazers_count": 42,
                "forks_count": 5,
                "language": "Python",
                "topics": ["telegram", "ai"],
                "license": {"spdx_id": "MIT"},
                "default_branch": "main",
            }
            return url, 200, {}, json.dumps(payload).encode()
        if url.endswith("/readme"):
            encoded = base64.b64encode(b"# Acme Bot\nRoutes inbox messages.").decode()
            return url, 200, {}, json.dumps({"encoding": "base64", "content": encoded}).encode()
        if url.endswith("/contents"):
            entries = [
                {"name": "README.md", "type": "file"},
                {"name": "pyproject.toml", "type": "file", "download_url": "https://raw.githubusercontent.com/acme/bot/main/pyproject.toml"},
            ]
            return url, 200, {}, json.dumps(entries).encode()
        if url.endswith("pyproject.toml"):
            return url, 200, {}, b'[project]\nname = "acme-bot"\n'
        return url, 404, {}, b""


@pytest.mark.asyncio
async def test_repo_inspector_github():
    inspector = RepoInspector(_FakeHttp())  # type: ignore[arg-type]
    res = await inspector.inspect("https://github.com/acme/bot", RuntimeSettings())
    assert res is not None
    assert res.full_name == "acme/bot"
    assert res.stars == 42
    assert res.language == "Python"
    assert "Routes inbox messages" in res.readme_text
    assert "acme-bot" in res.manifests_summary
