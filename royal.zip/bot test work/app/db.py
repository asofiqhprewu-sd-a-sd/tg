from __future__ import annotations

import json
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import aiosqlite

from app.config import DEFAULT_SYSTEM_PROMPT, RuntimeSettings, StaticConfig
from app.models import (
    BotAdminRecord,
    ChatRecord,
    KnownUserRecord,
    MessageRecord,
    RoutedItemRecord,
    TopicRecord,
    UserBanRecord,
)

SCHEMA_SQL = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chats (
    chat_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL DEFAULT '',
    is_forum INTEGER NOT NULL DEFAULT 0,
    inbox_thread_id INTEGER,
    system_prompt_override TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'ru',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    thread_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    system_prompt TEXT NOT NULL DEFAULT '',
    is_inbox INTEGER NOT NULL DEFAULT 0,
    is_closed INTEGER NOT NULL DEFAULT 0,
    created_by_bot INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(chat_id, thread_id)
);

CREATE TABLE IF NOT EXISTS routed_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    source_message_id INTEGER NOT NULL,
    source_thread_id INTEGER NOT NULL,
    target_thread_id INTEGER NOT NULL,
    target_message_id INTEGER,
    target_topic_name TEXT NOT NULL,
    author_id INTEGER NOT NULL,
    author_name TEXT NOT NULL,
    item_kind TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL DEFAULT '',
    normalized_url TEXT NOT NULL DEFAULT '',
    file_hash TEXT NOT NULL DEFAULT '',
    summary TEXT NOT NULL,
    why_needed TEXT NOT NULL DEFAULT '',
    tags_json TEXT NOT NULL DEFAULT '[]',
    raw_input TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_routed_chat_url ON routed_items(chat_id, normalized_url);
CREATE INDEX IF NOT EXISTS idx_routed_chat_hash ON routed_items(chat_id, file_hash);
CREATE INDEX IF NOT EXISTS idx_routed_chat_thread ON routed_items(chat_id, target_thread_id);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    thread_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    author_name TEXT NOT NULL,
    text TEXT NOT NULL,
    is_bot INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(chat_id, message_id)
);

CREATE INDEX IF NOT EXISTS idx_messages_topic ON messages(chat_id, thread_id, id DESC);

CREATE TABLE IF NOT EXISTS known_users (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL DEFAULT '',
    full_name TEXT NOT NULL DEFAULT '',
    last_chat_id INTEGER NOT NULL DEFAULT 0,
    last_seen_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bot_admins (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL DEFAULT '',
    full_name TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL DEFAULT 'granted',
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS user_bans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL DEFAULT 0,
    user_id INTEGER NOT NULL,
    author_name TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL DEFAULT '',
    banned_by INTEGER NOT NULL DEFAULT 0,
    expires_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_user_bans_lookup ON user_bans(user_id, chat_id);
"""

FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS routed_items_fts USING fts5(
    title,
    summary,
    why_needed,
    tags_text,
    url,
    content=''
);
"""


class Database:
    """Async SQLite repository for settings, chats, topics, knowledge items, and topic messages."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._conn: aiosqlite.Connection | None = None
        self._fts_enabled: bool = False

    async def connect(self, static_cfg: StaticConfig | None = None) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.db_path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(SCHEMA_SQL)
        # Safe forward migration for existing DBs
        async with self._conn.execute("PRAGMA table_info(chats)") as cur:
            cols = {row["name"] for row in await cur.fetchall()}
        if "language" not in cols:
            await self._conn.execute("ALTER TABLE chats ADD COLUMN language TEXT NOT NULL DEFAULT 'ru'")
        try:
            await self._conn.executescript(FTS_SQL)
            self._fts_enabled = True
        except aiosqlite.OperationalError:
            self._fts_enabled = False
        await self._conn.commit()
        if static_cfg is not None:
            await self._seed_settings(static_cfg)

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not connected")
        return self._conn

    async def _seed_settings(self, cfg: StaticConfig) -> None:
        defaults: dict[str, str] = {
            "system_prompt": DEFAULT_SYSTEM_PROMPT,
            "openai_api_key": cfg.openai_api_key,
            "openai_base_url": cfg.openai_base_url,
            "openai_model": cfg.openai_model,
            "openai_temperature": "0.3",
            "openai_max_tokens": "1500",
            "inbox_topic_name": cfg.inbox_topic_name,
            "language": "ru",
            "sandbox_internet_enabled": "1" if cfg.sandbox_internet_enabled else "0",
            "sandbox_proxy_url": cfg.sandbox_proxy_url,
            "sandbox_allowed_domains": "",
            "sandbox_blocked_domains": "",
            "auto_create_topics": "1",
            "delete_inbox_after_route": "0",
            "web_search_in_qa": "1",
            "web_admin_token": cfg.web_admin_token or secrets.token_urlsafe(20),
            "admin_domain": "",
            "admin_path": "",
        }
        for key, value in defaults.items():
            await self.conn.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value),
            )
        # If WEB_ADMIN_TOKEN is explicitly provided in env, keep it synced
        if cfg.web_admin_token:
            await self.conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                ("web_admin_token", cfg.web_admin_token),
            )
        await self.conn.commit()

    async def get_settings(self) -> RuntimeSettings:
        async with self.conn.execute("SELECT key, value FROM settings") as cur:
            rows = await cur.fetchall()
        data = {row["key"]: row["value"] for row in rows}
        return RuntimeSettings(
            system_prompt=data.get("system_prompt", DEFAULT_SYSTEM_PROMPT),
            openai_api_key=data.get("openai_api_key", ""),
            openai_base_url=data.get("openai_base_url", "https://api.openai.com/v1"),
            openai_model=data.get("openai_model", "gpt-4o-mini"),
            openai_temperature=float(data.get("openai_temperature", "0.3") or 0.3),
            openai_max_tokens=int(data.get("openai_max_tokens", "1500") or 1500),
            inbox_topic_name=data.get("inbox_topic_name", "📥 Входящие"),
            language=data.get("language", "ru"),
            sandbox_internet_enabled=data.get("sandbox_internet_enabled", "1") == "1",
            sandbox_proxy_url=data.get("sandbox_proxy_url", ""),
            sandbox_allowed_domains=data.get("sandbox_allowed_domains", ""),
            sandbox_blocked_domains=data.get("sandbox_blocked_domains", ""),
            auto_create_topics=data.get("auto_create_topics", "1") == "1",
            delete_inbox_after_route=data.get("delete_inbox_after_route", "0") == "1",
            web_search_in_qa=data.get("web_search_in_qa", "1") == "1",
            web_admin_token=data.get("web_admin_token", ""),
            admin_domain=data.get("admin_domain", ""),
            admin_path=data.get("admin_path", ""),
        )

    async def update_settings(self, updates: dict[str, Any]) -> RuntimeSettings:
        for key, value in updates.items():
            if isinstance(value, bool):
                serialized = "1" if value else "0"
            else:
                serialized = str(value)
            await self.conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                (key, serialized),
            )
        await self.conn.commit()
        return await self.get_settings()

    # --- Chats ---

    async def upsert_chat(self, chat_id: int, title: str, is_forum: bool) -> ChatRecord:
        await self.conn.execute(
            """
            INSERT INTO chats (chat_id, title, is_forum)
            VALUES (?, ?, ?)
            ON CONFLICT(chat_id) DO UPDATE SET
                title = excluded.title,
                is_forum = excluded.is_forum
            """,
            (chat_id, title, 1 if is_forum else 0),
        )
        await self.conn.commit()
        chat = await self.get_chat(chat_id)
        assert chat is not None
        return chat

    async def get_chat(self, chat_id: int) -> ChatRecord | None:
        async with self.conn.execute("SELECT * FROM chats WHERE chat_id = ?", (chat_id,)) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        return ChatRecord(
            chat_id=row["chat_id"],
            title=row["title"],
            is_forum=bool(row["is_forum"]),
            inbox_thread_id=row["inbox_thread_id"],
            system_prompt_override=row["system_prompt_override"],
            language=row["language"] or "ru",
            created_at=row["created_at"],
        )

    async def list_chats(self) -> list[ChatRecord]:
        async with self.conn.execute("SELECT * FROM chats ORDER BY created_at DESC") as cur:
            rows = await cur.fetchall()
        return [
            ChatRecord(
                chat_id=row["chat_id"],
                title=row["title"],
                is_forum=bool(row["is_forum"]),
                inbox_thread_id=row["inbox_thread_id"],
                system_prompt_override=row["system_prompt_override"],
                language=row["language"] or "ru",
                created_at=row["created_at"],
            )
            for row in rows
        ]

    async def set_chat_language(self, chat_id: int, language: str, title: str = "", is_forum: bool = False) -> None:
        lang = "en" if language == "en" else "ru"
        await self.conn.execute(
            """
            INSERT INTO chats (chat_id, title, is_forum, language)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(chat_id) DO UPDATE SET language = excluded.language
            """,
            (chat_id, title, 1 if is_forum else 0, lang),
        )
        await self.conn.commit()

    async def get_effective_language(self, chat_id: int | None = None) -> str:
        if chat_id is not None:
            chat = await self.get_chat(chat_id)
            if chat and chat.language in {"ru", "en"}:
                return chat.language
        settings = await self.get_settings()
        return settings.language if settings.language in {"ru", "en"} else "ru"

    async def set_chat_inbox_thread(self, chat_id: int, thread_id: int) -> None:
        await self.conn.execute(
            "UPDATE chats SET inbox_thread_id = ? WHERE chat_id = ?",
            (thread_id, chat_id),
        )
        await self.conn.commit()

    async def set_chat_system_prompt(self, chat_id: int, prompt: str) -> None:
        await self.conn.execute(
            "UPDATE chats SET system_prompt_override = ? WHERE chat_id = ?",
            (prompt, chat_id),
        )
        await self.conn.commit()

    # --- Topics ---

    async def upsert_topic(
        self,
        chat_id: int,
        thread_id: int,
        name: str,
        *,
        description: str | None = None,
        system_prompt: str | None = None,
        is_inbox: bool | None = None,
        is_closed: bool | None = None,
        created_by_bot: bool | None = None,
    ) -> TopicRecord:
        existing = await self.get_topic(chat_id, thread_id)
        if existing is None:
            await self.conn.execute(
                """
                INSERT INTO topics (
                    chat_id, thread_id, name, description, system_prompt,
                    is_inbox, is_closed, created_by_bot
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chat_id,
                    thread_id,
                    name,
                    description or "",
                    system_prompt or "",
                    1 if is_inbox else 0,
                    1 if is_closed else 0,
                    1 if created_by_bot else 0,
                ),
            )
        else:
            await self.conn.execute(
                """
                UPDATE topics SET
                    name = ?,
                    description = ?,
                    system_prompt = ?,
                    is_inbox = ?,
                    is_closed = ?,
                    created_by_bot = ?
                WHERE chat_id = ? AND thread_id = ?
                """,
                (
                    name if name else existing.name,
                    description if description is not None else existing.description,
                    system_prompt if system_prompt is not None else existing.system_prompt,
                    1 if (is_inbox if is_inbox is not None else existing.is_inbox) else 0,
                    1 if (is_closed if is_closed is not None else existing.is_closed) else 0,
                    1 if (created_by_bot if created_by_bot is not None else existing.created_by_bot) else 0,
                    chat_id,
                    thread_id,
                ),
            )
        await self.conn.commit()
        topic = await self.get_topic(chat_id, thread_id)
        assert topic is not None
        return topic

    async def get_topic(self, chat_id: int, thread_id: int) -> TopicRecord | None:
        async with self.conn.execute(
            "SELECT * FROM topics WHERE chat_id = ? AND thread_id = ?",
            (chat_id, thread_id),
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        return self._row_to_topic(row)

    async def find_topic_by_name(self, chat_id: int, name: str) -> TopicRecord | None:
        async with self.conn.execute(
            "SELECT * FROM topics WHERE chat_id = ? AND lower(trim(name)) = lower(trim(?))",
            (chat_id, name),
        ) as cur:
            row = await cur.fetchone()
        return self._row_to_topic(row) if row else None

    async def list_topics(self, chat_id: int, *, include_inbox: bool = True) -> list[TopicRecord]:
        if include_inbox:
            query = "SELECT * FROM topics WHERE chat_id = ? ORDER BY is_inbox DESC, id ASC"
        else:
            query = "SELECT * FROM topics WHERE chat_id = ? AND is_inbox = 0 ORDER BY id ASC"
        async with self.conn.execute(query, (chat_id,)) as cur:
            rows = await cur.fetchall()
        return [self._row_to_topic(r) for r in rows]

    async def update_topic_meta(
        self,
        chat_id: int,
        thread_id: int,
        *,
        name: str | None = None,
        description: str | None = None,
        system_prompt: str | None = None,
    ) -> TopicRecord | None:
        existing = await self.get_topic(chat_id, thread_id)
        if existing is None:
            return None
        await self.conn.execute(
            """
            UPDATE topics
            SET name = ?, description = ?, system_prompt = ?
            WHERE chat_id = ? AND thread_id = ?
            """,
            (
                name if name is not None else existing.name,
                description if description is not None else existing.description,
                system_prompt if system_prompt is not None else existing.system_prompt,
                chat_id,
                thread_id,
            ),
        )
        await self.conn.commit()
        return await self.get_topic(chat_id, thread_id)

    async def mark_topic_closed(self, chat_id: int, thread_id: int, is_closed: bool) -> None:
        await self.conn.execute(
            "UPDATE topics SET is_closed = ? WHERE chat_id = ? AND thread_id = ?",
            (1 if is_closed else 0, chat_id, thread_id),
        )
        await self.conn.commit()

    def _row_to_topic(self, row: aiosqlite.Row) -> TopicRecord:
        return TopicRecord(
            id=row["id"],
            chat_id=row["chat_id"],
            thread_id=row["thread_id"],
            name=row["name"],
            description=row["description"],
            system_prompt=row["system_prompt"],
            is_inbox=bool(row["is_inbox"]),
            is_closed=bool(row["is_closed"]),
            created_by_bot=bool(row["created_by_bot"]),
            created_at=row["created_at"],
        )

    # --- Routed Items / Knowledge Base ---

    async def save_routed_item(
        self,
        *,
        chat_id: int,
        source_message_id: int,
        source_thread_id: int,
        target_thread_id: int,
        target_message_id: int | None,
        target_topic_name: str,
        author_id: int,
        author_name: str,
        item_kind: str,
        title: str,
        url: str,
        normalized_url: str,
        file_hash: str,
        summary: str,
        why_needed: str,
        tags: list[str],
        raw_input: str = "",
    ) -> RoutedItemRecord:
        tags_json = json.dumps(tags, ensure_ascii=False)
        cur = await self.conn.execute(
            """
            INSERT INTO routed_items (
                chat_id, source_message_id, source_thread_id,
                target_thread_id, target_message_id, target_topic_name,
                author_id, author_name, item_kind, title,
                url, normalized_url, file_hash, summary, why_needed,
                tags_json, raw_input
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                chat_id,
                source_message_id,
                source_thread_id,
                target_thread_id,
                target_message_id,
                target_topic_name,
                author_id,
                author_name,
                item_kind,
                title,
                url,
                normalized_url,
                file_hash,
                summary,
                why_needed,
                tags_json,
                raw_input[:4000],
            ),
        )
        item_id = cur.lastrowid
        assert item_id is not None
        if self._fts_enabled:
            await self.conn.execute(
                """
                INSERT INTO routed_items_fts (rowid, title, summary, why_needed, tags_text, url)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (item_id, title, summary, why_needed, " ".join(tags), url),
            )
        await self.conn.commit()
        item = await self.get_routed_item(item_id)
        assert item is not None
        return item

    async def get_routed_item(self, item_id: int) -> RoutedItemRecord | None:
        async with self.conn.execute("SELECT * FROM routed_items WHERE id = ?", (item_id,)) as cur:
            row = await cur.fetchone()
        return self._row_to_item(row) if row else None

    async def update_routed_item_target(
        self,
        item_id: int,
        *,
        target_thread_id: int,
        target_message_id: int | None,
        target_topic_name: str,
    ) -> None:
        await self.conn.execute(
            """
            UPDATE routed_items
            SET target_thread_id = ?, target_message_id = ?, target_topic_name = ?
            WHERE id = ?
            """,
            (target_thread_id, target_message_id, target_topic_name, item_id),
        )
        await self.conn.commit()

    async def find_duplicate_item(
        self,
        chat_id: int,
        *,
        normalized_url: str = "",
        file_hash: str = "",
    ) -> RoutedItemRecord | None:
        if normalized_url:
            async with self.conn.execute(
                """
                SELECT * FROM routed_items
                WHERE chat_id = ? AND normalized_url = ?
                ORDER BY id DESC LIMIT 1
                """,
                (chat_id, normalized_url),
            ) as cur:
                row = await cur.fetchone()
            if row:
                return self._row_to_item(row)
        if file_hash:
            async with self.conn.execute(
                """
                SELECT * FROM routed_items
                WHERE chat_id = ? AND file_hash = ?
                ORDER BY id DESC LIMIT 1
                """,
                (chat_id, file_hash),
            ) as cur:
                row = await cur.fetchone()
            if row:
                return self._row_to_item(row)
        return None

    async def list_routed_items(
        self,
        chat_id: int | None = None,
        *,
        thread_id: int | None = None,
        limit: int = 50,
    ) -> list[RoutedItemRecord]:
        clauses: list[str] = []
        params: list[Any] = []
        if chat_id is not None:
            clauses.append("chat_id = ?")
            params.append(chat_id)
        if thread_id is not None:
            clauses.append("target_thread_id = ?")
            params.append(thread_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        async with self.conn.execute(
            f"SELECT * FROM routed_items {where} ORDER BY id DESC LIMIT ?",
            params,
        ) as cur:
            rows = await cur.fetchall()
        return [self._row_to_item(r) for r in rows]

    async def search_items(
        self,
        chat_id: int,
        query: str,
        *,
        limit: int = 10,
    ) -> list[RoutedItemRecord]:
        cleaned = query.strip()
        if not cleaned:
            return await self.list_routed_items(chat_id, limit=limit)
        if self._fts_enabled:
            # Escape double quotes and run safe token prefix FTS query
            tokens = [t.replace('"', "") for t in cleaned.split() if t.strip()]
            if tokens:
                fts_expr = " ".join(f'"{t}"*' for t in tokens)
                try:
                    async with self.conn.execute(
                        """
                        SELECT r.* FROM routed_items r
                        JOIN routed_items_fts f ON r.id = f.rowid
                        WHERE r.chat_id = ? AND routed_items_fts MATCH ?
                        ORDER BY rank, r.id DESC
                        LIMIT ?
                        """,
                        (chat_id, fts_expr, limit),
                    ) as cur:
                        rows = await cur.fetchall()
                    if rows:
                        return [self._row_to_item(r) for r in rows]
                except aiosqlite.OperationalError:
                    pass
        like = f"%{cleaned}%"
        async with self.conn.execute(
            """
            SELECT * FROM routed_items
            WHERE chat_id = ? AND (
                title LIKE ? OR summary LIKE ? OR why_needed LIKE ? OR tags_json LIKE ? OR url LIKE ?
            )
            ORDER BY id DESC LIMIT ?
            """,
            (chat_id, like, like, like, like, like, limit),
        ) as cur:
            rows = await cur.fetchall()
        return [self._row_to_item(r) for r in rows]

    def _row_to_item(self, row: aiosqlite.Row) -> RoutedItemRecord:
        try:
            tags = json.loads(row["tags_json"])
            if not isinstance(tags, list):
                tags = []
        except json.JSONDecodeError:
            tags = []
        return RoutedItemRecord(
            id=row["id"],
            chat_id=row["chat_id"],
            source_message_id=row["source_message_id"],
            source_thread_id=row["source_thread_id"],
            target_thread_id=row["target_thread_id"],
            target_message_id=row["target_message_id"],
            target_topic_name=row["target_topic_name"],
            author_id=row["author_id"],
            author_name=row["author_name"],
            item_kind=row["item_kind"],
            title=row["title"],
            url=row["url"],
            normalized_url=row["normalized_url"],
            file_hash=row["file_hash"],
            summary=row["summary"],
            why_needed=row["why_needed"],
            tags=[str(t) for t in tags],
            raw_input=row["raw_input"],
            created_at=row["created_at"],
        )

    # --- Topic Message History ---

    async def save_message(
        self,
        *,
        chat_id: int,
        thread_id: int,
        message_id: int,
        user_id: int,
        author_name: str,
        text: str,
        is_bot: bool = False,
    ) -> None:
        if not text.strip():
            return
        await self.conn.execute(
            """
            INSERT OR IGNORE INTO messages (
                chat_id, thread_id, message_id, user_id, author_name, text, is_bot
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (chat_id, thread_id, message_id, user_id, author_name, text[:4000], 1 if is_bot else 0),
        )
        await self.conn.commit()

    async def get_recent_messages(
        self,
        chat_id: int,
        thread_id: int,
        *,
        limit: int = 25,
    ) -> list[MessageRecord]:
        async with self.conn.execute(
            """
            SELECT * FROM messages
            WHERE chat_id = ? AND thread_id = ?
            ORDER BY id DESC LIMIT ?
            """,
            (chat_id, thread_id, limit),
        ) as cur:
            rows = await cur.fetchall()
        records = [
            MessageRecord(
                id=r["id"],
                chat_id=r["chat_id"],
                thread_id=r["thread_id"],
                message_id=r["message_id"],
                user_id=r["user_id"],
                author_name=r["author_name"],
                text=r["text"],
                is_bot=bool(r["is_bot"]),
                created_at=r["created_at"],
            )
            for r in rows
        ]
        records.reverse()
        return records

    async def get_stats(self, chat_id: int | None = None) -> dict[str, int]:
        if chat_id is None:
            q_topics = "SELECT COUNT(*) AS c FROM topics"
            q_items = "SELECT COUNT(*) AS c FROM routed_items"
            q_msgs = "SELECT COUNT(*) AS c FROM messages"
            params: tuple[Any, ...] = ()
        else:
            q_topics = "SELECT COUNT(*) AS c FROM topics WHERE chat_id = ?"
            q_items = "SELECT COUNT(*) AS c FROM routed_items WHERE chat_id = ?"
            q_msgs = "SELECT COUNT(*) AS c FROM messages WHERE chat_id = ?"
            params = (chat_id,)

        async with self.conn.execute(q_topics, params) as c1:
            t_count = (await c1.fetchone())["c"]
        async with self.conn.execute(q_items, params) as c2:
            i_count = (await c2.fetchone())["c"]
        async with self.conn.execute(q_msgs, params) as c3:
            m_count = (await c3.fetchone())["c"]
        return {"topics": t_count, "routed_items": i_count, "messages": m_count}

    # --- Dynamic Admin Site Domain Rotation ---

    async def rotate_admin_site_access(self) -> tuple[str, str, str]:
        """Generate a brand-new local subdomain, path prefix, and access token."""
        domain = f"adm-{secrets.token_hex(4)}.localhost"
        path = f"/gate-{secrets.token_hex(4)}"
        token = secrets.token_urlsafe(20)
        await self.update_settings(
            {
                "admin_domain": domain,
                "admin_path": path,
                "web_admin_token": token,
            }
        )
        return domain, path, token

    # --- Known Users & Bot Admins (Grant / Revoke) ---

    async def upsert_known_user(
        self,
        *,
        user_id: int,
        username: str = "",
        full_name: str = "",
        last_chat_id: int = 0,
    ) -> None:
        if not user_id:
            return
        await self.conn.execute(
            """
            INSERT INTO known_users (user_id, username, full_name, last_chat_id, last_seen_at)
            VALUES (?, ?, ?, ?, datetime('now'))
            ON CONFLICT(user_id) DO UPDATE SET
                username = CASE WHEN excluded.username != '' THEN excluded.username ELSE known_users.username END,
                full_name = CASE WHEN excluded.full_name != '' THEN excluded.full_name ELSE known_users.full_name END,
                last_chat_id = CASE WHEN excluded.last_chat_id != 0 THEN excluded.last_chat_id ELSE known_users.last_chat_id END,
                last_seen_at = datetime('now')
            """,
            (user_id, username.lstrip("@"), full_name, last_chat_id),
        )
        await self.conn.commit()

    async def list_known_users(self, limit: int = 100) -> list[KnownUserRecord]:
        async with self.conn.execute(
            "SELECT * FROM known_users ORDER BY last_seen_at DESC LIMIT ?",
            (limit,),
        ) as cur:
            rows = await cur.fetchall()
        return [
            KnownUserRecord(
                user_id=r["user_id"],
                username=r["username"],
                full_name=r["full_name"],
                last_chat_id=r["last_chat_id"],
                last_seen_at=r["last_seen_at"],
            )
            for r in rows
        ]

    async def find_user_by_username(self, username: str) -> KnownUserRecord | None:
        clean = username.strip().lstrip("@").lower()
        if not clean:
            return None
        async with self.conn.execute(
            "SELECT * FROM known_users WHERE lower(username) = ? LIMIT 1",
            (clean,),
        ) as cur:
            r = await cur.fetchone()
        if r is None:
            return None
        return KnownUserRecord(
            user_id=r["user_id"],
            username=r["username"],
            full_name=r["full_name"],
            last_chat_id=r["last_chat_id"],
            last_seen_at=r["last_seen_at"],
        )

    async def get_bot_admin_role(self, user_id: int) -> str | None:
        async with self.conn.execute(
            "SELECT role FROM bot_admins WHERE user_id = ?",
            (user_id,),
        ) as cur:
            row = await cur.fetchone()
        return str(row["role"]) if row else None

    async def set_bot_admin_role(
        self,
        user_id: int,
        role: str,
        *,
        username: str = "",
        full_name: str = "",
    ) -> None:
        if role == "default":
            await self.conn.execute("DELETE FROM bot_admins WHERE user_id = ?", (user_id,))
            await self.conn.commit()
            return
        if role not in {"granted", "revoked"}:
            raise ValueError(f"Unsupported admin role: {role}")
        await self.conn.execute(
            """
            INSERT INTO bot_admins (user_id, username, full_name, role, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'))
            ON CONFLICT(user_id) DO UPDATE SET
                role = excluded.role,
                username = CASE WHEN excluded.username != '' THEN excluded.username ELSE bot_admins.username END,
                full_name = CASE WHEN excluded.full_name != '' THEN excluded.full_name ELSE bot_admins.full_name END,
                updated_at = datetime('now')
            """,
            (user_id, username.lstrip("@"), full_name, role),
        )
        await self.conn.commit()

    async def list_bot_admins(self) -> list[BotAdminRecord]:
        async with self.conn.execute("SELECT * FROM bot_admins ORDER BY updated_at DESC") as cur:
            rows = await cur.fetchall()
        return [
            BotAdminRecord(
                user_id=r["user_id"],
                username=r["username"],
                full_name=r["full_name"],
                role=r["role"],
                updated_at=r["updated_at"],
            )
            for r in rows
        ]

    # --- User Bans & Temporary Bans ---

    async def ban_user(
        self,
        *,
        chat_id: int,
        user_id: int,
        author_name: str = "",
        reason: str = "",
        banned_by: int = 0,
        duration_seconds: int | None = None,
    ) -> UserBanRecord:
        expires_at: str | None = None
        if duration_seconds is not None and duration_seconds > 0:
            exp_dt = datetime.now(timezone.utc) + timedelta(seconds=duration_seconds)
            expires_at = exp_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

        await self.conn.execute(
            """
            INSERT INTO user_bans (chat_id, user_id, author_name, reason, banned_by, expires_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(chat_id, user_id) DO UPDATE SET
                author_name = CASE WHEN excluded.author_name != '' THEN excluded.author_name ELSE user_bans.author_name END,
                reason = excluded.reason,
                banned_by = excluded.banned_by,
                expires_at = excluded.expires_at,
                created_at = datetime('now')
            """,
            (chat_id, user_id, author_name, reason[:300], banned_by, expires_at),
        )
        await self.conn.commit()
        ban = await self.get_active_ban(chat_id, user_id)
        assert ban is not None
        return ban

    async def unban_user(self, chat_id: int, user_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM user_bans WHERE user_id = ? AND (chat_id = ? OR chat_id = 0)",
            (user_id, chat_id),
        )
        await self.conn.commit()
        return (cur.rowcount or 0) > 0

    async def _purge_expired_bans(self) -> None:
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        await self.conn.execute(
            "DELETE FROM user_bans WHERE expires_at IS NOT NULL AND expires_at <= ?",
            (now_iso,),
        )
        await self.conn.commit()

    async def get_active_ban(self, chat_id: int, user_id: int) -> UserBanRecord | None:
        await self._purge_expired_bans()
        async with self.conn.execute(
            """
            SELECT * FROM user_bans
            WHERE user_id = ? AND (chat_id = ? OR chat_id = 0)
            ORDER BY CASE WHEN chat_id = ? THEN 0 ELSE 1 END, id DESC
            LIMIT 1
            """,
            (user_id, chat_id, chat_id),
        ) as cur:
            row = await cur.fetchone()
        return self._row_to_ban(row) if row else None

    async def list_active_bans(self, chat_id: int | None = None) -> list[UserBanRecord]:
        await self._purge_expired_bans()
        if chat_id is None:
            query = "SELECT * FROM user_bans ORDER BY id DESC"
            params: tuple[Any, ...] = ()
        else:
            query = "SELECT * FROM user_bans WHERE chat_id = ? OR chat_id = 0 ORDER BY id DESC"
            params = (chat_id,)
        async with self.conn.execute(query, params) as cur:
            rows = await cur.fetchall()
        return [self._row_to_ban(r) for r in rows]

    @staticmethod
    def _row_to_ban(row: aiosqlite.Row) -> UserBanRecord:
        return UserBanRecord(
            id=row["id"],
            chat_id=row["chat_id"],
            user_id=row["user_id"],
            author_name=row["author_name"],
            reason=row["reason"],
            banned_by=row["banned_by"],
            expires_at=row["expires_at"],
            created_at=row["created_at"],
        )
