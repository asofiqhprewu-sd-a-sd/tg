from __future__ import annotations

from typing import Any

SUPPORTED_LANGUAGES = ("ru", "en")

DEFAULT_INBOX_NAMES = {
    "ru": "📥 Входящие",
    "en": "📥 Inbox",
}

STRINGS: dict[str, dict[str, str]] = {
    "ru": {
        "choose_lang": "🌐 Выберите язык / Choose language:",
        "lang_updated": "✅ Язык переключён на <b>Русский (RU)</b>.",
        "lang_admin_only": "⛔ Менять язык группы может только администратор.",
        "welcome_private": (
            "👋 <b>Привет! Я ИИ-помощник для Telegram-групп с ветками (форумом).</b>\n\n"
            "<b>Что я умею:</b>\n"
            "1. Создаю в форум-группе ветку <b>«📥 Входящие»</b>.\n"
            "2. Когда любой участник кидает туда ссылку, репозиторий (GitHub/GitLab), файл (PDF, DOCX, код, ZIP) или заметку — "
            "я выхожу в интернет из песочницы, анализирую материал через OpenAI-compatible модель и раскладываю по нужным веткам.\n"
            "3. Отвечаю на вопросы в любых ветках с учётом контекста и поиска в интернете (<code>/ask</code>, <code>/search</code>, <code>@упоминание</code>).\n"
            "4. Ищу по базе знаний (<code>/find</code>) и делаю дайджесты веток (<code>/digest</code>).\n\n"
            "<b>Команды настройки и админки:</b>\n"
            "• /setup — создать/проверить ветку «Входящие» в группе\n"
            "• /admin — админка (системник, модель, API-ключ, песочница, ветки)\n"
            "• /set_system <i>текст</i> — быстро задать системный промпт\n"
            "• /topics — список веток группы\n"
            "• /register_topic <i>название | описание</i> — зарегистрировать ветку\n\n"
            "Ваш Telegram ID: <code>{uid}</code>"
        ),
        "welcome_group": (
            "🤖 <b>Групповой ИИ-помощник по веткам активен!</b>\n"
            "{inbox_status}\n\n"
            "<b>Команды:</b>\n"
            "• /setup — проверить или создать ветку «📥 Входящие»\n"
            "• /topics — показать известные ветки\n"
            "• /register_topic <i>название | описание</i> — привязать существующую ветку\n"
            "• /find <i>запрос</i> — поиск по разобранным материалам\n"
            "• /ask <i>вопрос</i> или /search <i>запрос</i> — спросить с контекстом ветки / интернетом\n"
            "• /digest — сводка обсуждения и материалов (или <code>/digest all</code> в «Дайджесты»)\n"
            "• /compare <i>url1 url2</i> — сравнить 2 ссылки или репозитория\n"
            "• /index — навигатор по всем веткам (можно закрепить)\n"
            "• /export — скачать базу знаний в Markdown\n"
            "• /admin — панель администратора (системник, OpenAI API, песочница)"
        ),
        "inbox_active": "✅ Ветка «{name}» активна.",
        "topics_disabled": "⚠️ В этой группе ещё не включены Темы (Topics). Включите их в настройках группы.",
        "inbox_welcome": (
            "📥 <b>Ветка «Входящие» готова!</b>\n\n"
            "Сюда любой участник группы может скинуть:\n"
            "• 🔗 Ссылку на статью, сервис, документацию\n"
            "• 📦 Ссылку на репозиторий (GitHub / GitLab)\n"
            "• 📄 Файл (PDF, DOCX, код, Markdown, ZIP-архив)\n"
            "• 📝 Заметку или идею\n\n"
            "Я выйду в интернет из песочницы, изучу материал, объясню что это и зачем нужно, "
            "и распределю по подходящим веткам (или создам новую)."
        ),
        "analyzing": "⏳ Выхожу в песочницу, изучаю материал и подбираю ветку...",
        "routed_status": "✅ <b>Распределено в ветку «{topic}»</b>{new_badge}\n📌 {title}\n{link_html}{notes_html}",
        "new_topic_badge": " <i>(новая ветка)</i>",
        "goto_card": "Перейти к карточке →",
        "dup_found": "♻️ <b>Похоже, это уже было!</b>\nМатериал «{title}» уже лежит в ветке <b>«{topic}»</b>{link_part}.",
        "dup_open": "открыть существующую карточку",
        "btn_force_route": "♻️ Всё равно разобрать и распределить",
        "btn_reroute": "🔀 Перенести в другую ветку",
        "card_what": "Что это:",
        "card_why": "Зачем это нужно:",
        "card_from": "От:",
        "card_source": "Источник:",
        "card_back": "↩️ Оригинал во Входящих",
        "admin_title": "🛠 <b>Панель администратора</b>",
        "admin_btn_prompt": "📝 Задать системник",
        "admin_btn_show_prompt": "👁 Показать системник",
        "admin_btn_model": "🤖 Модель и OpenAI API",
        "admin_btn_test": "🩺 Тест модели",
        "admin_btn_sandbox": "🌐 Песочница",
        "admin_btn_topics": "🗂 Ветки",
        "admin_btn_lang": "🌐 Язык: RU",
        "admin_btn_stats": "📊 Статистика и Web-админка",
        "admin_btn_back": "⬅️ Назад в админку",
        "thinking": "⏳ Думаю над ответом...",
        "searching": "⏳ Ищу в интернете и думаю...",
        "digesting": "⏳ Собираю дайджест по ветке...",
    },
    "en": {
        "choose_lang": "🌐 Choose language / Выберите язык:",
        "lang_updated": "✅ Language switched to <b>English (EN)</b>.",
        "lang_admin_only": "⛔ Only a group administrator can change the group language.",
        "welcome_private": (
            "👋 <b>Hi! I'm an AI assistant for Telegram Forum Groups (with Topics).</b>\n\n"
            "<b>What I can do:</b>\n"
            "1. Automatically create an <b>«📥 Inbox»</b> topic in your forum group.\n"
            "2. Whenever any member drops a URL, repository (GitHub/GitLab), file (PDF, DOCX, code, ZIP), or note there — "
            "I fetch it from the internet inside my sandbox, analyze it with an OpenAI-compatible model, and route it to the right topic.\n"
            "3. Answer questions in any topic with thread context & web search (<code>/ask</code>, <code>/search</code>, or <code>@mention</code>).\n"
            "4. Search the knowledge base (<code>/find</code>) and generate topic summaries (<code>/digest</code>).\n\n"
            "<b>Setup & Admin commands:</b>\n"
            "• /setup — create/verify the Inbox topic in a group\n"
            "• /admin — admin panel (system prompt, model, API key, sandbox, topics)\n"
            "• /set_system <i>text</i> — quickly set the system prompt\n"
            "• /topics — list tracked topics in the group\n"
            "• /register_topic <i>name | description</i> — register an existing topic\n\n"
            "Your Telegram ID: <code>{uid}</code>"
        ),
        "welcome_group": (
            "🤖 <b>Group Topic AI Assistant is active!</b>\n"
            "{inbox_status}\n\n"
            "<b>Commands:</b>\n"
            "• /setup — create or check the «📥 Inbox» topic\n"
            "• /topics — list known topics\n"
            "• /register_topic <i>name | description</i> — bind an existing topic\n"
            "• /find <i>query</i> — search analyzed knowledge base\n"
            "• /ask <i>question</i> or /search <i>query</i> — ask with topic context / web search\n"
            "• /digest — summarize topic or whole group (<code>/digest all</code> -> «Digests»)\n"
            "• /compare <i>url1 url2</i> — compare 2 links or repos side-by-side\n"
            "• /index — interactive topic directory (pinnable)\n"
            "• /export — download knowledge base as Markdown\n"
            "• /admin — admin panel (system prompt, OpenAI API, sandbox)"
        ),
        "inbox_active": "✅ Topic «{name}» is active.",
        "topics_disabled": "⚠️ Topics (Forum mode) are disabled in this group. Enable Topics in Group Settings.",
        "inbox_welcome": (
            "📥 <b>«Inbox» topic is ready!</b>\n\n"
            "Any group member can drop here:\n"
            "• 🔗 Links to articles, tools, documentation\n"
            "• 📦 GitHub / GitLab repositories\n"
            "• 📄 Files (PDF, DOCX, source code, Markdown, ZIP archives)\n"
            "• 📝 Notes or ideas\n\n"
            "I will inspect it from my internet sandbox, explain what it is and why it matters, "
            "and route it to the best matching topic (or create a new one)."
        ),
        "analyzing": "⏳ Inspecting via sandbox & internet, matching a topic...",
        "routed_status": "✅ <b>Routed to «{topic}»</b>{new_badge}\n📌 {title}\n{link_html}{notes_html}",
        "new_topic_badge": " <i>(new topic)</i>",
        "goto_card": "Open card →",
        "dup_found": "♻️ <b>Already shared before!</b>\n«{title}» is already in <b>«{topic}»</b>{link_part}.",
        "dup_open": "open existing card",
        "btn_force_route": "♻️ Analyze & route anyway",
        "btn_reroute": "🔀 Move to another topic",
        "card_what": "What it is:",
        "card_why": "Why it matters:",
        "card_from": "From:",
        "card_source": "Source:",
        "card_back": "↩️ Original in Inbox",
        "admin_title": "🛠 <b>Admin Panel</b>",
        "admin_btn_prompt": "📝 Set System Prompt",
        "admin_btn_show_prompt": "👁 View System Prompt",
        "admin_btn_model": "🤖 Model & OpenAI API",
        "admin_btn_test": "🩺 Test Model",
        "admin_btn_sandbox": "🌐 Sandbox",
        "admin_btn_topics": "🗂 Topics",
        "admin_btn_lang": "🌐 Language: EN",
        "admin_btn_stats": "📊 Stats & Web Admin",
        "admin_btn_back": "⬅️ Back to Admin",
        "thinking": "⏳ Thinking...",
        "searching": "⏳ Searching the web & thinking...",
        "digesting": "⏳ Generating topic digest...",
    },
}


def normalize_lang(lang: str | None) -> str:
    val = (lang or "ru").strip().lower()
    return val if val in SUPPORTED_LANGUAGES else "ru"


def t(lang: str | None, key: str, **kwargs: Any) -> str:
    code = normalize_lang(lang)
    template = STRINGS[code].get(key) or STRINGS["ru"].get(key) or key
    return template.format(**kwargs) if kwargs else template
