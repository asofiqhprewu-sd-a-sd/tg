from __future__ import annotations

import html
from dataclasses import dataclass

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

from app.config import RuntimeSettings
from app.db import Database
from app.i18n import DEFAULT_INBOX_NAMES, t
from app.models import RoutedItemRecord, TopicRecord
from app.services.analyzer import AnalysisDecision


def build_topic_message_link(chat_id: int, message_id: int | None, thread_id: int | None = None) -> str:
    """Build a t.me/c/... deep link for supergroups (-100xxxxxxxxxx)."""
    s_id = str(chat_id)
    if not s_id.startswith("-100"):
        return ""
    internal_id = s_id[4:]
    if message_id:
        return f"https://t.me/c/{internal_id}/{message_id}"
    if thread_id:
        return f"https://t.me/c/{internal_id}/{thread_id}"
    return ""


def format_routed_card_html(
    decision: AnalysisDecision,
    *,
    author_id: int,
    author_name: str,
    source_link: str = "",
    lang: str = "ru",
) -> str:
    if lang == "en":
        kind_badge = {
            "repo": "📦 Repository",
            "video": "🎥 Video (YouTube)",
            "link": "🔗 Link",
            "file": "📄 File",
            "image": "🖼 Image",
            "note": "📝 Note",
        }.get(decision.item_kind, "📌 Item")
    else:
        kind_badge = {
            "repo": "📦 Репозиторий",
            "video": "🎥 Видео (YouTube)",
            "link": "🔗 Ссылка",
            "file": "📄 Файл",
            "image": "🖼 Изображение",
            "note": "📝 Заметка",
        }.get(decision.item_kind, "📌 Материал")

    safe_title = html.escape(decision.title)
    safe_summary = html.escape(decision.summary)
    safe_why = html.escape(decision.why_needed)
    safe_author = html.escape(author_name)
    author_mention = f'<a href="tg://user?id={author_id}">{safe_author}</a>'

    lines = [
        f"<b>{kind_badge}: {safe_title}</b>",
        f"👤 {t(lang, 'card_from')} {author_mention}",
    ]
    if decision.primary_url:
        safe_url = html.escape(decision.primary_url)
        lines.append(f"🌐 {t(lang, 'card_source')} {safe_url}")
    lines.append("")
    lines.append(f"<b>{t(lang, 'card_what')}</b>\n{safe_summary}")
    if safe_why:
        lines.append("")
        lines.append(f"<b>{t(lang, 'card_why')}</b>\n{safe_why}")
    if decision.tags:
        tags_str = " ".join(f"#{html.escape(tag)}" for tag in decision.tags)
        lines.append("")
        lines.append(f"🏷 {tags_str}")
    if source_link:
        lines.append(f'\n<a href="{html.escape(source_link)}">{t(lang, "card_back")}</a>')

    return "\n".join(lines)[:4000]


@dataclass
class EnsureInboxResult:
    ok: bool
    topic: TopicRecord | None = None
    created: bool = False
    error: str = ""


class TopicRouterService:
    """Manages Telegram Forum Topics ('ветки') and routes analyzed Inbox items."""

    def __init__(self, db: Database) -> None:
        self.db = db

    async def ensure_inbox_topic(
        self,
        bot: Bot,
        chat_id: int,
        chat_title: str,
        settings: RuntimeSettings,
        lang: str = "ru",
    ) -> EnsureInboxResult:
        chat = await self.db.get_chat(chat_id)
        if chat and chat.inbox_thread_id:
            topic = await self.db.get_topic(chat_id, chat.inbox_thread_id)
            if topic is not None and not topic.is_closed:
                return EnsureInboxResult(ok=True, topic=topic, created=False)

        inbox_name = settings.inbox_topic_name
        if inbox_name in {"📥 Входящие", "📥 Inbox"}:
            inbox_name = DEFAULT_INBOX_NAMES.get(lang, "📥 Входящие")

        # Check if a topic with inbox name was already discovered
        existing_by_name = None
        for candidate in (inbox_name, "📥 Входящие", "Входящие", "📥 Inbox", "Inbox"):
            existing_by_name = await self.db.find_topic_by_name(chat_id, candidate)
            if existing_by_name is not None:
                break
        if existing_by_name is not None and not existing_by_name.is_closed:
            await self.db.upsert_topic(
                chat_id,
                existing_by_name.thread_id,
                existing_by_name.name,
                is_inbox=True,
                description="Inbox topic for incoming links, files, and repositories",
            )
            await self.db.set_chat_inbox_thread(chat_id, existing_by_name.thread_id)
            topic = await self.db.get_topic(chat_id, existing_by_name.thread_id)
            return EnsureInboxResult(ok=True, topic=topic, created=False)

        # Create the Inbox topic in Telegram
        try:
            tg_topic = await bot.create_forum_topic(
                chat_id=chat_id,
                name=inbox_name[:120],
            )
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            err_msg = (
                "Failed to create Inbox topic. Make sure:\n"
                "1) Topics (Forum mode) are enabled in Group Settings.\n"
                "2) The bot is an admin with 'Manage Topics' (can_manage_topics) permission.\n"
                f"Telegram API: {exc}"
                if lang == "en"
                else "Не удалось создать ветку «Входящие». Убедитесь, что:\n"
                "1) В группе включены Темы (Topics / Форум).\n"
                "2) Бот назначен администратором с правом «Управление темами» (can_manage_topics).\n"
                f"Детали Telegram API: {exc}"
            )
            return EnsureInboxResult(ok=False, error=err_msg)

        await self.db.upsert_chat(chat_id, chat_title, True)
        topic = await self.db.upsert_topic(
            chat_id,
            tg_topic.message_thread_id,
            tg_topic.name,
            description="Inbox for incoming links, files, repositories, and notes.",
            is_inbox=True,
            created_by_bot=True,
        )
        await self.db.set_chat_inbox_thread(chat_id, tg_topic.message_thread_id)

        try:
            await bot.send_message(
                chat_id=chat_id,
                message_thread_id=tg_topic.message_thread_id,
                text=t(lang, "inbox_welcome"),
                parse_mode="HTML",
            )
        except Exception:
            pass

        return EnsureInboxResult(ok=True, topic=topic, created=True)

    async def ensure_named_topic(
        self,
        bot: Bot,
        chat_id: int,
        name: str,
        *,
        description: str = "",
    ) -> TopicRecord:
        existing = await self.db.find_topic_by_name(chat_id, name)
        if existing is None:
            alt = "Digests" if "Дайджесты" in name else ("Дайджесты" if "Digests" in name else "")
            if alt:
                existing = await self.db.find_topic_by_name(chat_id, f"📢 {alt}") or await self.db.find_topic_by_name(chat_id, alt)
        if existing is not None and not existing.is_closed:
            return existing
        tg_topic = await bot.create_forum_topic(chat_id=chat_id, name=name[:120])
        return await self.db.upsert_topic(
            chat_id,
            tg_topic.message_thread_id,
            tg_topic.name,
            description=description,
            is_inbox=False,
            created_by_bot=True,
        )

    async def resolve_or_create_target_topic(
        self,
        bot: Bot,
        chat_id: int,
        decision: AnalysisDecision,
    ) -> TopicRecord:
        if decision.target_thread_id is not None:
            existing = await self.db.get_topic(chat_id, decision.target_thread_id)
            if existing is not None and not existing.is_closed:
                return existing

        existing_by_name = await self.db.find_topic_by_name(chat_id, decision.target_topic_name)
        if existing_by_name is not None and not existing_by_name.is_closed:
            return existing_by_name

        tg_topic = await bot.create_forum_topic(
            chat_id=chat_id,
            name=decision.target_topic_name[:120],
        )
        return await self.db.upsert_topic(
            chat_id,
            tg_topic.message_thread_id,
            tg_topic.name,
            description=decision.new_topic_description,
            is_inbox=False,
            created_by_bot=True,
        )

    async def publish_to_topic(
        self,
        bot: Bot,
        *,
        chat_id: int,
        target_topic: TopicRecord,
        card_html: str,
        source_message_id: int,
        has_media: bool = False,
        reply_markup=None,
    ) -> int:
        """Publish summary card (and copy attachment if any) to the target forum topic."""
        try:
            sent = await bot.send_message(
                chat_id=chat_id,
                message_thread_id=target_topic.thread_id,
                text=card_html,
                parse_mode="HTML",
                disable_web_page_preview=False,
                reply_markup=reply_markup,
            )
        except TelegramBadRequest as exc:
            # If the topic was deleted manually on Telegram side, recreate and retry once
            err = str(exc).lower()
            if "thread not found" in err or "topic_deleted" in err or "topic_closed" in err:
                tg_topic = await bot.create_forum_topic(chat_id=chat_id, name=target_topic.name[:120])
                new_topic = await self.db.upsert_topic(
                    chat_id,
                    tg_topic.message_thread_id,
                    tg_topic.name,
                    description=target_topic.description,
                    created_by_bot=True,
                )
                sent = await bot.send_message(
                    chat_id=chat_id,
                    message_thread_id=new_topic.thread_id,
                    text=card_html,
                    parse_mode="HTML",
                    disable_web_page_preview=False,
                    reply_markup=reply_markup,
                )
                target_topic = new_topic
            else:
                raise

        if has_media:
            try:
                await bot.copy_message(
                    chat_id=chat_id,
                    from_chat_id=chat_id,
                    message_id=source_message_id,
                    message_thread_id=target_topic.thread_id,
                    reply_to_message_id=sent.message_id,
                )
            except Exception:
                pass

        return sent.message_id

    async def reroute_existing_item(
        self,
        bot: Bot,
        item: RoutedItemRecord,
        new_target_topic: TopicRecord,
        *,
        reply_markup=None,
        lang: str = "ru",
    ) -> int:
        """Move a previously routed card to a different topic chosen by a user/admin."""
        decision = AnalysisDecision(
            title=item.title,
            summary=item.summary,
            why_needed=item.why_needed,
            target_thread_id=new_target_topic.thread_id,
            target_topic_name=new_target_topic.name,
            create_new_topic=False,
            new_topic_description="",
            tags=item.tags,
            item_kind=item.item_kind,
            primary_url=item.url,
            normalized_url=item.normalized_url,
            file_hash=item.file_hash,
        )
        source_link = build_topic_message_link(item.chat_id, item.source_message_id, item.source_thread_id)
        card_html = format_routed_card_html(
            decision,
            author_id=item.author_id,
            author_name=item.author_name,
            source_link=source_link,
            lang=lang,
        )
        new_msg_id = await self.publish_to_topic(
            bot,
            chat_id=item.chat_id,
            target_topic=new_target_topic,
            card_html=card_html,
            source_message_id=item.source_message_id,
            has_media=(item.item_kind in {"file", "image"}),
            reply_markup=reply_markup,
        )
        # Try removing old routed message to avoid duplicates across topics
        if item.target_message_id:
            try:
                await bot.delete_message(chat_id=item.chat_id, message_id=item.target_message_id)
            except Exception:
                pass

        await self.db.update_routed_item_target(
            item.id,
            target_thread_id=new_target_topic.thread_id,
            target_message_id=new_msg_id,
            target_topic_name=new_target_topic.name,
        )
        return new_msg_id
