from __future__ import annotations

import base64
import mimetypes
import re
from dataclasses import dataclass, field
from typing import Any

from app.config import RuntimeSettings
from app.llm.client import OpenAICompatibleClient
from app.models import TopicRecord
from app.sandbox.files import FileSandbox, InspectedFile
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient, extract_urls, normalize_url
from app.sandbox.youtube import YouTubeInspector


def strip_emoji_prefix(name: str) -> str:
    cleaned = re.sub(r"^[^\wА-Яа-яЁё]+", "", name.strip())
    return " ".join(cleaned.lower().split())


@dataclass
class ExtractedPayload:
    item_kind: str  # "repo" | "link" | "file" | "image" | "note"
    urls: list[str] = field(default_factory=list)
    primary_url: str = ""
    normalized_url: str = ""
    file_hash: str = ""
    filename: str = ""
    context_text: str = ""
    image_b64: str = ""
    image_mime: str = ""
    extraction_notes: list[str] = field(default_factory=list)


@dataclass
class AnalysisDecision:
    title: str
    summary: str
    why_needed: str
    target_thread_id: int | None
    target_topic_name: str
    create_new_topic: bool
    new_topic_description: str
    tags: list[str]
    item_kind: str
    primary_url: str
    normalized_url: str
    file_hash: str


class InboxAnalyzer:
    """Extracts content via internet/file sandbox and classifies it with the OpenAI-compatible LLM."""

    def __init__(
        self,
        *,
        http_client: SandboxHttpClient,
        repo_inspector: RepoInspector,
        file_sandbox: FileSandbox,
        llm_client: OpenAICompatibleClient,
        youtube_inspector: YouTubeInspector | None = None,
    ) -> None:
        self.http = http_client
        self.repos = repo_inspector
        self.files = file_sandbox
        self.llm = llm_client
        self.youtube = youtube_inspector or YouTubeInspector(http_client)

    async def extract_payload(
        self,
        *,
        text: str,
        settings: RuntimeSettings,
        file_name: str = "",
        file_bytes: bytes | None = None,
        is_image: bool = False,
    ) -> ExtractedPayload:
        urls = extract_urls(text)
        primary_url = urls[0] if urls else ""
        norm_url = normalize_url(primary_url) if primary_url else ""

        sections: list[str] = []
        notes: list[str] = []
        item_kind = "note"

        if text.strip():
            sections.append(f"Текст/комментарий участника:\n{text.strip()[:2500]}")

        inspected_file: InspectedFile | None = None
        image_b64 = ""
        image_mime = ""
        if file_bytes is not None:
            inspected_file = self.files.inspect_bytes(file_name or "attachment.bin", file_bytes)
            item_kind = "image" if (is_image or inspected_file.kind == "image") else "file"
            if item_kind == "image" and len(file_bytes) <= 2_500_000:
                image_b64 = base64.b64encode(file_bytes).decode("ascii")
                guessed, _ = mimetypes.guess_type(inspected_file.filename)
                image_mime = guessed if guessed and guessed.startswith("image/") else "image/jpeg"
            file_section = [
                f"Прикреплённый файл: {inspected_file.filename} ({inspected_file.size_bytes} байт, тип: {inspected_file.kind})"
            ]
            if inspected_file.error:
                file_section.append(f"Ошибка инспекции файла: {inspected_file.error}")
                notes.append(inspected_file.error)
            if inspected_file.extracted_text:
                file_section.append(f"Содержимое файла:\n{inspected_file.extracted_text}")
            sections.append("\n".join(file_section))
        elif is_image:
            item_kind = "image"
            sections.append("Участник отправил изображение/скриншот.")

        # Inspect up to 2 URLs from the internet sandbox
        for idx, url in enumerate(urls[:2]):
            yt = await self.youtube.inspect(url, settings)
            if yt is not None:
                if idx == 0 and item_kind == "note":
                    item_kind = "video"
                sections.append(yt.to_prompt_text())
                if yt.error:
                    notes.append(yt.error)
                continue

            repo = await self.repos.inspect(url, settings)
            if repo is not None:
                if idx == 0 and item_kind == "note":
                    item_kind = "repo"
                sections.append(repo.to_prompt_text())
                if repo.error:
                    notes.append(repo.error)
                continue

            page = await self.http.fetch_webpage(url, settings, max_text_chars=6500)
            if idx == 0 and item_kind == "note":
                item_kind = "link"
            page_parts = [f"Веб-ресурс: {page.final_url}"]
            if page.error:
                page_parts.append(f"Не удалось загрузить страницу из песочницы: {page.error}")
                notes.append(f"{url}: {page.error}")
            else:
                if page.title:
                    page_parts.append(f"Заголовок страницы: {page.title}")
                if page.description:
                    page_parts.append(f"Описание страницы: {page.description}")
                if page.text:
                    page_parts.append(f"Текст страницы:\n{page.text}")
            sections.append("\n".join(page_parts))

        return ExtractedPayload(
            item_kind=item_kind,
            urls=urls,
            primary_url=primary_url,
            normalized_url=norm_url,
            file_hash=inspected_file.sha256 if inspected_file else "",
            filename=inspected_file.filename if inspected_file else file_name,
            context_text="\n\n====================\n\n".join(sections)[:15000],
            image_b64=image_b64,
            image_mime=image_mime,
            extraction_notes=notes,
        )

    async def analyze_and_classify(
        self,
        *,
        payload: ExtractedPayload,
        author_name: str,
        existing_topics: list[TopicRecord],
        settings: RuntimeSettings,
        chat_system_override: str = "",
        lang: str = "ru",
    ) -> AnalysisDecision:
        topics_desc_lines: list[str] = []
        for t in existing_topics:
            if t.is_inbox or t.is_closed:
                continue
            desc = f" — {t.description}" if t.description else ""
            topics_desc_lines.append(f"- thread_id={t.thread_id} | name=\"{t.name}\"{desc}")

        topics_block = (
            "\n".join(topics_desc_lines)
            if topics_desc_lines
            else ("(No topics created yet — suggest a fitting new topic)" if lang == "en" else "(Пока нет созданных тематических веток — предложи подходящую новую ветку)")
        )

        system_parts = [settings.system_prompt.strip()]
        if chat_system_override.strip():
            system_parts.append(f"Дополнительная инструкция для этой группы:\n{chat_system_override.strip()}")

        output_lang_instr = (
            "Write title, summary, why_needed, new_topic_description, and any NEW target_topic_name in ENGLISH."
            if lang == "en"
            else "Поля title, summary, why_needed, new_topic_description и название НОВОЙ ветки (если создаётся) пиши на РУССКОМ языке."
        )
        system_parts.append(
            "Ты анализируешь входящие материалы (ссылки, репозитории, файлы, заметки) из ветки «Входящие» / «Inbox» "
            "и распределяешь их по тематическим веткам группы.\n"
            f"{output_lang_instr}\n"
            "Верни СТРОГО валидный JSON-объект без лишнего текста со следующими полями:\n"
            "{\n"
            '  "title": "Short clear title (max 80 chars)",\n'
            '  "summary": "What this is: essence, tech stack, key capabilities (2-4 sentences)",\n'
            '  "why_needed": "Why it matters and how the team can apply it (1-2 sentences)",\n'
            '  "target_thread_id": numeric thread_id of existing topic OR null if new topic is needed,\n'
            '  "target_topic_name": "Exact name of existing topic OR short new topic name with leading emoji (e.g. ⚙️ Backend, 🤖 AI & LLM, 🎨 Design)",\n'
            '  "create_new_topic": true or false,\n'
            '  "new_topic_description": "1-sentence topic description if create_new_topic=true",\n'
            '  "tags": ["tag1", "tag2", "tag3"]\n'
            "}\n\n"
            "Правила выбора ветки:\n"
            "1. Сначала проверь существующие ветки — если одна из них хорошо подходит по смыслу, выбери её "
            "(укажи её точный target_thread_id и target_topic_name, и create_new_topic=false).\n"
            "2. Если ни одна существующая ветка не подходит, предложи новую короткую обобщённую ветку."
        )

        user_prompt = (
            f"Автор сообщения: {author_name}\n"
            f"Тип материала: {payload.item_kind}\n\n"
            f"Существующие ветки группы:\n{topics_block}\n\n"
            f"Извлечённый материал из песочницы:\n{payload.context_text}"
        )

        user_content: Any = user_prompt
        if payload.image_b64:
            mime = payload.image_mime or "image/jpeg"
            user_content = [
                {"type": "text", "text": user_prompt},
                {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{payload.image_b64}"}},
            ]

        raw_json = await self.llm.complete_json(
            settings,
            [
                {"role": "system", "content": "\n\n".join(system_parts)},
                {"role": "user", "content": user_content},
            ],
            temperature=0.2,
            max_tokens=settings.openai_max_tokens,
        )

        return self._normalize_decision(raw_json, payload, existing_topics, settings)

    def _normalize_decision(
        self,
        data: dict,
        payload: ExtractedPayload,
        existing_topics: list[TopicRecord],
        settings: RuntimeSettings,
    ) -> AnalysisDecision:
        non_inbox = [t for t in existing_topics if not t.is_inbox and not t.is_closed]
        by_id = {t.thread_id: t for t in non_inbox}
        by_norm_name = {strip_emoji_prefix(t.name): t for t in non_inbox if strip_emoji_prefix(t.name)}
        by_exact_lower = {t.name.strip().lower(): t for t in non_inbox}

        raw_tid = data.get("target_thread_id")
        matched_topic: TopicRecord | None = None
        if isinstance(raw_tid, int) and raw_tid in by_id:
            matched_topic = by_id[raw_tid]
        elif isinstance(raw_tid, str) and raw_tid.strip().isdigit() and int(raw_tid.strip()) in by_id:
            matched_topic = by_id[int(raw_tid.strip())]

        raw_tname = str(data.get("target_topic_name") or "").strip()
        if matched_topic is None and raw_tname:
            matched_topic = by_exact_lower.get(raw_tname.lower()) or by_norm_name.get(
                strip_emoji_prefix(raw_tname)
            )

        if matched_topic is not None:
            target_thread_id: int | None = matched_topic.thread_id
            target_topic_name = matched_topic.name
            create_new_topic = False
        elif settings.auto_create_topics:
            target_thread_id = None
            target_topic_name = (raw_tname or "📚 Разное")[:60]
            create_new_topic = True
        else:
            if non_inbox:
                fallback = non_inbox[0]
                target_thread_id = fallback.thread_id
                target_topic_name = fallback.name
                create_new_topic = False
            else:
                target_thread_id = None
                target_topic_name = "📚 Общее"
                create_new_topic = True

        raw_tags = data.get("tags") or []
        if isinstance(raw_tags, str):
            raw_tags = [t.strip() for t in raw_tags.split(",") if t.strip()]
        tags: list[str] = []
        for t in raw_tags[:5]:
            clean_tag = re.sub(r"[^\wА-Яа-яЁё_-]", "", str(t).lstrip("#"))
            if clean_tag:
                tags.append(clean_tag.lower())

        title = str(data.get("title") or "").strip() or (
            payload.filename or payload.primary_url or "Материал из Входящих"
        )
        summary = str(data.get("summary") or "").strip() or "Содержимое разобрано, краткое описание не сформировано."
        why_needed = str(data.get("why_needed") or "").strip()
        new_desc = str(data.get("new_topic_description") or "").strip()

        return AnalysisDecision(
            title=title[:120],
            summary=summary[:2000],
            why_needed=why_needed[:1000],
            target_thread_id=target_thread_id,
            target_topic_name=target_topic_name,
            create_new_topic=create_new_topic,
            new_topic_description=new_desc[:300],
            tags=tags,
            item_kind=payload.item_kind,
            primary_url=payload.primary_url,
            normalized_url=payload.normalized_url,
            file_hash=payload.file_hash,
        )
