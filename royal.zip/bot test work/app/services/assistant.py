from __future__ import annotations

import asyncio
import html

from app.config import RuntimeSettings
from app.db import Database
from app.llm.client import OpenAICompatibleClient
from app.models import RoutedItemRecord, TopicRecord
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient, extract_urls
from app.sandbox.youtube import YouTubeInspector
from app.services.router import build_topic_message_link


class AssistantService:
    """Topic-aware group Q&A assistant, web research, topic digest, specs, compare, and search."""

    def __init__(
        self,
        *,
        db: Database,
        llm: OpenAICompatibleClient,
        http: SandboxHttpClient,
        repos: RepoInspector,
        youtube: YouTubeInspector | None = None,
    ) -> None:
        self.db = db
        self.llm = llm
        self.http = http
        self.repos = repos
        self.youtube = youtube or YouTubeInspector(http)

    async def _inspect_url_text(self, url: str, settings: RuntimeSettings, max_chars: int = 4500) -> str:
        yt = await self.youtube.inspect(url, settings)
        if yt is not None:
            return yt.to_prompt_text()[:max_chars]
        repo = await self.repos.inspect(url, settings)
        if repo is not None:
            return repo.to_prompt_text()[:max_chars]
        page = await self.http.fetch_webpage(url, settings, max_text_chars=max_chars)
        if not page.error:
            return f"Страница {page.final_url} ({page.title}):\n{page.text}"
        return f"Не удалось открыть {url}: {page.error}"

    async def answer_question(
        self,
        *,
        chat_id: int,
        thread_id: int,
        user_name: str,
        question: str,
        settings: RuntimeSettings,
        force_web_search: bool = False,
        lang: str = "ru",
    ) -> str:
        chat = await self.db.get_chat(chat_id)
        topic = await self.db.get_topic(chat_id, thread_id) if thread_id else None
        recent_msgs = await self.db.get_recent_messages(chat_id, thread_id, limit=20)
        topic_items = await self.db.list_routed_items(chat_id, thread_id=thread_id, limit=8)

        # Search across the ENTIRE group knowledge base as well!
        kb_matches = await self.db.search_items(chat_id, question, limit=6)
        if len(kb_matches) < 3:
            extra_recent = await self.db.list_routed_items(chat_id, limit=8)
            seen_ids = {it.id for it in kb_matches}
            for it in extra_recent:
                if it.id not in seen_ids:
                    kb_matches.append(it)
                    seen_ids.add(it.id)
                if len(kb_matches) >= 6:
                    break

        # Fetch any URLs explicitly mentioned in the question, or run sandbox web search if needed
        web_context_parts: list[str] = []
        urls = extract_urls(question)
        if settings.sandbox_internet_enabled and urls:
            for url in urls[:2]:
                web_context_parts.append(await self._inspect_url_text(url, settings))

        elif settings.sandbox_internet_enabled and (force_web_search or (settings.web_search_in_qa and self._looks_like_web_query(question))):
            try:
                hits = await self.http.search_web(question, settings, limit=4)
                if hits:
                    formatted_hits = "\n".join(
                        f"- {h.title} ({h.url}): {h.snippet}" for h in hits
                    )
                    web_context_parts.append(f"Результаты поиска в интернете:\n{formatted_hits}")
            except Exception:
                pass

        sys_parts = [settings.system_prompt.strip()]
        if chat and chat.system_prompt_override.strip():
            sys_parts.append(f"Системная инструкция группы:\n{chat.system_prompt_override.strip()}")
        if topic and topic.system_prompt.strip():
            sys_parts.append(f"Системная инструкция для ветки «{topic.name}»:\n{topic.system_prompt.strip()}")

        topic_label = topic.name if topic else ("General chat" if lang == "en" else "Общий чат")
        lang_hint = "Respond in English." if lang == "en" else "Отвечай на русском языке."
        sys_parts.append(
            f"Сейчас ты отвечаешь в ветке Telegram-группы: «{topic_label}».\n"
            "Используй контекст сообщений ветки, всю накопленную базу знаний чата (с указанием ветки) и данные из интернета (если они предоставлены). "
            f"{lang_hint} Пиши чётко и лаконично."
        )

        context_blocks: list[str] = []
        if topic_items:
            kb_lines = [
                f"• [{it.item_kind}] {it.title} — {it.summary[:220]}"
                + (f" ({it.url})" if it.url else "")
                for it in topic_items
            ]
            context_blocks.append("Сохранённые материалы в текущей ветке:\n" + "\n".join(kb_lines))

        topic_item_ids = {it.id for it in topic_items}
        other_kb = [it for it in kb_matches if it.id not in topic_item_ids]
        if other_kb:
            group_kb_lines = [
                f"• [Ветка: {it.target_topic_name}] {it.title} — {it.summary[:200]}"
                + (f" ({it.url})" if it.url else "")
                for it in other_kb
            ]
            context_blocks.append("Релевантные материалы из других веток базы знаний группы:\n" + "\n".join(group_kb_lines))

        if recent_msgs:
            hist_lines = [
                f"{'[Бот] ' if m.is_bot else ''}{m.author_name}: {m.text[:400]}"
                for m in recent_msgs[-15:]
            ]
            context_blocks.append("Последние сообщения ветки:\n" + "\n".join(hist_lines))

        if web_context_parts:
            context_blocks.append("\n\n".join(web_context_parts))

        user_content = f"Вопрос от {user_name}:\n{question}"
        if context_blocks:
            user_content = "\n\n---\n\n".join(context_blocks) + "\n\n---\n\n" + user_content

        return await self.llm.chat(
            settings,
            [
                {"role": "system", "content": "\n\n".join(sys_parts)},
                {"role": "user", "content": user_content[:16000]},
            ],
        )

    async def build_digest(
        self,
        *,
        chat_id: int,
        thread_id: int,
        settings: RuntimeSettings,
        lang: str = "ru",
        group_wide: bool = False,
    ) -> str:
        topic: TopicRecord | None = await self.db.get_topic(chat_id, thread_id) if (thread_id and not group_wide) else None
        recent_msgs = await self.db.get_recent_messages(chat_id, thread_id, limit=40) if not group_wide else []
        use_thread_filter = thread_id if (topic and not topic.is_inbox and not group_wide) else None
        items = await self.db.list_routed_items(
            chat_id,
            thread_id=use_thread_filter,
            limit=35 if group_wide else 15,
        )

        if not recent_msgs and not items:
            return (
                "Not enough messages or saved items yet for a digest."
                if lang == "en"
                else "Пока недостаточно сообщений и материалов для дайджеста."
            )

        parts: list[str] = []
        if items:
            parts.append(
                "Материалы базы знаний:\n"
                + "\n".join(
                    f"- [{it.target_topic_name}] {it.title}: {it.summary[:220]}"
                    + (f" | Зачем: {it.why_needed[:120]}" if it.why_needed else "")
                    + f" ({it.url or 'файл/заметка'})"
                    for it in items
                )
            )
        if recent_msgs:
            parts.append(
                "Обсуждение в ветке:\n"
                + "\n".join(f"{m.author_name}: {m.text[:350]}" for m in recent_msgs)
            )

        scope_label = (
            ("entire group" if lang == "en" else "всей группы")
            if (group_wide or topic is None)
            else f"«{topic.name}»"
        )
        digest_prompt = (
            f"{settings.system_prompt}\n\n"
            f"Create a structured digest in ENGLISH for {scope_label}: "
            "1) Key themes & decisions; 2) Highlighted links/repos/videos grouped by topic; 3) Open questions & action items."
            if lang == "en"
            else f"{settings.system_prompt}\n\n"
            f"Сделай структурированный дайджест на РУССКОМ языке для {scope_label}: "
            "1) Главные темы и итоги; 2) Ключевые ссылки, репозитории и материалы по веткам; 3) Открытые вопросы и задачи."
        )
        return await self.llm.chat(
            settings,
            [
                {"role": "system", "content": digest_prompt},
                {"role": "user", "content": "\n\n".join(parts)[:15000]},
            ],
            temperature=0.2,
        )

    async def generate_item_spec(
        self,
        item: RoutedItemRecord,
        settings: RuntimeSettings,
        *,
        lang: str = "ru",
    ) -> str:
        """Generate an actionable developer task / technical spec (ТЗ) from a routed item."""
        instr = (
            f"{settings.system_prompt}\n\n"
            "Generate a concise, practical Developer Task / Technical Specification in ENGLISH based on this material:\n"
            "1) Goal & Value\n2) Acceptance Criteria (checklist)\n3) Implementation Steps / Subtasks\n4) Risks & Dependencies."
            if lang == "en"
            else f"{settings.system_prompt}\n\n"
            "Составь готовое, практичное ТЗ / задачу для разработчиков на РУССКОМ языке на основе материала:\n"
            "1) Цель и ожидаемый эффект\n2) Критерии приёмки (чеклист)\n3) Шаги реализации / подзадачи\n4) Риски и зависимости."
        )
        body = (
            f"Название: {item.title}\n"
            f"Тип: {item.item_kind} | Ветка: {item.target_topic_name}\n"
            f"URL: {item.url or 'нет'}\n"
            f"Суть: {item.summary}\n"
            f"Зачем нужно: {item.why_needed}\n"
            f"Теги: {', '.join(item.tags)}\n"
            f"Исходный комментарий: {item.raw_input[:1200]}"
        )
        return await self.llm.chat(
            settings,
            [{"role": "system", "content": instr}, {"role": "user", "content": body}],
            temperature=0.25,
        )

    async def generate_item_review(
        self,
        item: RoutedItemRecord,
        settings: RuntimeSettings,
        *,
        lang: str = "ru",
    ) -> str:
        """Generate a sharp technical pros/cons/risks review of a routed item."""
        instr = (
            f"{settings.system_prompt}\n\n"
            "Provide a sharp Tech Architect Review in ENGLISH: 1) Pros, 2) Cons & Limitations, 3) Alternatives, 4) Verdict (when to adopt vs skip)."
            if lang == "en"
            else f"{settings.system_prompt}\n\n"
            "Дай жёсткий разбор технического архитектора на РУССКОМ языке: 1) Плюсы, 2) Минусы и ограничения, 3) Альтернативы, 4) Вердикт (когда брать, а когда нет)."
        )
        body = (
            f"Материал: {item.title} ({item.url or item.item_kind})\n"
            f"Описание: {item.summary}\n"
            f"Польза: {item.why_needed}"
        )
        return await self.llm.chat(
            settings,
            [{"role": "system", "content": instr}, {"role": "user", "content": body}],
            temperature=0.25,
        )

    async def compare_urls(
        self,
        url1: str,
        url2: str,
        settings: RuntimeSettings,
        *,
        lang: str = "ru",
    ) -> str:
        """Fetch two URLs/repos/videos concurrently from the sandbox and compare them."""
        if not settings.sandbox_internet_enabled:
            return (
                "⛔ Sandbox internet access is disabled by admin."
                if lang == "en"
                else "⛔ Выход в интернет из песочницы отключён администратором."
            )
        txt1, txt2 = await asyncio.gather(
            self._inspect_url_text(url1, settings, max_chars=5000),
            self._inspect_url_text(url2, settings, max_chars=5000),
        )
        instr = (
            f"{settings.system_prompt}\n\n"
            "Compare these two resources in ENGLISH: 1) Core purpose & stack, 2) Key differences, 3) Pros/Cons of each, 4) Recommendation on which to choose."
            if lang == "en"
            else f"{settings.system_prompt}\n\n"
            "Сравни эти два ресурса на РУССКОМ языке: 1) Суть и стек, 2) Ключевые отличия, 3) Плюсы и минусы каждого, 4) Что выбрать под разные сценарии."
        )
        return await self.llm.chat(
            settings,
            [
                {"role": "system", "content": instr},
                {"role": "user", "content": f"=== Вариант 1 ({url1}) ===\n{txt1}\n\n=== Вариант 2 ({url2}) ===\n{txt2}"},
            ],
            temperature=0.2,
        )

    @staticmethod
    def format_search_results_html(query: str, items: list[RoutedItemRecord], lang: str = "ru") -> str:
        if not items:
            return (
                f"🔎 Nothing found in the knowledge base for <b>{html.escape(query)}</b>."
                if lang == "en"
                else f"🔎 По запросу <b>{html.escape(query)}</b> в базе знаний пока ничего не найдено."
            )

        header = (
            f"🔎 <b>Knowledge Base matches («{html.escape(query)}»):</b>"
            if lang == "en"
            else f"🔎 <b>Результаты поиска по базе знаний («{html.escape(query)}»):</b>"
        )
        lines = [header, ""]
        for idx, it in enumerate(items, start=1):
            link = build_topic_message_link(it.chat_id, it.target_message_id, it.target_thread_id)
            title = html.escape(it.title)
            topic = html.escape(it.target_topic_name)
            summary = html.escape(it.summary[:160]) + ("…" if len(it.summary) > 160 else "")
            if link:
                lines.append(f'{idx}. <a href="{html.escape(link)}"><b>{title}</b></a> → <i>{topic}</i>')
            else:
                lines.append(f"{idx}. <b>{title}</b> → <i>{topic}</i>")
            lines.append(f"   {summary}")
            if it.url:
                lines.append(f"   🌐 {html.escape(it.url)}")
        return "\n".join(lines)[:4000]

    async def build_index_html(self, chat_id: int, lang: str = "ru") -> str:
        topics = await self.db.list_topics(chat_id, include_inbox=True)
        items = await self.db.list_routed_items(chat_id, limit=200)
        by_thread: dict[int, list[RoutedItemRecord]] = {}
        for it in items:
            by_thread.setdefault(it.target_thread_id, []).append(it)

        if not topics:
            return (
                "📚 No topics tracked yet. Run /setup first."
                if lang == "en"
                else "📚 Ветки пока не зарегистрированы. Запустите /setup."
            )

        title = "🧭 <b>Навигатор по веткам группы</b>" if lang != "en" else "🧭 <b>Group Topics Directory</b>"
        lines = [title, ""]
        for tp in topics:
            link = build_topic_message_link(chat_id, None, tp.thread_id)
            name_html = (
                f'<a href="{html.escape(link)}"><b>{html.escape(tp.name)}</b></a>'
                if link
                else f"<b>{html.escape(tp.name)}</b>"
            )
            if tp.is_inbox:
                hint = (
                    "Drop links, repos, and files here for auto-routing"
                    if lang == "en"
                    else "Сюда кидаем ссылки, репо и файлы для авто-разбора"
                )
                lines.append(f"📥 {name_html} — <i>{hint}</i>")
                continue

            tp_items = by_thread.get(tp.thread_id, [])
            count_word = f"{len(tp_items)} items" if lang == "en" else f"материалов: {len(tp_items)}"
            desc = f" — {html.escape(tp.description)}" if tp.description else ""
            lines.append(f"💬 {name_html} (<i>{count_word}</i>){desc}")
            for recent in tp_items[:2]:
                r_link = build_topic_message_link(chat_id, recent.target_message_id, tp.thread_id)
                r_title = html.escape(recent.title[:70])
                if r_link:
                    lines.append(f'   • <a href="{html.escape(r_link)}">{r_title}</a>')
                else:
                    lines.append(f"   • {r_title}")

        total_lbl = f"Total archived: {len(items)}" if lang == "en" else f"Всего в базе знаний: {len(items)}"
        lines.append(f"\n📌 <i>{total_lbl}</i>")
        return "\n".join(lines)[:4000]

    async def build_export_markdown(self, chat_id: int, chat_title: str, lang: str = "ru") -> str:
        topics = await self.db.list_topics(chat_id, include_inbox=False)
        items = await self.db.list_routed_items(chat_id, limit=500)
        by_thread: dict[int, list[RoutedItemRecord]] = {}
        for it in items:
            by_thread.setdefault(it.target_thread_id, []).append(it)

        header = (
            f"# Knowledge Base: {chat_title or chat_id}\n\n"
            if lang == "en"
            else f"# База знаний группы: {chat_title or chat_id}\n\n"
        )
        sections = [header]
        if not items:
            sections.append("_Empty / Пока пусто._\n")
            return "".join(sections)

        seen_threads: set[int] = set()
        for tp in topics:
            tp_items = by_thread.get(tp.thread_id, [])
            if not tp_items:
                continue
            seen_threads.add(tp.thread_id)
            sections.append(f"## {tp.name}\n")
            if tp.description:
                sections.append(f"_{tp.description}_\n\n")
            for it in tp_items:
                sections.append(self._format_export_item_md(it, lang))

        # Include any items whose topic isn't in topics table
        for tid, tp_items in by_thread.items():
            if tid in seen_threads:
                continue
            sections.append(f"## {tp_items[0].target_topic_name}\n")
            for it in tp_items:
                sections.append(self._format_export_item_md(it, lang))

        return "\n".join(sections)

    @staticmethod
    def _format_export_item_md(it: RoutedItemRecord, lang: str) -> str:
        tags = " ".join(f"`#{t}`" for t in it.tags)
        lines = [f"### {it.title}"]
        if it.url:
            lines.append(f"- **URL**: {it.url}")
        lines.append(f"- **Author**: {it.author_name} ({it.created_at})")
        lines.append(f"- **{'Summary' if lang == 'en' else 'Что это'}**: {it.summary}")
        if it.why_needed:
            lines.append(f"- **{'Why needed' if lang == 'en' else 'Зачем нужно'}**: {it.why_needed}")
        if tags:
            lines.append(f"- **Tags**: {tags}")
        lines.append("")
        return "\n".join(lines)

    @staticmethod
    def _looks_like_web_query(text: str) -> bool:
        low = text.lower()
        triggers = (
            "найди в интернете",
            "поищи",
            "загугли",
            "свеж",
            "последняя версия",
            "актуальн",
            "новости",
            "документация",
            "что такое ",
            "как установить",
            "сравни ",
            "search ",
        )
        return any(t in low for t in triggers)
