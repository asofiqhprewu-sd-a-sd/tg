"""Telegram Bot (aiogram 3) package."""
