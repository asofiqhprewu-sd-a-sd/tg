from __future__ import annotations

import html
import re
from dataclasses import dataclass

from aiogram import Bot

from app.config import StaticConfig
from app.db import Database
from app.llm.client import OpenAICompatibleClient
from app.models import UserBanRecord
from app.sandbox.files import FileSandbox
from app.sandbox.github import RepoInspector
from app.sandbox.net import SandboxHttpClient
from app.services.analyzer import InboxAnalyzer
from app.services.assistant import AssistantService
from app.services.router import TopicRouterService

DURATION_RE = re.compile(r"^(\d+)\s*(s|sec|m|min|h|hr|d|day|w|м|мин|ч|д|с)?$", re.IGNORECASE)


@dataclass
class AppContext:
    static_cfg: StaticConfig
    db: Database
    llm: OpenAICompatibleClient
    http: SandboxHttpClient
    repos: RepoInspector
    files: FileSandbox
    analyzer: InboxAnalyzer
    router_svc: TopicRouterService
    assistant: AssistantService
    bot_username: str = ""
    bot_id: int = 0


def parse_duration_seconds(spec: str) -> int | None:
    """Parse duration like '30m', '2h', '7d', '45s', or bare integer minutes ('15')."""
    m = DURATION_RE.match((spec or "").strip())
    if not m:
        return None
    val = int(m.group(1))
    if val <= 0:
        return None
    unit = (m.group(2) or "m").lower()
    if unit in {"s", "sec", "с"}:
        return val
    if unit in {"m", "min", "м", "мин"}:
        return val * 60
    if unit in {"h", "hr", "ч"}:
        return val * 3600
    if unit in {"d", "day", "д"}:
        return val * 86400
    if unit == "w":
        return val * 604800
    return None


def format_ban_notice(ban: UserBanRecord, lang: str = "ru") -> str:
    reason = f"\nПричина: {html.escape(ban.reason)}" if (ban.reason and lang != "en") else (
        f"\nReason: {html.escape(ban.reason)}" if ban.reason else ""
    )
    if ban.expires_at:
        if lang == "en":
            return f"⛔ You are temporarily banned from using this bot until <code>{ban.expires_at}</code>.{reason}"
        return f"⛔ Доступ к боту временно ограничен до <code>{ban.expires_at}</code>.{reason}"
    if lang == "en":
        return f"⛔ You are banned from using this bot.{reason}"
    return f"⛔ Вам заблокирован доступ к боту.{reason}"


async def is_user_admin(
    bot: Bot,
    chat_id: int,
    chat_type: str,
    user_id: int,
    static_cfg: StaticConfig,
    db: Database | None = None,
) -> bool:
    if user_id in static_cfg.admin_user_ids:
        return True
    if db is not None:
        role = await db.get_bot_admin_role(user_id)
        if role == "granted":
            return True
        if role == "revoked":
            return False
    if chat_type in {"group", "supergroup"}:
        try:
            member = await bot.get_chat_member(chat_id, user_id)
            return member.status in {"creator", "administrator"}
        except Exception:
            return False
    return False
