from __future__ import annotations

import html

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import CallbackQuery, ChatMemberUpdated, Message

from app.bot.context import AppContext, is_user_admin
from app.bot.keyboards import language_select_keyboard
from app.i18n import normalize_lang, t

router = Router(name="common")


async def _build_welcome_text(message: Message, ctx: AppContext, lang: str) -> str:
    if message.chat.type == "private":
        uid = message.from_user.id if message.from_user else 0
        return t(lang, "welcome_private", uid=uid)

    if message.chat.is_forum:
        settings = await ctx.db.get_settings()
        res = await ctx.router_svc.ensure_inbox_topic(
            message.bot,  # type: ignore[arg-type]
            message.chat.id,
            message.chat.title or "",
            settings,
            lang=lang,
        )
        inbox_status = (
            t(lang, "inbox_active", name=html.escape(res.topic.name))
            if res.ok and res.topic
            else f"⚠️ {html.escape(res.error)}"
        )
    else:
        inbox_status = t(lang, "topics_disabled")

    return t(lang, "welcome_group", inbox_status=inbox_status)


@router.my_chat_member()
async def on_bot_membership_update(event: ChatMemberUpdated, ctx: AppContext) -> None:
    """Automatically creates Inbox topic when the bot joins or becomes admin in a forum group."""
    if event.chat.type not in {"group", "supergroup"}:
        return
    new_status = event.new_chat_member.status
    if new_status not in {"member", "administrator"}:
        return

    await ctx.db.upsert_chat(event.chat.id, event.chat.title or "", bool(event.chat.is_forum))
    if not event.chat.is_forum or new_status != "administrator":
        return

    settings = await ctx.db.get_settings()
    lang = await ctx.db.get_effective_language(event.chat.id)
    res = await ctx.router_svc.ensure_inbox_topic(
        event.bot,  # type: ignore[arg-type]
        event.chat.id,
        event.chat.title or "",
        settings,
        lang=lang,
    )
    if not res.ok and res.error:
        try:
            await event.bot.send_message(event.chat.id, res.error)
        except Exception:
            pass


@router.message(Command("start", "lang"))
async def cmd_start(message: Message, ctx: AppContext) -> None:
    """Ask user to choose RU / EN language right after /start (or /lang)."""
    await message.reply(
        t("ru", "choose_lang"),
        reply_markup=language_select_keyboard(),
    )


@router.callback_query(F.data.startswith("lang:set:"))
async def on_language_selected(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.data or not cb.from_user:
        return
    chosen = normalize_lang(cb.data.split(":")[2])
    msg = cb.message

    if msg.chat.type in {"group", "supergroup"}:
        is_adm = await is_user_admin(
            cb.bot,  # type: ignore[arg-type]
            msg.chat.id,
            msg.chat.type,
            cb.from_user.id,
            ctx.static_cfg,
            ctx.db,
        )
        if not is_adm:
            await cb.answer(t(chosen, "lang_admin_only"), show_alert=True)
            return
        await ctx.db.set_chat_language(
            msg.chat.id,
            chosen,
            title=msg.chat.title or "",
            is_forum=bool(msg.chat.is_forum),
        )
    else:
        await ctx.db.set_chat_language(msg.chat.id, chosen, title="DM", is_forum=False)
        # Also sync global default language when admin changes it in DM
        if cb.from_user.id in ctx.static_cfg.admin_user_ids or not ctx.static_cfg.admin_user_ids:
            await ctx.db.update_settings({"language": chosen})

    await cb.answer("OK")
    welcome_body = await _build_welcome_text(msg, ctx, chosen)
    # Preserve user ID in DM welcome since cb.message.from_user is the bot
    if msg.chat.type == "private":
        welcome_body = t(chosen, "welcome_private", uid=cb.from_user.id)

    await msg.edit_text(
        f"{t(chosen, 'lang_updated')}\n\n{welcome_body}",
        parse_mode="HTML",
        reply_markup=language_select_keyboard(),
    )


@router.message(Command("help"))
async def cmd_help(message: Message, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    text = await _build_welcome_text(message, ctx, lang)
    await message.reply(text, parse_mode="HTML")


@router.message(Command("setup", "inbox"))
async def cmd_setup(message: Message, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply(
            "Run /setup inside a supergroup with Topics enabled."
            if lang == "en"
            else "Команду /setup нужно запускать внутри супергруппы с включёнными ветками (Topics)."
        )
        return

    if not message.chat.is_forum:
        await message.reply(t(lang, "topics_disabled"), parse_mode="HTML")
        return

    settings = await ctx.db.get_settings()
    res = await ctx.router_svc.ensure_inbox_topic(
        message.bot,  # type: ignore[arg-type]
        message.chat.id,
        message.chat.title or "",
        settings,
        lang=lang,
    )
    if res.ok and res.topic:
        if lang == "en":
            verb = "created" if res.created else "already active"
            await message.reply(
                f"✅ Topic <b>«{html.escape(res.topic.name)}»</b> is {verb} (thread_id=<code>{res.topic.thread_id}</code>).\n"
                "Members can now drop links, repositories, files, and notes there!",
                parse_mode="HTML",
            )
        else:
            verb = "создана" if res.created else "уже активна"
            await message.reply(
                f"✅ Ветка <b>«{html.escape(res.topic.name)}»</b> {verb} (thread_id=<code>{res.topic.thread_id}</code>).\n"
                "Участники могут отправлять туда ссылки, репозитории, файлы и заметки!",
                parse_mode="HTML",
            )
    else:
        await message.reply(f"❌ {html.escape(res.error)}", parse_mode="HTML")


@router.message(Command("topics"))
async def cmd_topics(message: Message, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply("Available in group chats." if lang == "en" else "Команда работает в группе.")
        return

    topics = await ctx.db.list_topics(message.chat.id, include_inbox=True)
    if not topics:
        await message.reply(
            "No topics tracked yet. Run /setup or /register_topic inside a topic."
            if lang == "en"
            else "Ветки ещё не зарегистрированы. Вызовите /setup или напишите /register_topic внутри нужной ветки."
        )
        return

    header = "🗂 <b>Tracked topics:</b>" if lang == "en" else "🗂 <b>Известные ветки группы:</b>"
    lines = [header, ""]
    for topic in topics:
        inbox_tag = "📥 [Inbox]" if lang == "en" else "📥 [Входящие]"
        closed_tag = "🔒 [Closed]" if lang == "en" else "🔒 [Закрыта]"
        badge = inbox_tag if topic.is_inbox else (closed_tag if topic.is_closed else "💬")
        desc = f" — {html.escape(topic.description)}" if topic.description else ""
        lines.append(f"{badge} <b>{html.escape(topic.name)}</b> (<code>{topic.thread_id}</code>){desc}")

    hint = (
        "\n💡 To name or describe a topic, run inside it: <code>/register_topic Name | description</code>"
        if lang == "en"
        else "\n💡 Чтобы переименовать или описать ветку, напишите в ней: <code>/register_topic Название | описание</code>"
    )
    lines.append(hint)
    await message.reply("\n".join(lines)[:4000], parse_mode="HTML")


@router.message(Command("register_topic"))
async def cmd_register_topic(message: Message, command: CommandObject, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"} or not message.from_user:
        return
    if not await is_user_admin(message.bot, message.chat.id, message.chat.type, message.from_user.id, ctx.static_cfg, ctx.db):  # type: ignore[arg-type]
        await message.reply(
            "⛔ Admin only." if lang == "en" else "⛔ Только администратор может регистрировать и описывать ветки."
        )
        return

    thread_id = message.message_thread_id
    if not thread_id:
        await message.reply(
            "Send this command inside a forum topic."
            if lang == "en"
            else "Эту команду нужно отправить внутри конкретной ветки (топика)."
        )
        return

    args = (command.args or "").strip()
    if not args:
        await message.reply(
            "Usage: <code>/register_topic Name | short description</code>"
            if lang == "en"
            else "Использование: <code>/register_topic Название | краткое описание</code>",
            parse_mode="HTML",
        )
        return

    if "|" in args:
        name_part, desc_part = args.split("|", 1)
    else:
        name_part, desc_part = args, ""

    topic_name = name_part.strip()[:120]
    topic_desc = desc_part.strip()[:300]
    if not topic_name:
        await message.reply("Specify a non-empty topic name." if lang == "en" else "Укажите непустое название ветки.")
        return

    topic = await ctx.db.upsert_topic(
        message.chat.id,
        thread_id,
        topic_name,
        description=topic_desc,
    )
    saved_msg = (
        f"✅ Topic saved: <b>{html.escape(topic.name)}</b> (<code>{topic.thread_id}</code>)"
        if lang == "en"
        else f"✅ Ветка сохранена: <b>{html.escape(topic.name)}</b> (<code>{topic.thread_id}</code>)"
    )
    await message.reply(
        saved_msg + (f"\nDescription: {html.escape(topic.description)}" if topic.description else ""),
        parse_mode="HTML",
    )
