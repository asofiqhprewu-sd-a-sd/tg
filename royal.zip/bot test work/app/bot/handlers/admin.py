from __future__ import annotations

import html

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, ForceReply, Message

from app.bot.context import AppContext, is_user_admin, parse_duration_seconds
from app.bot.keyboards import (
    admin_bans_keyboard,
    admin_main_keyboard,
    admin_model_keyboard,
    admin_sandbox_keyboard,
    admin_topics_keyboard,
)
from app.config import RuntimeSettings
from app.models import UserBanRecord

router = Router(name="admin")


class AdminFSM(StatesGroup):
    waiting_system_prompt = State()
    waiting_api_key = State()
    waiting_base_url = State()
    waiting_model = State()
    waiting_new_topic_name = State()
    waiting_ban_perm = State()
    waiting_ban_temp = State()


def _mask_secret(secret: str) -> str:
    s = (secret or "").strip()
    if not s or s.startswith("sk-replace"):
        return "не задан"
    if len(s) <= 8:
        return "****"
    return f"{s[:4]}...{s[-4:]}"


def _admin_summary_html(settings: RuntimeSettings, lang: str = "ru") -> str:
    prompt_preview = html.escape(settings.system_prompt[:220])
    if len(settings.system_prompt) > 220:
        prompt_preview += "…"
    if lang == "en":
        return (
            "🛠 <b>Admin Panel</b>\n\n"
            f"🧠 <b>Model:</b> <code>{html.escape(settings.openai_model)}</code>\n"
            f"🌐 <b>Base URL:</b> <code>{html.escape(settings.openai_base_url)}</code>\n"
            f"🔑 <b>API Key:</b> <code>{_mask_secret(settings.openai_api_key)}</code>\n"
            f"🛡 <b>Sandbox Internet:</b> {'ON' if settings.sandbox_internet_enabled else 'OFF'}\n"
            f"🗂 <b>Auto-Create Topics:</b> {'ON' if settings.auto_create_topics else 'OFF'}\n\n"
            f"📝 <b>Current System Prompt:</b>\n<blockquote>{prompt_preview}</blockquote>"
        )
    return (
        "🛠 <b>Панель администратора</b>\n\n"
        f"🧠 <b>Модель:</b> <code>{html.escape(settings.openai_model)}</code>\n"
        f"🌐 <b>Base URL:</b> <code>{html.escape(settings.openai_base_url)}</code>\n"
        f"🔑 <b>API Key:</b> <code>{_mask_secret(settings.openai_api_key)}</code>\n"
        f"🛡 <b>Интернет из песочницы:</b> {'ВКЛ' if settings.sandbox_internet_enabled else 'ВЫКЛ'}\n"
        f"🗂 <b>Автосоздание веток:</b> {'ВКЛ' if settings.auto_create_topics else 'ВЫКЛ'}\n\n"
        f"📝 <b>Текущий системник:</b>\n<blockquote>{prompt_preview}</blockquote>"
    )


async def _deny_non_admin(message: Message, ctx: AppContext) -> bool:
    if not message.from_user:
        return True
    allowed = await is_user_admin(
        message.bot,  # type: ignore[arg-type]
        message.chat.id,
        message.chat.type,
        message.from_user.id,
        ctx.static_cfg,
        ctx.db,
    )
    if allowed:
        return False

    if message.chat.type == "private":
        await message.reply(
            "⛔ У вас нет прав глобального администратора.\n"
            f"Добавьте свой ID <code>{message.from_user.id}</code> в <code>ADMIN_USER_IDS</code> в <code>.env</code> "
            "или откройте <code>/admin</code> внутри группы с правами администратора.",
            parse_mode="HTML",
        )
    else:
        await message.reply("⛔ Эта команда доступна только администраторам группы.")
    return True


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    cur = await state.get_state()
    if cur is None:
        return
    await state.clear()
    await message.reply("✖️ Действие отменено.")


@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    await state.clear()
    settings = await ctx.db.get_settings()
    lang = await ctx.db.get_effective_language(message.chat.id)
    await message.reply(
        _admin_summary_html(settings, lang),
        parse_mode="HTML",
        reply_markup=admin_main_keyboard(settings, lang),
    )


@router.message(Command("system"))
async def cmd_system(message: Message, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    settings = await ctx.db.get_settings()
    parts = [f"📝 <b>Глобальный системник:</b>\n<pre>{html.escape(settings.system_prompt[:3400])}</pre>"]
    if message.chat.type in {"group", "supergroup"} and message.message_thread_id:
        topic = await ctx.db.get_topic(message.chat.id, message.message_thread_id)
        if topic and topic.system_prompt:
            parts.append(
                f"📌 <b>Системник ветки «{html.escape(topic.name)}»:</b>\n"
                f"<pre>{html.escape(topic.system_prompt[:1000])}</pre>"
            )
    await message.reply("\n\n".join(parts)[:4000], parse_mode="HTML")


@router.message(Command("set_system"))
async def cmd_set_system(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    new_prompt = (command.args or "").strip()
    if not new_prompt and message.reply_to_message:
        new_prompt = (message.reply_to_message.text or message.reply_to_message.caption or "").strip()

    if not new_prompt:
        await message.reply(
            "Использование: <code>/set_system Новый системный промпт</code> (или ответом на сообщение).",
            parse_mode="HTML",
        )
        return

    await ctx.db.update_settings({"system_prompt": new_prompt})
    await message.reply(
        f"✅ <b>Системник обновлён!</b> ({len(new_prompt)} симв.)\n\n"
        f"<blockquote>{html.escape(new_prompt[:600])}</blockquote>",
        parse_mode="HTML",
    )


@router.message(Command("set_topic_system"))
async def cmd_set_topic_system(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    if message.chat.type not in {"group", "supergroup"} or not message.message_thread_id:
        await message.reply("Запустите команду внутри нужной ветки группы.")
        return

    val = (command.args or "").strip()
    if not val:
        await message.reply(
            "Использование: <code>/set_topic_system Инструкция для этой ветки</code> (или <code>clear</code> для сброса).",
            parse_mode="HTML",
        )
        return

    if val.lower() in {"clear", "reset", "off", "сброс"}:
        val = ""

    topic = await ctx.db.update_topic_meta(message.chat.id, message.message_thread_id, system_prompt=val)
    if topic is None:
        topic = await ctx.db.upsert_topic(
            message.chat.id,
            message.message_thread_id,
            f"Ветка #{message.message_thread_id}",
            system_prompt=val,
        )
    if val:
        await message.reply(f"✅ Для ветки «{html.escape(topic.name)}» задан локальный системник.", parse_mode="HTML")
    else:
        await message.reply(f"✅ Локальный системник для ветки «{html.escape(topic.name)}» очищен.", parse_mode="HTML")


@router.message(Command("set_model"))
async def cmd_set_model(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    args = (command.args or "").strip().split()
    if not args:
        await message.reply("Использование: <code>/set_model model_name [base_url]</code>", parse_mode="HTML")
        return
    updates = {"openai_model": args[0]}
    if len(args) > 1:
        updates["openai_base_url"] = args[1].rstrip("/")
    settings = await ctx.db.update_settings(updates)
    await message.reply(
        f"✅ Модель обновлена: <code>{html.escape(settings.openai_model)}</code>\n"
        f"Base URL: <code>{html.escape(settings.openai_base_url)}</code>",
        parse_mode="HTML",
    )


@router.message(Command("test_model"))
async def cmd_test_model(message: Message, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    wait_msg = await message.reply("⏳ Проверяю соединение с OpenAI-compatible моделью...")
    settings = await ctx.db.get_settings()
    res = await ctx.llm.test_connection(settings)
    if res.ok:
        await wait_msg.edit_text(
            f"✅ <b>Модель отвечает!</b>\n"
            f"Модель: <code>{html.escape(res.model)}</code>\n"
            f"Задержка: {res.latency_ms} мс\n"
            f"Ответ: <code>{html.escape(res.reply_preview)}</code>",
            parse_mode="HTML",
        )
    else:
        await wait_msg.edit_text(
            f"❌ <b>Ошибка соединения с моделью:</b>\n"
            f"<code>{html.escape(res.error)}</code>",
            parse_mode="HTML",
        )


async def _run_sandbox_self_test(ctx: AppContext, target_url: str, lang: str) -> str:
    settings = await ctx.db.get_settings()
    page = await ctx.http.fetch_webpage(target_url, settings, max_text_chars=300)
    ssrf_blocked = False
    ssrf_detail = ""
    try:
        await ctx.http.fetch_raw("http://127.0.0.1:80/", settings, max_bytes=1024)
    except Exception as exc:
        ssrf_blocked = True
        ssrf_detail = str(exc)

    if lang == "en":
        inet_line = (
            f"✅ Public Internet OK: <code>{html.escape(page.final_url)}</code> (HTTP {page.status})\n"
            f"Preview: <code>{html.escape((page.title or page.text)[:140])}</code>"
            if not page.error
            else f"❌ Public Internet failed: <code>{html.escape(page.error)}</code>"
        )
        ssrf_line = (
            f"🛡 SSRF Guard OK (127.0.0.1 blocked): <code>{html.escape(ssrf_detail[:120])}</code>"
            if ssrf_blocked
            else "⚠️ SSRF Guard did NOT block 127.0.0.1"
        )
        return f"🧪 <b>Sandbox Self-Test</b>\n\n{inet_line}\n\n{ssrf_line}"

    inet_line = (
        f"✅ Выход в интернет работает: <code>{html.escape(page.final_url)}</code> (HTTP {page.status})\n"
        f"Ответ: <code>{html.escape((page.title or page.text)[:140])}</code>"
        if not page.error
        else f"❌ Ошибка выхода в интернет: <code>{html.escape(page.error)}</code>"
    )
    ssrf_line = (
        f"🛡 SSRF-защита работает (127.0.0.1 заблокирован): <code>{html.escape(ssrf_detail[:120])}</code>"
        if ssrf_blocked
        else "⚠️ Внимание: 127.0.0.1 не был заблокирован"
    )
    return f"🧪 <b>Проверка песочницы и интернета</b>\n\n{inet_line}\n\n{ssrf_line}"


@router.message(Command("test_net"))
async def cmd_test_net(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    lang = await ctx.db.get_effective_language(message.chat.id)
    target = (command.args or "").strip() or "https://api.github.com/zen"
    wait_msg = await message.reply("⏳ Проверяю выход в интернет из песочницы..." if lang != "en" else "⏳ Testing sandbox internet...")
    report = await _run_sandbox_self_test(ctx, target, lang)
    await wait_msg.edit_text(report, parse_mode="HTML", disable_web_page_preview=True)


async def _resolve_ban_target(ctx: AppContext, message: Message, token: str) -> tuple[int, str] | None:
    clean = token.strip()
    if clean.lstrip("-").isdigit():
        uid = int(clean)
        users = await ctx.db.list_known_users(limit=200)
        matched = next((u for u in users if u.user_id == uid), None)
        label = (matched.full_name or (f"@{matched.username}" if matched.username else "")) if matched else ""
        return uid, label or str(uid)
    if clean.startswith("@"):
        found = await ctx.db.find_user_by_username(clean)
        if found:
            return found.user_id, found.full_name or f"@{found.username}"
    if message.reply_to_message and message.reply_to_message.from_user:
        u = message.reply_to_message.from_user
        return u.id, u.full_name or (f"@{u.username}" if u.username else str(u.id))
    return None


def _format_bans_html(bans: list[UserBanRecord], lang: str = "ru") -> str:
    if not bans:
        return (
            "🚫 <b>User Bans</b>\n\nNo active bans."
            if lang == "en"
            else "🚫 <b>Блокировки пользователей</b>\n\nАктивных блокировок нет."
        )
    header = "🚫 <b>Active User Bans:</b>" if lang == "en" else "🚫 <b>Активные блокировки:</b>"
    lines = [header, ""]
    for b in bans[:15]:
        name = html.escape(b.author_name or str(b.user_id))
        dur = (
            f"until <code>{b.expires_at}</code>"
            if (b.expires_at and lang == "en")
            else (f"до <code>{b.expires_at}</code>" if b.expires_at else ("permanent" if lang == "en" else "навсегда"))
        )
        reason = f" — {html.escape(b.reason)}" if b.reason else ""
        lines.append(f"• <b>{name}</b> (<code>{b.user_id}</code>) [{dur}]{reason}")
    return "\n".join(lines)[:3900]


@router.message(Command("bans"))
async def cmd_bans(message: Message, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    lang = await ctx.db.get_effective_language(message.chat.id)
    scope = message.chat.id if message.chat.type in {"group", "supergroup"} else None
    bans = await ctx.db.list_active_bans(scope)
    await message.reply(
        _format_bans_html(bans, lang),
        parse_mode="HTML",
        reply_markup=admin_bans_keyboard(bans, lang),
    )


@router.message(Command("ban"))
async def cmd_ban(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    lang = await ctx.db.get_effective_language(message.chat.id)
    args = (command.args or "").strip()
    parts = args.split(maxsplit=1) if args else []
    target = None
    reason = ""
    if parts:
        target = await _resolve_ban_target(ctx, message, parts[0])
        if target is not None:
            reason = parts[1].strip() if len(parts) > 1 else ""
        elif message.reply_to_message and message.reply_to_message.from_user:
            u = message.reply_to_message.from_user
            target = (u.id, u.full_name or str(u.id))
            reason = args
    elif message.reply_to_message and message.reply_to_message.from_user:
        u = message.reply_to_message.from_user
        target = (u.id, u.full_name or str(u.id))

    if target is None:
        await message.reply(
            "Usage: <code>/ban user_id [reason]</code> or reply to user."
            if lang == "en"
            else "Использование: <code>/ban user_id [причина]</code> или ответом на сообщение пользователя.",
            parse_mode="HTML",
        )
        return

    uid, uname = target
    scope_chat = message.chat.id if message.chat.type in {"group", "supergroup"} else 0
    await ctx.db.ban_user(
        chat_id=scope_chat,
        user_id=uid,
        author_name=uname,
        reason=reason,
        banned_by=message.from_user.id if message.from_user else 0,
        duration_seconds=None,
    )
    await message.reply(
        f"🔨 Заблокирован навсегда: <b>{html.escape(uname)}</b> (<code>{uid}</code>)"
        + (f"\nПричина: {html.escape(reason)}" if reason else ""),
        parse_mode="HTML",
    )


@router.message(Command("tempban"))
async def cmd_tempban(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    lang = await ctx.db.get_effective_language(message.chat.id)
    args = (command.args or "").strip()
    tokens = args.split()
    target: tuple[int, str] | None = None
    duration_sec: int | None = None
    reason = ""

    if len(tokens) >= 2:
        target = await _resolve_ban_target(ctx, message, tokens[0])
        if target is not None:
            duration_sec = parse_duration_seconds(tokens[1])
            reason = " ".join(tokens[2:])
    if target is None and len(tokens) >= 1 and message.reply_to_message and message.reply_to_message.from_user:
        duration_sec = parse_duration_seconds(tokens[0])
        if duration_sec is not None:
            u = message.reply_to_message.from_user
            target = (u.id, u.full_name or str(u.id))
            reason = " ".join(tokens[1:])

    if target is None or duration_sec is None:
        await message.reply(
            "Usage: <code>/tempban user_id 30m [reason]</code> (supports m, h, d) or reply <code>/tempban 1h</code>."
            if lang == "en"
            else "Использование: <code>/tempban user_id 30m [причина]</code> (m/h/d) или реплаем <code>/tempban 1h</code>.",
            parse_mode="HTML",
        )
        return

    uid, uname = target
    scope_chat = message.chat.id if message.chat.type in {"group", "supergroup"} else 0
    ban = await ctx.db.ban_user(
        chat_id=scope_chat,
        user_id=uid,
        author_name=uname,
        reason=reason,
        banned_by=message.from_user.id if message.from_user else 0,
        duration_seconds=duration_sec,
    )
    await message.reply(
        f"⏳ Временно заблокирован до <code>{ban.expires_at}</code>: <b>{html.escape(uname)}</b> (<code>{uid}</code>)"
        + (f"\nПричина: {html.escape(reason)}" if reason else ""),
        parse_mode="HTML",
    )


@router.message(Command("unban"))
async def cmd_unban(message: Message, command: CommandObject, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    args = (command.args or "").strip()
    token = args.split()[0] if args else ""
    target = await _resolve_ban_target(ctx, message, token)
    if target is None:
        await message.reply(
            "Использование: <code>/unban user_id</code> (или реплаем на сообщение).",
            parse_mode="HTML",
        )
        return
    uid, uname = target
    scope_chat = message.chat.id if message.chat.type in {"group", "supergroup"} else 0
    removed = await ctx.db.unban_user(scope_chat, uid)
    if removed:
        await message.reply(f"✅ Разблокирован: <b>{html.escape(uname)}</b> (<code>{uid}</code>)", parse_mode="HTML")
    else:
        await message.reply(f"Пользователь <code>{uid}</code> не найден в списке банов.", parse_mode="HTML")


# --- Admin Inline Callbacks ---


async def _check_cb_admin(cb: CallbackQuery, ctx: AppContext) -> bool:
    if not cb.message or not cb.from_user:
        return False
    allowed = await is_user_admin(
        cb.bot,  # type: ignore[arg-type]
        cb.message.chat.id,
        cb.message.chat.type,
        cb.from_user.id,
        ctx.static_cfg,
        ctx.db,
    )
    if not allowed:
        await cb.answer("⛔ Только для администраторов.", show_alert=True)
        return False
    return True


@router.callback_query(F.data.startswith("adm:"))
async def on_admin_callback(cb: CallbackQuery, state: FSMContext, ctx: AppContext) -> None:
    if not await _check_cb_admin(cb, ctx):
        return
    assert cb.message is not None and cb.data is not None
    action = cb.data.split(":", 1)[1]
    settings = await ctx.db.get_settings()
    msg = cb.message
    lang = await ctx.db.get_effective_language(msg.chat.id)

    if action == "tog_lang":
        new_lang = "en" if lang == "ru" else "ru"
        if msg.chat.type in {"group", "supergroup"}:
            await ctx.db.set_chat_language(msg.chat.id, new_lang, title=msg.chat.title or "", is_forum=bool(msg.chat.is_forum))
        else:
            await ctx.db.set_chat_language(msg.chat.id, new_lang, title="DM", is_forum=False)
            await ctx.db.update_settings({"language": new_lang})
        await msg.edit_text(
            _admin_summary_html(settings, new_lang),
            parse_mode="HTML",
            reply_markup=admin_main_keyboard(settings, new_lang),
        )
        await cb.answer("Language: EN" if new_lang == "en" else "Язык: RU")
        return

    if action == "home":
        await state.clear()
        await msg.edit_text(
            _admin_summary_html(settings, lang),
            parse_mode="HTML",
            reply_markup=admin_main_keyboard(settings, lang),
        )
        await cb.answer()
        return

    if action == "show_prompt":
        await cb.answer()
        await msg.answer(
            f"📝 <b>Полный системный промпт:</b>\n<pre>{html.escape(settings.system_prompt[:3800])}</pre>",
            parse_mode="HTML",
        )
        return

    if action == "prompt":
        await state.set_state(AdminFSM.waiting_system_prompt)
        await cb.answer()
        await msg.answer(
            "✏️ Отправьте новый <b>системный промпт (системник)</b> ответом на это сообщение.\n"
            "Для отмены отправьте /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "model":
        await msg.edit_text(
            "🤖 <b>Настройки OpenAI-compatible модели:</b>\n\n"
            f"• Модель: <code>{html.escape(settings.openai_model)}</code>\n"
            f"• Base URL: <code>{html.escape(settings.openai_base_url)}</code>\n"
            f"• API Key: <code>{_mask_secret(settings.openai_api_key)}</code>\n"
            f"• Temperature: <code>{settings.openai_temperature}</code>\n"
            f"• Max Tokens: <code>{settings.openai_max_tokens}</code>",
            parse_mode="HTML",
            reply_markup=admin_model_keyboard(lang),
        )
        await cb.answer()
        return

    if action == "set_key":
        await state.set_state(AdminFSM.waiting_api_key)
        await cb.answer()
        await msg.answer(
            "🔑 Отправьте новый <b>API Key</b> (сообщение постараюсь сразу удалить из чата после сохранения).\n"
            "Отмена: /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "set_url":
        await state.set_state(AdminFSM.waiting_base_url)
        await cb.answer()
        await msg.answer(
            "🌐 Отправьте новый <b>OpenAI-compatible Base URL</b>\n"
            "Примеры:\n"
            "• <code>https://api.openai.com/v1</code>\n"
            "• <code>https://openrouter.ai/api/v1</code>\n"
            "• <code>https://api.deepseek.com/v1</code>\n"
            "• <code>http://localhost:11434/v1</code>\n"
            "Отмена: /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "set_model":
        await state.set_state(AdminFSM.waiting_model)
        await cb.answer()
        await msg.answer(
            "🧠 Отправьте имя модели (например <code>gpt-4o-mini</code>, <code>deepseek-chat</code>, <code>qwen2.5:14b</code>).\n"
            "Отмена: /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "test_model":
        await cb.answer("Проверяю модель...")
        res = await ctx.llm.test_connection(settings)
        if res.ok:
            await msg.answer(
                f"✅ <b>Модель отвечает!</b>\n"
                f"Модель: <code>{html.escape(res.model)}</code> ({res.latency_ms} мс)\n"
                f"Ответ: <code>{html.escape(res.reply_preview)}</code>",
                parse_mode="HTML",
            )
        else:
            await msg.answer(
                f"❌ <b>Модель не ответила:</b>\n<code>{html.escape(res.error)}</code>",
                parse_mode="HTML",
            )
        return

    if action == "sandbox":
        await msg.edit_text(
            "🛡 <b>Политика песочницы и сортировки:</b>\n\n"
            "• <b>Интернет</b> — разрешает боту выходить из песочницы для загрузки ссылок и репозиториев.\n"
            "• <b>Поиск в Q&A</b> — позволяет искать в интернете при ответах в ветках.\n"
            "• <b>Авто-ветки</b> — автоматически создавать новые ветки, если подходящей нет.\n"
            "• <b>Чистить Входящие</b> — удалять исходное сообщение из «Входящих» после переноса в ветку.",
            parse_mode="HTML",
            reply_markup=admin_sandbox_keyboard(settings, lang),
        )
        await cb.answer()
        return

    toggle_map = {
        "tog_inet": ("sandbox_internet_enabled", settings.sandbox_internet_enabled),
        "tog_qa_web": ("web_search_in_qa", settings.web_search_in_qa),
        "tog_auto_topics": ("auto_create_topics", settings.auto_create_topics),
        "tog_del_inbox": ("delete_inbox_after_route", settings.delete_inbox_after_route),
    }
    if action in toggle_map:
        field_name, cur_val = toggle_map[action]
        settings = await ctx.db.update_settings({field_name: not cur_val})
        await msg.edit_reply_markup(reply_markup=admin_sandbox_keyboard(settings, lang))
        await cb.answer("Updated" if lang == "en" else "Настройка обновлена")
        return

    if action == "test_sandbox":
        await cb.answer("Testing sandbox..." if lang == "en" else "Проверяю песочницу...")
        report = await _run_sandbox_self_test(ctx, "https://api.github.com/zen", lang)
        await msg.answer(report, parse_mode="HTML", disable_web_page_preview=True)
        return

    if action == "topics":
        is_group = msg.chat.type in {"group", "supergroup"}
        if is_group:
            topics = await ctx.db.list_topics(msg.chat.id, include_inbox=True)
            t_lines = [
                f"{'📥' if tp.is_inbox else '💬'} <b>{html.escape(tp.name)}</b> (<code>{tp.thread_id}</code>)"
                for tp in topics[:25]
            ]
            t_block = "\n".join(t_lines) if t_lines else ("No topics tracked yet." if lang == "en" else "Пока нет зарегистрированных веток.")
        else:
            t_block = "Open this menu inside a group to manage its topics." if lang == "en" else "Откройте эту секцию внутри группы для управления её ветками."
        await msg.edit_text(
            f"🗂 <b>{'Topics management' if lang == 'en' else 'Управление ветками'}:</b>\n\n{t_block}",
            parse_mode="HTML",
            reply_markup=admin_topics_keyboard(is_group, lang),
        )
        await cb.answer()
        return

    if action == "ensure_inbox":
        if msg.chat.type not in {"group", "supergroup"}:
            await cb.answer("Только для групп", show_alert=True)
            return
        res = await ctx.router_svc.ensure_inbox_topic(
            cb.bot,  # type: ignore[arg-type]
            msg.chat.id,
            msg.chat.title or "",
            settings,
        )
        if res.ok and res.topic:
            await cb.answer(f"Ветка «{res.topic.name}» готова!", show_alert=True)
        else:
            await cb.answer(res.error[:180], show_alert=True)
        return

    if action == "create_topic":
        await state.set_state(AdminFSM.waiting_new_topic_name)
        await cb.answer()
        await msg.answer(
            "➕ Отправьте название новой ветки (можно через `|`, чтобы добавить описание):\n"
            "Пример: <code>⚙️ Backend | Ссылки и архитектура сервера</code>",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "bans":
        scope = msg.chat.id if msg.chat.type in {"group", "supergroup"} else None
        bans = await ctx.db.list_active_bans(scope)
        await msg.edit_text(
            _format_bans_html(bans, lang),
            parse_mode="HTML",
            reply_markup=admin_bans_keyboard(bans, lang),
        )
        await cb.answer()
        return

    if action == "ban_perm":
        await state.set_state(AdminFSM.waiting_ban_perm)
        await cb.answer()
        await msg.answer(
            "🔨 Введите <code>user_id [причина]</code> или <code>@username [причина]</code> для постоянной блокировки.\n"
            "Отмена: /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action == "ban_temp":
        await state.set_state(AdminFSM.waiting_ban_temp)
        await cb.answer()
        await msg.answer(
            "⏳ Введите <code>user_id &lt;длительность&gt; [причина]</code> (например <code>123456 30m спам</code> или <code>123456 2h</code>).\n"
            "Отмена: /cancel.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True),
        )
        return

    if action.startswith("unban:"):
        parts = action.split(":")
        if len(parts) == 3 and parts[1].lstrip("-").isdigit() and parts[2].lstrip("-").isdigit():
            b_chat = int(parts[1])
            b_uid = int(parts[2])
            await ctx.db.unban_user(b_chat, b_uid)
            scope = msg.chat.id if msg.chat.type in {"group", "supergroup"} else None
            bans = await ctx.db.list_active_bans(scope)
            await msg.edit_text(
                _format_bans_html(bans, lang),
                parse_mode="HTML",
                reply_markup=admin_bans_keyboard(bans, lang),
            )
            await cb.answer("✅ Разблокирован")
        return

    if action == "stats":
        chat_filter = msg.chat.id if msg.chat.type in {"group", "supergroup"} else None
        stats = await ctx.db.get_stats(chat_filter)
        bans = await ctx.db.list_active_bans(chat_filter)
        await msg.answer(
            "📊 <b>Статистика:</b>\n"
            f"• Отслеживаемых веток: <b>{stats['topics']}</b>\n"
            f"• Разобрано материалов: <b>{stats['routed_items']}</b>\n"
            f"• Сообщений в памяти веток: <b>{stats['messages']}</b>\n"
            f"• Активных блокировок: <b>{len(bans)}</b>\n\n"
            "🔐 Выдача и отзыв админки доступны локально на ПК через <code>admin_generate.bat</code>.",
            parse_mode="HTML",
        )
        await cb.answer()


# --- Admin FSM Input Handlers ---


@router.message(AdminFSM.waiting_system_prompt, F.text)
async def fsm_set_system_prompt(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    text = (message.text or "").strip()
    await ctx.db.update_settings({"system_prompt": text})
    await state.clear()
    settings = await ctx.db.get_settings()
    await message.reply(
        f"✅ <b>Системник сохранён!</b>\n\n<blockquote>{html.escape(text[:600])}</blockquote>",
        parse_mode="HTML",
        reply_markup=admin_main_keyboard(settings),
    )


@router.message(AdminFSM.waiting_api_key, F.text)
async def fsm_set_api_key(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    key = (message.text or "").strip()
    await ctx.db.update_settings({"openai_api_key": key})
    await state.clear()
    try:
        await message.delete()
    except Exception:
        pass
    await message.answer(
        f"✅ API ключ обновлён (<code>{_mask_secret(key)}</code>).",
        parse_mode="HTML",
        reply_markup=admin_model_keyboard(),
    )


@router.message(AdminFSM.waiting_base_url, F.text)
async def fsm_set_base_url(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    url = (message.text or "").strip().rstrip("/")
    if not url.startswith(("http://", "https://")):
        await message.reply("⚠️ URL должен начинаться с http:// или https://. Попробуйте снова или /cancel.")
        return
    await ctx.db.update_settings({"openai_base_url": url})
    await state.clear()
    await message.reply(
        f"✅ Base URL обновлён: <code>{html.escape(url)}</code>",
        parse_mode="HTML",
        reply_markup=admin_model_keyboard(),
    )


@router.message(AdminFSM.waiting_model, F.text)
async def fsm_set_model(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    model = (message.text or "").strip()
    await ctx.db.update_settings({"openai_model": model})
    await state.clear()
    await message.reply(
        f"✅ Модель обновлена: <code>{html.escape(model)}</code>",
        parse_mode="HTML",
        reply_markup=admin_model_keyboard(),
    )


@router.message(AdminFSM.waiting_new_topic_name, F.text)
async def fsm_create_topic(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    if message.chat.type not in {"group", "supergroup"} or not message.chat.is_forum:
        await state.clear()
        await message.reply("⚠️ Создание веток доступно только в супергруппах с включёнными темами.")
        return
    raw = (message.text or "").strip()
    name_part, desc_part = raw.split("|", 1) if "|" in raw else (raw, "")
    name = name_part.strip()[:120]
    desc = desc_part.strip()[:300]
    await state.clear()
    try:
        tg_topic = await message.bot.create_forum_topic(chat_id=message.chat.id, name=name)  # type: ignore[union-attr]
        topic = await ctx.db.upsert_topic(
            message.chat.id,
            tg_topic.message_thread_id,
            tg_topic.name,
            description=desc,
            created_by_bot=True,
        )
        await message.reply(
            f"✅ Ветка <b>«{html.escape(topic.name)}»</b> создана (<code>{topic.thread_id}</code>).",
            parse_mode="HTML",
        )
    except Exception as exc:
        await message.reply(f"❌ Не удалось создать ветку: {html.escape(str(exc))}", parse_mode="HTML")


@router.message(AdminFSM.waiting_ban_perm, F.text)
async def fsm_ban_perm(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    raw = (message.text or "").strip()
    parts = raw.split(maxsplit=1)
    target = await _resolve_ban_target(ctx, message, parts[0] if parts else "")
    if target is None:
        await message.reply("⚠️ Укажите числовой `user_id` или `@username` (который уже писал боту), либо /cancel.")
        return
    uid, uname = target
    reason = parts[1].strip() if len(parts) > 1 else ""
    scope_chat = message.chat.id if message.chat.type in {"group", "supergroup"} else 0
    await ctx.db.ban_user(
        chat_id=scope_chat,
        user_id=uid,
        author_name=uname,
        reason=reason,
        banned_by=message.from_user.id if message.from_user else 0,
        duration_seconds=None,
    )
    await state.clear()
    lang = await ctx.db.get_effective_language(message.chat.id)
    bans = await ctx.db.list_active_bans(scope_chat if scope_chat else None)
    await message.reply(
        f"🔨 Заблокирован навсегда: <b>{html.escape(uname)}</b> (<code>{uid}</code>)",
        parse_mode="HTML",
        reply_markup=admin_bans_keyboard(bans, lang),
    )


@router.message(AdminFSM.waiting_ban_temp, F.text)
async def fsm_ban_temp(message: Message, state: FSMContext, ctx: AppContext) -> None:
    if await _deny_non_admin(message, ctx):
        return
    raw = (message.text or "").strip()
    tokens = raw.split()
    target = await _resolve_ban_target(ctx, message, tokens[0]) if len(tokens) >= 2 else None
    dur = parse_duration_seconds(tokens[1]) if len(tokens) >= 2 else None
    if target is None or dur is None:
        await message.reply("⚠️ Формат: <code>user_id 30m [причина]</code> (например `123456 2h спам`), либо /cancel.", parse_mode="HTML")
        return
    uid, uname = target
    reason = " ".join(tokens[2:])
    scope_chat = message.chat.id if message.chat.type in {"group", "supergroup"} else 0
    ban = await ctx.db.ban_user(
        chat_id=scope_chat,
        user_id=uid,
        author_name=uname,
        reason=reason,
        banned_by=message.from_user.id if message.from_user else 0,
        duration_seconds=dur,
    )
    await state.clear()
    lang = await ctx.db.get_effective_language(message.chat.id)
    bans = await ctx.db.list_active_bans(scope_chat if scope_chat else None)
    await message.reply(
        f"⏳ Временно заблокирован до <code>{ban.expires_at}</code>: <b>{html.escape(uname)}</b> (<code>{uid}</code>)",
        parse_mode="HTML",
        reply_markup=admin_bans_keyboard(bans, lang),
    )
