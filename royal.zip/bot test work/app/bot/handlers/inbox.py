from __future__ import annotations

import html
import io
import logging
from collections import OrderedDict

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from app.bot.context import AppContext, is_user_admin
from app.bot.keyboards import (
    duplicate_override_keyboard,
    reroute_topics_keyboard,
    routed_item_keyboard,
)
from app.i18n import t
from app.llm.client import LLMConfigError
from app.services.analyzer import ExtractedPayload
from app.services.router import build_topic_message_link, format_routed_card_html

logger = logging.getLogger(__name__)
router = Router(name="inbox")

# Bounded cache for duplicate-override actions: (chat_id, source_msg_id) -> (Message, ExtractedPayload)
_FORCE_CACHE: OrderedDict[tuple[int, int], tuple[Message, ExtractedPayload]] = OrderedDict()
_FORCE_CACHE_MAX = 150


def _cache_put(chat_id: int, msg_id: int, msg: Message, payload: ExtractedPayload) -> None:
    key = (chat_id, msg_id)
    _FORCE_CACHE[key] = (msg, payload)
    _FORCE_CACHE.move_to_end(key)
    while len(_FORCE_CACHE) > _FORCE_CACHE_MAX:
        _FORCE_CACHE.popitem(last=False)


def _is_service_message(message: Message) -> bool:
    return any(
        [
            message.forum_topic_created,
            message.forum_topic_edited,
            message.forum_topic_closed,
            message.forum_topic_reopened,
            message.new_chat_members,
            message.left_chat_member,
            message.pinned_message,
        ]
    )


async def _extract_message_payload(message: Message, ctx: AppContext) -> ExtractedPayload:
    settings = await ctx.db.get_settings()
    raw_text = (message.text or message.caption or "").strip()

    # Include forwarded source context if present
    if message.forward_origin:
        origin_desc = getattr(message.forward_origin, "type", "forwarded")
        chat_obj = getattr(message.forward_origin, "chat", None)
        if chat_obj and getattr(chat_obj, "title", None):
            origin_desc = f"канал/чат «{chat_obj.title}»"
        raw_text = f"[Переслано: {origin_desc}]\n{raw_text}".strip()

    file_name = ""
    file_bytes: bytes | None = None
    is_image = False

    if message.document:
        doc = message.document
        file_name = doc.file_name or "document.bin"
        if (doc.file_size or 0) <= ctx.static_cfg.sandbox_max_download_bytes:
            buf = io.BytesIO()
            await message.bot.download(doc, destination=buf)  # type: ignore[union-attr]
            file_bytes = buf.getvalue()
        else:
            raw_text = (
                f"{raw_text}\n[Файл {file_name}, размер {doc.file_size} байт — превышает лимит скачивания песочницы]"
            ).strip()
    elif message.photo:
        photo = message.photo[-1]
        is_image = True
        file_name = f"photo_{photo.file_unique_id}.jpg"
        if (photo.file_size or 0) <= ctx.static_cfg.sandbox_max_download_bytes:
            buf = io.BytesIO()
            await message.bot.download(photo, destination=buf)  # type: ignore[union-attr]
            file_bytes = buf.getvalue()
    elif message.video:
        file_name = message.video.file_name or "video.mp4"
        raw_text = f"{raw_text}\n[Видео: {file_name}, длительность {message.video.duration}с]".strip()
    elif message.audio or message.voice:
        raw_text = f"{raw_text}\n[Аудио/голосовое сообщение]".strip()

    return await ctx.analyzer.extract_payload(
        text=raw_text,
        settings=settings,
        file_name=file_name,
        file_bytes=file_bytes,
        is_image=is_image,
    )


async def _process_and_route(
    message: Message,
    payload: ExtractedPayload,
    ctx: AppContext,
    *,
    status_msg: Message,
) -> None:
    chat_id = message.chat.id
    thread_id = message.message_thread_id or 0
    settings = await ctx.db.get_settings()
    lang = await ctx.db.get_effective_language(chat_id)
    chat_rec = await ctx.db.get_chat(chat_id)
    topics = await ctx.db.list_topics(chat_id, include_inbox=False)

    author = message.from_user
    author_id = author.id if author else 0
    author_name = (
        (author.full_name or author.username or str(author.id))
        if author
        else ("Member" if lang == "en" else "Участник")
    )

    decision = await ctx.analyzer.analyze_and_classify(
        payload=payload,
        author_name=author_name,
        existing_topics=topics,
        settings=settings,
        chat_system_override=chat_rec.system_prompt_override if chat_rec else "",
        lang=lang,
    )

    target_topic = await ctx.router_svc.resolve_or_create_target_topic(
        message.bot,  # type: ignore[arg-type]
        chat_id,
        decision,
    )

    source_link = build_topic_message_link(chat_id, message.message_id, thread_id)
    card_html = format_routed_card_html(
        decision,
        author_id=author_id,
        author_name=author_name,
        source_link="" if settings.delete_inbox_after_route else source_link,
        lang=lang,
    )

    has_media = bool(message.document or message.photo or message.video or message.audio or message.voice)
    # Save first to obtain item.id for inline re-route keyboard
    saved_item = await ctx.db.save_routed_item(
        chat_id=chat_id,
        source_message_id=message.message_id,
        source_thread_id=thread_id,
        target_thread_id=target_topic.thread_id,
        target_message_id=None,
        target_topic_name=target_topic.name,
        author_id=author_id,
        author_name=author_name,
        item_kind=decision.item_kind,
        title=decision.title,
        url=decision.primary_url,
        normalized_url=decision.normalized_url,
        file_hash=decision.file_hash,
        summary=decision.summary,
        why_needed=decision.why_needed,
        tags=decision.tags,
        raw_input=(message.text or message.caption or "")[:2000],
    )

    target_msg_id = await ctx.router_svc.publish_to_topic(
        message.bot,  # type: ignore[arg-type]
        chat_id=chat_id,
        target_topic=target_topic,
        card_html=card_html,
        source_message_id=message.message_id,
        has_media=has_media,
        reply_markup=routed_item_keyboard(saved_item.id, lang),
    )
    await ctx.db.update_routed_item_target(
        saved_item.id,
        target_thread_id=target_topic.thread_id,
        target_message_id=target_msg_id,
        target_topic_name=target_topic.name,
    )

    target_link = build_topic_message_link(chat_id, target_msg_id, target_topic.thread_id)
    new_badge = t(lang, "new_topic_badge") if decision.create_new_topic else ""
    link_html = (
        f' <a href="{html.escape(target_link)}">{t(lang, "goto_card")}</a>'
        if target_link
        else ""
    )
    notes_html = ""
    if payload.extraction_notes:
        notes_html = f"\n⚠️ <i>{html.escape(payload.extraction_notes[0][:140])}</i>"

    await status_msg.edit_text(
        t(
            lang,
            "routed_status",
            topic=html.escape(target_topic.name),
            new_badge=new_badge,
            title=html.escape(decision.title),
            link_html=link_html,
            notes_html=notes_html,
        ),
        parse_mode="HTML",
        disable_web_page_preview=True,
    )

    if settings.delete_inbox_after_route:
        try:
            await message.delete()
        except Exception:
            pass


@router.message(F.chat.type.in_({"group", "supergroup"}))
async def on_inbox_message(message: Message, ctx: AppContext) -> None:
    if not message.chat.is_forum or not message.from_user or message.from_user.is_bot:
        return
    if _is_service_message(message):
        return

    raw_text = (message.text or message.caption or "").strip()
    if raw_text.startswith("/"):
        return

    chat_rec = await ctx.db.get_chat(message.chat.id)
    if not chat_rec or not chat_rec.inbox_thread_id:
        return
    if message.message_thread_id != chat_rec.inbox_thread_id:
        return

    # Ensure there is something meaningful to inspect
    if not raw_text and not any([message.document, message.photo, message.video, message.audio, message.voice]):
        return

    lang = await ctx.db.get_effective_language(message.chat.id)
    status_msg = await message.reply(t(lang, "analyzing"))

    try:
        payload = await _extract_message_payload(message, ctx)
        dup = await ctx.db.find_duplicate_item(
            message.chat.id,
            normalized_url=payload.normalized_url,
            file_hash=payload.file_hash,
        )
        if dup is not None:
            _cache_put(message.chat.id, message.message_id, message, payload)
            dup_link = build_topic_message_link(message.chat.id, dup.target_message_id, dup.target_thread_id)
            link_part = (
                f' (<a href="{html.escape(dup_link)}">{t(lang, "dup_open")}</a>)'
                if dup_link
                else ""
            )
            await status_msg.edit_text(
                t(
                    lang,
                    "dup_found",
                    title=html.escape(dup.title),
                    topic=html.escape(dup.target_topic_name),
                    link_part=link_part,
                ),
                parse_mode="HTML",
                disable_web_page_preview=True,
                reply_markup=duplicate_override_keyboard(message.message_id, lang),
            )
            return

        await _process_and_route(message, payload, ctx, status_msg=status_msg)

    except LLMConfigError as exc:
        await status_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        logger.exception("Failed to route inbox message %s", message.message_id)
        await status_msg.edit_text(
            f"❌ Ошибка при разборе материала:\n<code>{html.escape(str(exc)[:300])}</code>",
            parse_mode="HTML",
        )


@router.callback_query(F.data.startswith("inbox:force:"))
async def on_duplicate_force(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.data:
        return
    try:
        source_msg_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Некорректные данные", show_alert=True)
        return

    cached = _FORCE_CACHE.pop((cb.message.chat.id, source_msg_id), None)
    if cached is None:
        await cb.answer("Кэш этого сообщения устарел, отправьте материал ещё раз.", show_alert=True)
        return

    orig_msg, payload = cached
    await cb.answer("Разбираю заново...")
    await cb.message.edit_text("⏳ Анализирую и распределяю по веткам...")
    try:
        await _process_and_route(orig_msg, payload, ctx, status_msg=cb.message)
    except Exception as exc:
        await cb.message.edit_text(
            f"❌ Ошибка при разборе:\n<code>{html.escape(str(exc)[:300])}</code>",
            parse_mode="HTML",
        )


@router.callback_query(F.data.startswith("reroute:"))
async def on_reroute_callback(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.data or not cb.from_user:
        return
    parts = cb.data.split(":")
    if len(parts) < 3:
        return
    action = parts[1]
    try:
        item_id = int(parts[2])
    except ValueError:
        await cb.answer("Некорректный ID", show_alert=True)
        return

    item = await ctx.db.get_routed_item(item_id)
    if item is None:
        await cb.answer("Запись не найдена в базе", show_alert=True)
        return

    is_admin = await is_user_admin(
        cb.bot,  # type: ignore[arg-type]
        cb.message.chat.id,
        cb.message.chat.type,
        cb.from_user.id,
        ctx.static_cfg,
        ctx.db,
    )
    if not is_admin and cb.from_user.id != item.author_id:
        await cb.answer("Перенести может автор материала или администратор.", show_alert=True)
        return

    if action == "menu":
        topics = await ctx.db.list_topics(item.chat_id, include_inbox=False)
        candidates = [t for t in topics if not t.is_closed and t.thread_id != item.target_thread_id]
        if not candidates:
            await cb.answer("Нет других открытых веток для переноса.", show_alert=True)
            return
        await cb.message.edit_reply_markup(
            reply_markup=reroute_topics_keyboard(item.id, topics, item.target_thread_id)
        )
        await cb.answer("Выберите целевую ветку")
        return

    if action == "cancel":
        lang = await ctx.db.get_effective_language(item.chat_id)
        await cb.message.edit_reply_markup(reply_markup=routed_item_keyboard(item.id, lang))
        await cb.answer("Cancelled" if lang == "en" else "Отменено")
        return

    if action == "to" and len(parts) >= 4:
        try:
            new_thread_id = int(parts[3])
        except ValueError:
            return
        new_topic = await ctx.db.get_topic(item.chat_id, new_thread_id)
        if new_topic is None:
            await cb.answer("Topic not found / Ветка не найдена", show_alert=True)
            return

        lang = await ctx.db.get_effective_language(item.chat_id)
        await cb.answer(f"Moving to «{new_topic.name}»..." if lang == "en" else f"Переношу в «{new_topic.name}»...")
        await ctx.router_svc.reroute_existing_item(
            cb.bot,  # type: ignore[arg-type]
            item,
            new_topic,
            reply_markup=routed_item_keyboard(item.id, lang),
            lang=lang,
        )


@router.callback_query(F.data.startswith("item:"))
async def on_item_action_callback(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.data:
        return
    parts = cb.data.split(":")
    if len(parts) < 3 or not parts[2].isdigit():
        return
    action = parts[1]
    item_id = int(parts[2])
    item = await ctx.db.get_routed_item(item_id)
    if item is None:
        await cb.answer("Материал не найден в базе", show_alert=True)
        return

    lang = await ctx.db.get_effective_language(item.chat_id)
    settings = await ctx.db.get_settings()

    if action == "spec":
        await cb.answer("Генерирую ТЗ..." if lang != "en" else "Generating spec...")
        wait_msg = await cb.message.reply(
            "⏳ Генерирую задачу / ТЗ на основе материала..." if lang != "en" else "⏳ Generating developer task / spec..."
        )
        try:
            spec_text = await ctx.assistant.generate_item_spec(item, settings, lang=lang)
            header = f"📝 <b>{'Developer Task / Spec' if lang == 'en' else 'Задача / ТЗ'}: {html.escape(item.title)}</b>\n\n"
            await wait_msg.edit_text((header + html.escape(spec_text))[:4000], parse_mode="HTML", disable_web_page_preview=True)
        except LLMConfigError as exc:
            await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
        except Exception as exc:
            await wait_msg.edit_text(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")
        return

    if action == "review":
        await cb.answer("Анализирую плюсы и риски..." if lang != "en" else "Analyzing pros & risks...")
        wait_msg = await cb.message.reply(
            "⏳ Оцениваю плюсы, минусы и риски..." if lang != "en" else "⏳ Reviewing pros, cons & risks..."
        )
        try:
            review_text = await ctx.assistant.generate_item_review(item, settings, lang=lang)
            header = f"⚖️ <b>{'Tech Review' if lang == 'en' else 'Плюсы и риски'}: {html.escape(item.title)}</b>\n\n"
            await wait_msg.edit_text((header + html.escape(review_text))[:4000], parse_mode="HTML", disable_web_page_preview=True)
        except LLMConfigError as exc:
            await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
        except Exception as exc:
            await wait_msg.edit_text(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")
