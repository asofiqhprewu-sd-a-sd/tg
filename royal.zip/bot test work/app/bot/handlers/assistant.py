from __future__ import annotations

import html
import logging
import re

from aiogram import F, Router
from aiogram.filters import BaseFilter, Command, CommandObject
from aiogram.types import BufferedInputFile, CallbackQuery, Message

from app.bot.context import AppContext, is_user_admin
from app.bot.keyboards import digest_publish_keyboard, index_keyboard
from app.i18n import t
from app.llm.client import LLMConfigError
from app.sandbox.net import extract_urls
from app.services.router import build_topic_message_link

logger = logging.getLogger(__name__)
router = Router(name="assistant")


class GroupMentionOrReplyFilter(BaseFilter):
    """Matches only group messages outside Inbox that mention the bot or reply to it."""

    async def __call__(self, message: Message, ctx: AppContext) -> bool:
        if message.chat.type not in {"group", "supergroup"}:
            return False
        if not message.from_user or message.from_user.is_bot:
            return False
        text = (message.text or "").strip()
        if not text or text.startswith("/"):
            return False

        chat_rec = await ctx.db.get_chat(message.chat.id)
        if chat_rec and chat_rec.inbox_thread_id and message.message_thread_id == chat_rec.inbox_thread_id:
            return False

        bot_uname = ctx.bot_username.lower()
        mentioned = bool(bot_uname and f"@{bot_uname}" in text.lower())
        replied_to_bot = bool(
            message.reply_to_message
            and message.reply_to_message.from_user
            and message.reply_to_message.from_user.id == ctx.bot_id
            and not message.reply_to_message.forum_topic_created
        )
        return mentioned or replied_to_bot


async def _send_reply_chunks(message: Message, text: str) -> None:
    """Split long LLM responses cleanly within Telegram's 4096 char limit."""
    chunks = [text[i : i + 3900] for i in range(0, len(text), 3900)] or ["(пустой ответ)"]
    for idx, chunk in enumerate(chunks):
        safe = html.escape(chunk)
        if idx == 0:
            await message.reply(safe, parse_mode="HTML", disable_web_page_preview=True)
        else:
            await message.answer(
                safe,
                message_thread_id=message.message_thread_id,
                parse_mode="HTML",
                disable_web_page_preview=True,
            )


@router.message(Command("find"))
async def cmd_find(message: Message, command: CommandObject, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply("Knowledge search works in group chats." if lang == "en" else "Поиск по базе знаний работает в группе.")
        return
    query = (command.args or "").strip()
    if not query:
        await message.reply(
            "Usage: <code>/find keyword</code>" if lang == "en" else "Использование: <code>/find ключевое слово</code>",
            parse_mode="HTML",
        )
        return
    items = await ctx.db.search_items(message.chat.id, query, limit=8)
    result_html = ctx.assistant.format_search_results_html(query, items, lang=lang)
    await message.reply(result_html, parse_mode="HTML", disable_web_page_preview=True)


@router.message(Command("index"))
async def cmd_index(message: Message, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply(
            "Topics directory works in group chats." if lang == "en" else "Навигатор по веткам работает в группе."
        )
        return
    index_html = await ctx.assistant.build_index_html(message.chat.id, lang=lang)
    await message.reply(
        index_html,
        parse_mode="HTML",
        disable_web_page_preview=True,
        reply_markup=index_keyboard(lang),
    )


@router.callback_query(F.data == "idx:pin")
async def on_pin_index(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.from_user:
        return
    lang = await ctx.db.get_effective_language(cb.message.chat.id)
    allowed = await is_user_admin(
        cb.bot,  # type: ignore[arg-type]
        cb.message.chat.id,
        cb.message.chat.type,
        cb.from_user.id,
        ctx.static_cfg,
        ctx.db,
    )
    if not allowed:
        await cb.answer("⛔ Admins only" if lang == "en" else "⛔ Только для администраторов", show_alert=True)
        return
    try:
        await cb.bot.pin_chat_message(  # type: ignore[union-attr]
            chat_id=cb.message.chat.id,
            message_id=cb.message.message_id,
            disable_notification=True,
        )
        await cb.answer("📌 Pinned!" if lang == "en" else "📌 Закреплено!")
    except Exception as exc:
        await cb.answer(str(exc)[:180], show_alert=True)


@router.message(Command("export"))
async def cmd_export(message: Message, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply(
            "Knowledge base export works in group chats."
            if lang == "en"
            else "Экспорт базы знаний работает внутри группы."
        )
        return
    md = await ctx.assistant.build_export_markdown(
        message.chat.id,
        message.chat.title or str(message.chat.id),
        lang=lang,
    )
    doc = BufferedInputFile(md.encode("utf-8"), filename="knowledge_base.md")
    caption = (
        "📦 Knowledge base exported as Markdown."
        if lang == "en"
        else "📦 База знаний группы выгружена в Markdown."
    )
    await message.reply_document(doc, caption=caption)


@router.message(Command("digest"))
async def cmd_digest(message: Message, command: CommandObject, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    if message.chat.type not in {"group", "supergroup"}:
        await message.reply("Digest works inside a group topic." if lang == "en" else "Дайджест формируется внутри групповой ветки.")
        return

    arg = (command.args or "").strip().lower()
    thread_id = message.message_thread_id or 0
    chat_rec = await ctx.db.get_chat(message.chat.id)
    in_inbox = bool(chat_rec and chat_rec.inbox_thread_id and thread_id == chat_rec.inbox_thread_id)
    group_wide = (arg in {"all", "group", "week", "неделя", "вся"}) or (thread_id == 0) or in_inbox

    wait_msg = await message.reply(t(lang, "digesting"))
    settings = await ctx.db.get_settings()
    try:
        digest_text = await ctx.assistant.build_digest(
            chat_id=message.chat.id,
            thread_id=thread_id,
            settings=settings,
            lang=lang,
            group_wide=group_wide,
        )
        if group_wide and message.chat.is_forum:
            digest_topic_name = "📢 Digests" if lang == "en" else "📢 Дайджесты"
            d_topic = await ctx.router_svc.ensure_named_topic(
                message.bot,  # type: ignore[arg-type]
                message.chat.id,
                digest_topic_name,
                description="Weekly and group knowledge digests",
            )
            header = f"📢 <b>{'Group Digest' if lang == 'en' else 'Дайджест группы'}</b>\n\n"
            sent = await message.bot.send_message(  # type: ignore[union-attr]
                chat_id=message.chat.id,
                message_thread_id=d_topic.thread_id,
                text=(header + html.escape(digest_text))[:4000],
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            link = build_topic_message_link(message.chat.id, sent.message_id, d_topic.thread_id)
            link_part = f' → <a href="{html.escape(link)}">{t(lang, "goto_card")}</a>' if link else ""
            await wait_msg.edit_text(
                f"✅ <b>{'Published to' if lang == 'en' else 'Дайджест опубликован в'} «{html.escape(d_topic.name)}»</b>{link_part}",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
        else:
            await wait_msg.edit_text(
                html.escape(digest_text[:4000]),
                parse_mode="HTML",
                reply_markup=(digest_publish_keyboard(thread_id, lang) if message.chat.is_forum else None),
            )
    except LLMConfigError as exc:
        await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        await wait_msg.edit_text(f"❌ Error: <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")


@router.callback_query(F.data.startswith("digest:pub:"))
async def on_publish_digest(cb: CallbackQuery, ctx: AppContext) -> None:
    if not cb.message or not cb.data:
        return
    lang = await ctx.db.get_effective_language(cb.message.chat.id)
    if not cb.message.chat.is_forum:
        await cb.answer("Topics disabled", show_alert=True)
        return
    digest_topic_name = "📢 Digests" if lang == "en" else "📢 Дайджесты"
    d_topic = await ctx.router_svc.ensure_named_topic(
        cb.bot,  # type: ignore[arg-type]
        cb.message.chat.id,
        digest_topic_name,
        description="Group & topic digests",
    )
    txt = cb.message.text or ""
    sent = await cb.bot.send_message(  # type: ignore[union-attr]
        chat_id=cb.message.chat.id,
        message_thread_id=d_topic.thread_id,
        text=f"📢 <b>{'Digest' if lang == 'en' else 'Дайджест'}</b>\n\n{html.escape(txt[:3800])}",
        parse_mode="HTML",
        disable_web_page_preview=True,
    )
    link = build_topic_message_link(cb.message.chat.id, sent.message_id, d_topic.thread_id)
    await cb.answer(f"✅ «{d_topic.name}»" + (f" ({link})" if link else ""))


@router.message(Command("compare"))
async def cmd_compare(message: Message, command: CommandObject, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    raw = (command.args or "").strip()
    if message.reply_to_message:
        raw = f"{raw} {message.reply_to_message.text or message.reply_to_message.caption or ''}".strip()
    urls = extract_urls(raw)
    if len(urls) < 2:
        await message.reply(
            "Usage: <code>/compare https://url1 https://url2</code>"
            if lang == "en"
            else "Использование: <code>/compare https://ссылка1 https://ссылка2</code>",
            parse_mode="HTML",
        )
        return
    wait_msg = await message.reply(
        "⏳ Fetching both links from sandbox & comparing..."
        if lang == "en"
        else "⏳ Загружаю обе ссылки из песочницы и сравниваю..."
    )
    settings = await ctx.db.get_settings()
    try:
        cmp_text = await ctx.assistant.compare_urls(urls[0], urls[1], settings, lang=lang)
        await wait_msg.delete()
        await _send_reply_chunks(message, cmp_text)
    except LLMConfigError as exc:
        await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        await wait_msg.edit_text(f"❌ Error: <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")


@router.message(Command("ask", "search"))
async def cmd_ask_or_search(message: Message, command: CommandObject, ctx: AppContext) -> None:
    lang = await ctx.db.get_effective_language(message.chat.id)
    question = (command.args or "").strip()
    if not question and message.reply_to_message:
        question = (message.reply_to_message.text or message.reply_to_message.caption or "").strip()
    if not question:
        await message.reply(
            "Usage: <code>/ask question</code> or <code>/search web query</code>"
            if lang == "en"
            else "Использование: <code>/ask ваш вопрос</code> или <code>/search запрос в интернет</code>",
            parse_mode="HTML",
        )
        return

    cmd_name = (command.command or "ask").lower()
    force_web = cmd_name == "search"
    wait_msg = await message.reply(t(lang, "searching") if force_web else t(lang, "thinking"))

    settings = await ctx.db.get_settings()
    author_name = (
        (message.from_user.full_name or message.from_user.username or "Member")
        if message.from_user
        else "Member"
    )
    try:
        answer = await ctx.assistant.answer_question(
            chat_id=message.chat.id,
            thread_id=message.message_thread_id or 0,
            user_name=author_name,
            question=question,
            settings=settings,
            force_web_search=force_web,
            lang=lang,
        )
        await wait_msg.delete()
        await _send_reply_chunks(message, answer)
        if message.chat.type in {"group", "supergroup"}:
            await ctx.db.save_message(
                chat_id=message.chat.id,
                thread_id=message.message_thread_id or 0,
                message_id=wait_msg.message_id,
                user_id=ctx.bot_id,
                author_name=ctx.bot_username or "Bot",
                text=answer[:3000],
                is_bot=True,
            )
    except LLMConfigError as exc:
        await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        logger.exception("Assistant error")
        await wait_msg.edit_text(f"❌ Error: <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")


@router.message(GroupMentionOrReplyFilter())
async def on_group_mention_or_reply(message: Message, ctx: AppContext) -> None:
    """Reply when mentioned (@bot) or replied to in any non-Inbox topic (or general chat)."""
    assert message.from_user is not None
    lang = await ctx.db.get_effective_language(message.chat.id)
    text = (message.text or "").strip()
    bot_uname = ctx.bot_username.lower()

    cleaned_question = text
    if bot_uname:
        cleaned_question = re.sub(rf"@{re.escape(bot_uname)}\b", "", cleaned_question, flags=re.IGNORECASE).strip()
    if not cleaned_question:
        cleaned_question = (
            "Help with the latest discussion in this topic."
            if lang == "en"
            else "Помоги по последнему обсуждению в этой ветке."
        )

    settings = await ctx.db.get_settings()
    author_name = message.from_user.full_name or message.from_user.username or str(message.from_user.id)
    try:
        answer = await ctx.assistant.answer_question(
            chat_id=message.chat.id,
            thread_id=message.message_thread_id or 0,
            user_name=author_name,
            question=cleaned_question,
            settings=settings,
            lang=lang,
        )
        await _send_reply_chunks(message, answer)
    except LLMConfigError as exc:
        await message.reply(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        logger.exception("Mention assistant error")
        await message.reply(f"❌ Error: <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def on_private_question(message: Message, ctx: AppContext) -> None:
    if not message.from_user or message.from_user.is_bot:
        return
    text = (message.text or "").strip()
    if not text:
        return

    lang = await ctx.db.get_effective_language(message.chat.id)
    wait_msg = await message.reply(t(lang, "thinking"))
    settings = await ctx.db.get_settings()
    author_name = message.from_user.full_name or message.from_user.username or "User"
    try:
        answer = await ctx.assistant.answer_question(
            chat_id=message.chat.id,
            thread_id=0,
            user_name=author_name,
            question=text,
            settings=settings,
            lang=lang,
        )
        await wait_msg.delete()
        await _send_reply_chunks(message, answer)
    except LLMConfigError as exc:
        await wait_msg.edit_text(f"⚠️ {html.escape(str(exc))}", parse_mode="HTML")
    except Exception as exc:
        await wait_msg.edit_text(f"❌ Ошибка: <code>{html.escape(str(exc)[:250])}</code>", parse_mode="HTML")
