from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.config import RuntimeSettings
from app.i18n import t
from app.models import TopicRecord, UserBanRecord


def language_select_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang:set:ru"),
                InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:set:en"),
            ]
        ]
    )


def admin_main_keyboard(settings: RuntimeSettings, lang: str = "ru") -> InlineKeyboardMarkup:
    inet_badge = "🟢 ON" if settings.sandbox_internet_enabled else "🔴 OFF"
    auto_topic = "🟢 ON" if settings.auto_create_topics else "🔴 OFF"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t(lang, "admin_btn_prompt"), callback_data="adm:prompt"),
                InlineKeyboardButton(text=t(lang, "admin_btn_show_prompt"), callback_data="adm:show_prompt"),
            ],
            [
                InlineKeyboardButton(text=t(lang, "admin_btn_model"), callback_data="adm:model"),
                InlineKeyboardButton(text=t(lang, "admin_btn_test"), callback_data="adm:test_model"),
            ],
            [
                InlineKeyboardButton(text=f"{t(lang, 'admin_btn_sandbox')} ({inet_badge})", callback_data="adm:sandbox"),
                InlineKeyboardButton(text=f"{t(lang, 'admin_btn_topics')} ({auto_topic})", callback_data="adm:topics"),
            ],
            [
                InlineKeyboardButton(
                    text="🚫 User Bans" if lang == "en" else "🚫 Блокировки",
                    callback_data="adm:bans",
                ),
                InlineKeyboardButton(text=t(lang, "admin_btn_lang"), callback_data="adm:tog_lang"),
            ],
            [
                InlineKeyboardButton(text=t(lang, "admin_btn_stats"), callback_data="adm:stats"),
            ],
        ]
    )


def admin_model_keyboard(lang: str = "ru") -> InlineKeyboardMarkup:
    if lang == "en":
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="🔑 API Key", callback_data="adm:set_key"),
                    InlineKeyboardButton(text="🌐 Base URL", callback_data="adm:set_url"),
                ],
                [
                    InlineKeyboardButton(text="🧠 Model Name", callback_data="adm:set_model"),
                    InlineKeyboardButton(text="🩺 Test Connection", callback_data="adm:test_model"),
                ],
                [InlineKeyboardButton(text=t(lang, "admin_btn_back"), callback_data="adm:home")],
            ]
        )
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🔑 Изменить API Key", callback_data="adm:set_key"),
                InlineKeyboardButton(text="🌐 Изменить Base URL", callback_data="adm:set_url"),
            ],
            [
                InlineKeyboardButton(text="🧠 Изменить модель", callback_data="adm:set_model"),
                InlineKeyboardButton(text="🩺 Проверить связь", callback_data="adm:test_model"),
            ],
            [InlineKeyboardButton(text=t(lang, "admin_btn_back"), callback_data="adm:home")],
        ]
    )


def admin_sandbox_keyboard(settings: RuntimeSettings, lang: str = "ru") -> InlineKeyboardMarkup:
    if lang == "en":
        inet = "🟢 Internet: ON" if settings.sandbox_internet_enabled else "🔴 Internet: OFF"
        qa_web = "🟢 Web Search in Q&A: ON" if settings.web_search_in_qa else "🔴 Web Search in Q&A: OFF"
        auto_t = "🟢 Auto-Topics: ON" if settings.auto_create_topics else "🔴 Auto-Topics: OFF"
        del_in = "🟢 Delete Inbox msg: ON" if settings.delete_inbox_after_route else "🔴 Delete Inbox msg: OFF"
    else:
        inet = "🟢 Интернет: ВКЛ" if settings.sandbox_internet_enabled else "🔴 Интернет: ВЫКЛ"
        qa_web = "🟢 Поиск в Q&A: ВКЛ" if settings.web_search_in_qa else "🔴 Поиск в Q&A: ВЫКЛ"
        auto_t = "🟢 Авто-ветки: ВКЛ" if settings.auto_create_topics else "🔴 Авто-ветки: ВЫКЛ"
        del_in = "🟢 Чистить Входящие: ВКЛ" if settings.delete_inbox_after_route else "🔴 Чистить Входящие: ВЫКЛ"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=inet, callback_data="adm:tog_inet")],
            [InlineKeyboardButton(text=qa_web, callback_data="adm:tog_qa_web")],
            [InlineKeyboardButton(text=auto_t, callback_data="adm:tog_auto_topics")],
            [InlineKeyboardButton(text=del_in, callback_data="adm:tog_del_inbox")],
            [
                InlineKeyboardButton(
                    text="🌐 Test Sandbox Internet" if lang == "en" else "🌐 Тест интернета песочницы",
                    callback_data="adm:test_sandbox",
                )
            ],
            [InlineKeyboardButton(text=t(lang, "admin_btn_back"), callback_data="adm:home")],
        ]
    )


def admin_topics_keyboard(is_group: bool, lang: str = "ru") -> InlineKeyboardMarkup:
    rows = []
    if is_group:
        rows.append(
            [
                InlineKeyboardButton(
                    text="📥 Ensure Inbox topic" if lang == "en" else "📥 Создать/проверить Входящие",
                    callback_data="adm:ensure_inbox",
                )
            ]
        )
        rows.append(
            [
                InlineKeyboardButton(
                    text="➕ Create New Topic" if lang == "en" else "➕ Создать новую ветку",
                    callback_data="adm:create_topic",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text=t(lang, "admin_btn_back"), callback_data="adm:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_bans_keyboard(bans: list[UserBanRecord], lang: str = "ru") -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(
                text="🔨 Ban Forever" if lang == "en" else "🔨 Бан навсегда",
                callback_data="adm:ban_perm",
            ),
            InlineKeyboardButton(
                text="⏳ Temp Ban" if lang == "en" else "⏳ Временный бан",
                callback_data="adm:ban_temp",
            ),
        ]
    ]
    for b in bans[:10]:
        label = b.author_name or str(b.user_id)
        kind = f"до {b.expires_at[:16]}" if b.expires_at else ("perm" if lang == "en" else "вечный")
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"✅ {'Unban' if lang == 'en' else 'Разбан'}: {label[:22]} ({kind})",
                    callback_data=f"adm:unban:{b.chat_id}:{b.user_id}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text=t(lang, "admin_btn_back"), callback_data="adm:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def routed_item_keyboard(item_id: int, lang: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📝 Generate Task / Spec" if lang == "en" else "📝 Сгенерировать задачу / ТЗ",
                    callback_data=f"item:spec:{item_id}",
                ),
                InlineKeyboardButton(
                    text="⚖️ Pros / Risks" if lang == "en" else "⚖️ Плюсы / Риски",
                    callback_data=f"item:review:{item_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=t(lang, "btn_reroute"),
                    callback_data=f"reroute:menu:{item_id}",
                )
            ],
        ]
    )


def reroute_topics_keyboard(item_id: int, topics: list[TopicRecord], current_thread_id: int) -> InlineKeyboardMarkup:
    buttons: list[list[InlineKeyboardButton]] = []
    for topic in topics:
        if topic.is_inbox or topic.is_closed or topic.thread_id == current_thread_id:
            continue
        buttons.append(
            [
                InlineKeyboardButton(
                    text=topic.name[:45],
                    callback_data=f"reroute:to:{item_id}:{topic.thread_id}",
                )
            ]
        )
    buttons.append([InlineKeyboardButton(text="✖️ Cancel / Отмена", callback_data=f"reroute:cancel:{item_id}")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def duplicate_override_keyboard(source_msg_id: int, lang: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=t(lang, "btn_force_route"),
                    callback_data=f"inbox:force:{source_msg_id}",
                )
            ]
        ]
    )


def index_keyboard(lang: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📌 Pin Directory" if lang == "en" else "📌 Закрепить навигатор",
                    callback_data="idx:pin",
                )
            ]
        ]
    )


def digest_publish_keyboard(thread_id: int, lang: str = "ru") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📢 Post to «Digests»" if lang == "en" else "📢 В ветку «Дайджесты»",
                    callback_data=f"digest:pub:{thread_id}",
                )
            ]
        ]
    )
