from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.bot.context import AppContext, format_ban_notice, is_user_admin

logger = logging.getLogger(__name__)


class TopicTrackingMiddleware(BaseMiddleware):
    """Auto-discovers forum topics, tracks known users, enforces bans, and stores history."""

    def __init__(self, ctx: AppContext) -> None:
        self.ctx = ctx

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        data["ctx"] = self.ctx

        if isinstance(event, Message):
            if event.from_user and not event.from_user.is_bot:
                await self.ctx.db.upsert_known_user(
                    user_id=event.from_user.id,
                    username=event.from_user.username or "",
                    full_name=event.from_user.full_name or "",
                    last_chat_id=event.chat.id,
                )

                ban = await self.ctx.db.get_active_ban(event.chat.id, event.from_user.id)
                if ban is not None:
                    is_adm = await is_user_admin(
                        event.bot,  # type: ignore[arg-type]
                        event.chat.id,
                        event.chat.type,
                        event.from_user.id,
                        self.ctx.static_cfg,
                        self.ctx.db,
                    )
                    if not is_adm:
                        text = (event.text or event.caption or "").strip()
                        bot_uname = self.ctx.bot_username.lower()
                        mentioned = bool(bot_uname and f"@{bot_uname}" in text.lower())
                        if event.chat.type == "private" or text.startswith("/") or mentioned:
                            lang = await self.ctx.db.get_effective_language(event.chat.id)
                            try:
                                await event.reply(format_ban_notice(ban, lang), parse_mode="HTML")
                            except Exception:
                                pass
                        return None

            if event.chat.type in {"group", "supergroup"}:
                await self._track_group_message(event)

        return await handler(event, data)

    async def _track_group_message(self, message: Message) -> None:
        chat_id = message.chat.id
        is_forum = bool(message.chat.is_forum)
        await self.ctx.db.upsert_chat(chat_id, message.chat.title or "", is_forum)

        thread_id = message.message_thread_id or 0
        if is_forum and thread_id:
            if message.forum_topic_created:
                await self.ctx.db.upsert_topic(
                    chat_id,
                    thread_id,
                    message.forum_topic_created.name,
                )
            elif message.forum_topic_edited and message.forum_topic_edited.name:
                existing = await self.ctx.db.get_topic(chat_id, thread_id)
                if existing:
                    await self.ctx.db.update_topic_meta(
                        chat_id,
                        thread_id,
                        name=message.forum_topic_edited.name,
                    )
                else:
                    await self.ctx.db.upsert_topic(
                        chat_id,
                        thread_id,
                        message.forum_topic_edited.name,
                    )
            elif message.forum_topic_closed:
                await self.ctx.db.mark_topic_closed(chat_id, thread_id, True)
            elif message.forum_topic_reopened:
                await self.ctx.db.mark_topic_closed(chat_id, thread_id, False)
            else:
                existing = await self.ctx.db.get_topic(chat_id, thread_id)
                if existing is None:
                    discovered_name = ""
                    if (
                        message.reply_to_message
                        and message.reply_to_message.forum_topic_created
                    ):
                        discovered_name = message.reply_to_message.forum_topic_created.name
                    await self.ctx.db.upsert_topic(
                        chat_id,
                        thread_id,
                        discovered_name or f"Ветка #{thread_id}",
                    )

        # Auto-create "📥 Входящие" topic in forum groups on first activity if missing
        if is_forum and not (message.from_user and message.from_user.is_bot):
            chat_rec = await self.ctx.db.get_chat(chat_id)
            if chat_rec and not chat_rec.inbox_thread_id:
                settings = await self.ctx.db.get_settings()
                lang = await self.ctx.db.get_effective_language(chat_id)
                res = await self.ctx.router_svc.ensure_inbox_topic(
                    message.bot,  # type: ignore[arg-type]
                    chat_id,
                    message.chat.title or "",
                    settings,
                    lang=lang,
                )
                if not res.ok:
                    logger.debug("Auto-ensure inbox skipped/failed for %s: %s", chat_id, res.error)

        # Save non-command messages for topic context & /digest
        raw_text = (message.text or message.caption or "").strip()
        if raw_text and not raw_text.startswith("/") and message.from_user:
            author_name = message.from_user.full_name or message.from_user.username or str(message.from_user.id)
            await self.ctx.db.save_message(
                chat_id=chat_id,
                thread_id=thread_id,
                message_id=message.message_id,
                user_id=message.from_user.id,
                author_name=author_name,
                text=raw_text,
                is_bot=bool(message.from_user.is_bot),
            )


class CallbackBanMiddleware(BaseMiddleware):
    """Blocks banned users from interacting with inline keyboards."""

    def __init__(self, ctx: AppContext) -> None:
        self.ctx = ctx

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        data["ctx"] = self.ctx
        if isinstance(event, CallbackQuery) and event.from_user and event.message:
            await self.ctx.db.upsert_known_user(
                user_id=event.from_user.id,
                username=event.from_user.username or "",
                full_name=event.from_user.full_name or "",
                last_chat_id=event.message.chat.id,
            )
            ban = await self.ctx.db.get_active_ban(event.message.chat.id, event.from_user.id)
            if ban is not None:
                is_adm = await is_user_admin(
                    event.bot,  # type: ignore[arg-type]
                    event.message.chat.id,
                    event.message.chat.type,
                    event.from_user.id,
                    self.ctx.static_cfg,
                    self.ctx.db,
                )
                if not is_adm:
                    await event.answer("⛔ Доступ заблокирован / Access denied", show_alert=True)
                    return None
        return await handler(event, data)
