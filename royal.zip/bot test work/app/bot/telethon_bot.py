from __future__ import annotations

import html
import io
import logging
import random
import re
from collections import OrderedDict
from types import SimpleNamespace
from typing import Any

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import InlineKeyboardMarkup
from telethon import Button, TelegramClient, events, utils
from telethon.errors import RPCError
from telethon.network.connection import ConnectionTcpMTProxyRandomizedIntermediate
from telethon.tl.functions.bots import SetBotCommandsRequest
from telethon.tl.functions.messages import CreateForumTopicRequest, GetForumTopicsRequest
from telethon.tl.types import (
    BotCommand,
    BotCommandScopeDefault,
    DocumentAttributeFilename,
    MessageActionTopicCreate,
    MessageActionTopicEdit,
)

from app.bot.context import AppContext, format_ban_notice, parse_duration_seconds
from app.bot.handlers.admin import (
    _admin_summary_html,
    _format_bans_html,
    _mask_secret,
    _run_sandbox_self_test,
)
from app.bot.keyboards import (
    admin_bans_keyboard,
    admin_main_keyboard,
    admin_model_keyboard,
    admin_sandbox_keyboard,
    admin_topics_keyboard,
    digest_publish_keyboard,
    duplicate_override_keyboard,
    index_keyboard,
    language_select_keyboard,
    reroute_topics_keyboard,
    routed_item_keyboard,
)
from app.config import StaticConfig
from app.i18n import normalize_lang, t
from app.llm.client import LLMConfigError
from app.sandbox.net import extract_urls
from app.services.analyzer import ExtractedPayload
from app.services.router import build_topic_message_link, format_routed_card_html

logger = logging.getLogger(__name__)

_FORCE_CACHE: OrderedDict[tuple[int, int], tuple[Any, ExtractedPayload]] = OrderedDict()
_FORCE_CACHE_MAX = 150


def _cache_put(chat_id: int, msg_id: int, msg: Any, payload: ExtractedPayload) -> None:
    key = (chat_id, msg_id)
    _FORCE_CACHE[key] = (msg, payload)
    _FORCE_CACHE.move_to_end(key)
    while len(_FORCE_CACHE) > _FORCE_CACHE_MAX:
        _FORCE_CACHE.popitem(last=False)


def markup_to_telethon_buttons(markup: InlineKeyboardMarkup | None) -> list[list[Any]] | None:
    if markup is None or not markup.inline_keyboard:
        return None
    rows: list[list[Any]] = []
    for row in markup.inline_keyboard:
        btns = []
        for btn in row:
            if btn.callback_data:
                btns.append(Button.inline(btn.text, data=btn.callback_data.encode("utf-8")))
            elif btn.url:
                btns.append(Button.url(btn.text, btn.url))
        if btns:
            rows.append(btns)
    return rows or None


def extract_thread_id(msg: Any) -> int:
    reply_to = getattr(msg, "reply_to", None)
    if reply_to is None:
        return 0
    if getattr(reply_to, "forum_topic", False):
        return int(getattr(reply_to, "reply_to_top_id", None) or getattr(reply_to, "reply_to_msg_id", None) or 0)
    return 0


def parse_command(text: str, bot_username: str) -> tuple[str, str] | None:
    stripped = (text or "").strip()
    if not stripped.startswith("/"):
        return None
    parts = stripped.split(maxsplit=1)
    head = parts[0][1:]
    args = parts[1].strip() if len(parts) > 1 else ""
    if "@" in head:
        cmd, target = head.split("@", 1)
        if bot_username and target.lower() != bot_username.lower():
            return None
        head = cmd
    return head.lower(), args


class TelethonBotShim:
    """Bot-API-compatible adapter backed by a Telethon MTProto TelegramClient."""

    def __init__(self, client: TelegramClient) -> None:
        self.client = client

    async def create_forum_topic(self, chat_id: int, name: str) -> SimpleNamespace:
        clean_name = name[:120]
        try:
            peer = await self.client.get_input_entity(chat_id)
            updates = await self.client(
                CreateForumTopicRequest(
                    peer=peer,
                    title=clean_name,
                    random_id=random.randrange(1, 2**63),
                )
            )
        except RPCError as exc:
            raise TelegramBadRequest(method="createForumTopic", message=str(exc)) from exc

        thread_id = 0
        for upd in getattr(updates, "updates", []) or []:
            msg = getattr(upd, "message", None)
            if msg is not None and isinstance(getattr(msg, "action", None), MessageActionTopicCreate):
                thread_id = int(msg.id)
                break

        if not thread_id:
            res = await self.client(
                GetForumTopicsRequest(
                    peer=peer,
                    offset_date=None,
                    offset_id=0,
                    offset_topic=0,
                    limit=10,
                    q=clean_name,
                )
            )
            for topic in getattr(res, "topics", []) or []:
                if getattr(topic, "title", "") == clean_name:
                    thread_id = int(topic.id)
                    break

        if not thread_id:
            raise TelegramBadRequest(method="createForumTopic", message="Created topic ID not returned")
        return SimpleNamespace(message_thread_id=thread_id, name=clean_name)

    async def send_message(
        self,
        chat_id: int,
        text: str,
        *,
        message_thread_id: int | None = None,
        reply_to_message_id: int | None = None,
        parse_mode: str = "HTML",
        disable_web_page_preview: bool = False,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> SimpleNamespace:
        try:
            sent = await self.client.send_message(
                chat_id,
                text,
                reply_to=reply_to_message_id or (message_thread_id or None),
                parse_mode="html" if parse_mode.upper() == "HTML" else None,
                link_preview=not disable_web_page_preview,
                buttons=markup_to_telethon_buttons(reply_markup),
            )
            return SimpleNamespace(message_id=sent.id)
        except RPCError as exc:
            raise TelegramBadRequest(method="sendMessage", message=str(exc)) from exc

    async def copy_message(
        self,
        *,
        chat_id: int,
        from_chat_id: int,
        message_id: int,
        message_thread_id: int | None = None,
        reply_to_message_id: int | None = None,
    ) -> SimpleNamespace:
        src = await self.client.get_messages(from_chat_id, ids=message_id)
        if src is None:
            return SimpleNamespace(message_id=0)
        target_reply = reply_to_message_id or (message_thread_id or None)
        if src.media:
            sent = await self.client.send_file(
                chat_id,
                src.media,
                caption=src.text or None,
                reply_to=target_reply,
            )
            return SimpleNamespace(message_id=sent.id)
        sent = await self.client.send_message(
            chat_id,
            src.text or "",
            reply_to=target_reply,
        )
        return SimpleNamespace(message_id=sent.id)

    async def delete_message(self, chat_id: int, message_id: int) -> None:
        await self.client.delete_messages(chat_id, [message_id])

    async def pin_chat_message(
        self,
        chat_id: int,
        message_id: int,
        *,
        disable_notification: bool = True,
    ) -> None:
        await self.client.pin_message(chat_id, message_id, notify=not disable_notification)

    async def get_chat_member(self, chat_id: int, user_id: int) -> SimpleNamespace:
        perms = await self.client.get_permissions(chat_id, user_id)
        if getattr(perms, "is_creator", False):
            return SimpleNamespace(status="creator")
        if getattr(perms, "is_admin", False):
            return SimpleNamespace(status="administrator")
        return SimpleNamespace(status="member")

    async def sync_forum_topics(self, chat_id: int, ctx: AppContext) -> None:
        """Fetch existing forum topics via MTProto so manually created topics are known."""
        try:
            peer = await self.client.get_input_entity(chat_id)
            res = await self.client(
                GetForumTopicsRequest(
                    peer=peer,
                    offset_date=None,
                    offset_id=0,
                    offset_topic=0,
                    limit=100,
                )
            )
        except Exception as exc:
            logger.debug("sync_forum_topics skipped for %s: %s", chat_id, exc)
            return

        for tp in getattr(res, "topics", []) or []:
            tid = getattr(tp, "id", None)
            title = getattr(tp, "title", None)
            if not tid or not title:
                continue
            is_inbox_name = title.strip().lower() in {"📥 входящие", "входящие", "📥 inbox", "inbox"}
            await ctx.db.upsert_topic(
                chat_id,
                int(tid),
                str(title),
                is_inbox=is_inbox_name if is_inbox_name else None,
                is_closed=bool(getattr(tp, "closed", False)),
            )
            if is_inbox_name:
                chat_rec = await ctx.db.get_chat(chat_id)
                if chat_rec and not chat_rec.inbox_thread_id:
                    await ctx.db.set_chat_inbox_thread(chat_id, int(tid))


def build_telethon_client(cfg: StaticConfig) -> TelegramClient:
    session_path = cfg.telethon_session_path
    from pathlib import Path

    Path(session_path).parent.mkdir(parents=True, exist_ok=True)
    if cfg.mtproto_proxy_host and cfg.mtproto_proxy_port and cfg.mtproto_proxy_secret:
        logger.info(
            "Configuring Telethon MTProto proxy %s:%s",
            cfg.mtproto_proxy_host,
            cfg.mtproto_proxy_port,
        )
        return TelegramClient(
            session_path,
            cfg.telegram_api_id,
            cfg.telegram_api_hash,
            connection=ConnectionTcpMTProxyRandomizedIntermediate,
            proxy=(cfg.mtproto_proxy_host, cfg.mtproto_proxy_port, cfg.mtproto_proxy_secret),
        )
    return TelegramClient(session_path, cfg.telegram_api_id, cfg.telegram_api_hash)


async def configure_telethon_commands(client: TelegramClient) -> None:
    try:
        await client(
            SetBotCommandsRequest(
                scope=BotCommandScopeDefault(),
                lang_code="",
                commands=[
                    BotCommand(command="start", description="Выбор языка (RU/EN) и старт"),
                    BotCommand(command="setup", description="Создать/проверить ветку Входящие"),
                    BotCommand(command="admin", description="Панель администратора"),
                    BotCommand(command="set_system", description="Задать системный промпт"),
                    BotCommand(command="topics", description="Список веток группы"),
                    BotCommand(command="find", description="Поиск по базе знаний"),
                    BotCommand(command="ask", description="Спросить ИИ в ветке"),
                    BotCommand(command="search", description="Поиск в интернете + ответ ИИ"),
                    BotCommand(command="digest", description="Дайджест ветки / группы"),
                    BotCommand(command="compare", description="Сравнить 2 ссылки или репо"),
                    BotCommand(command="index", description="Навигатор по веткам"),
                    BotCommand(command="export", description="Экспорт базы знаний (.md)"),
                    BotCommand(command="test_net", description="Проверить интернет из песочницы"),
                    BotCommand(command="ban", description="Заблокировать пользователя"),
                    BotCommand(command="tempban", description="Временный бан пользователя"),
                    BotCommand(command="unban", description="Разблокировать пользователя"),
                    BotCommand(command="bans", description="Список блокировок"),
                ],
            )
        )
    except Exception as exc:
        logger.warning("Could not set Telethon bot commands: %s", exc)


def register_telethon_handlers(client: TelegramClient, bot_shim: TelethonBotShim, ctx: AppContext) -> None:
    admin_fsm: dict[tuple[int, int], str] = {}
    synced_chats: set[int] = set()

    async def is_admin(chat_id: int, is_group: bool, user_id: int) -> bool:
        if user_id in ctx.static_cfg.admin_user_ids:
            return True
        role = await ctx.db.get_bot_admin_role(user_id)
        if role == "granted":
            return True
        if role == "revoked":
            return False
        if is_group:
            try:
                member = await bot_shim.get_chat_member(chat_id, user_id)
                return member.status in {"creator", "administrator"}
            except Exception:
                return False
        return False

    async def resolve_tl_ban_target(msg: Any, token: str) -> tuple[int, str] | None:
        clean = token.strip()
        if clean.lstrip("-").isdigit():
            uid = int(clean)
            users = await ctx.db.list_known_users(limit=200)
            matched = next((u for u in users if u.user_id == uid), None)
            lbl = (matched.full_name or (f"@{matched.username}" if matched.username else "")) if matched else ""
            return uid, lbl or str(uid)
        if clean.startswith("@"):
            found = await ctx.db.find_user_by_username(clean)
            if found:
                return found.user_id, found.full_name or f"@{found.username}"
        if msg.is_reply:
            rep = await msg.get_reply_message()
            if rep is not None:
                s = await rep.get_sender()
                if s is not None:
                    return int(s.id), utils.get_display_name(s) or str(s.id)
        return None

    async def send_chunks(reply_to_msg: Any, chat_id: int, thread_id: int, text: str) -> None:
        chunks = [text[i : i + 3900] for i in range(0, len(text), 3900)] or ["(пустой ответ)"]
        for idx, chunk in enumerate(chunks):
            safe = html.escape(chunk)
            if idx == 0:
                await reply_to_msg.reply(safe, parse_mode="html", link_preview=False)
            else:
                await client.send_message(
                    chat_id,
                    safe,
                    reply_to=thread_id or None,
                    parse_mode="html",
                    link_preview=False,
                )

    async def extract_payload_from_msg(msg: Any) -> ExtractedPayload:
        settings = await ctx.db.get_settings()
        raw_text = (msg.raw_text or "").strip()
        if msg.fwd_from:
            raw_text = f"[Пересланное сообщение]\n{raw_text}".strip()

        file_name = ""
        file_bytes: bytes | None = None
        is_image = False

        if msg.document:
            for attr in getattr(msg.document, "attributes", []) or []:
                if isinstance(attr, DocumentAttributeFilename):
                    file_name = attr.file_name
                    break
            file_name = file_name or f"document_{msg.id}.bin"
            size = int(getattr(msg.document, "size", 0) or 0)
            if size <= ctx.static_cfg.sandbox_max_download_bytes:
                file_bytes = await msg.download_media(file=bytes)
            else:
                raw_text = (
                    f"{raw_text}\n[Файл {file_name}, размер {size} байт — превышает лимит песочницы]"
                ).strip()
        elif msg.photo:
            is_image = True
            file_name = f"photo_{msg.id}.jpg"
            file_bytes = await msg.download_media(file=bytes)

        return await ctx.analyzer.extract_payload(
            text=raw_text,
            settings=settings,
            file_name=file_name,
            file_bytes=file_bytes,
            is_image=is_image,
        )

    async def route_inbox_msg(msg: Any, payload: ExtractedPayload, status_msg: Any, chat_id: int, thread_id: int) -> None:
        settings = await ctx.db.get_settings()
        lang = await ctx.db.get_effective_language(chat_id)
        chat_rec = await ctx.db.get_chat(chat_id)
        topics = await ctx.db.list_topics(chat_id, include_inbox=False)

        sender = await msg.get_sender()
        author_id = int(getattr(sender, "id", 0) or msg.sender_id or 0)
        author_name = (
            utils.get_display_name(sender)
            if sender
            else ("Member" if lang == "en" else "Участник")
        ) or str(author_id)

        decision = await ctx.analyzer.analyze_and_classify(
            payload=payload,
            author_name=author_name,
            existing_topics=topics,
            settings=settings,
            chat_system_override=chat_rec.system_prompt_override if chat_rec else "",
            lang=lang,
        )

        target_topic = await ctx.router_svc.resolve_or_create_target_topic(
            bot_shim,  # type: ignore[arg-type]
            chat_id,
            decision,
        )

        source_link = build_topic_message_link(chat_id, msg.id, thread_id)
        card_html = format_routed_card_html(
            decision,
            author_id=author_id,
            author_name=author_name,
            source_link="" if settings.delete_inbox_after_route else source_link,
            lang=lang,
        )

        has_media = bool(msg.document or msg.photo or msg.video or msg.audio or msg.voice)
        saved_item = await ctx.db.save_routed_item(
            chat_id=chat_id,
            source_message_id=msg.id,
            source_thread_id=thread_id,
            target_thread_id=target_topic.thread_id,
            target_message_id=None,
            target_topic_name=target_topic.name,
            author_id=author_id,
            author_name=author_name,
            item_kind=decision.item_kind,
            title=decision.title,
            url=decision.primary_url,
            normalized_url=decision.normalized_url,
            file_hash=decision.file_hash,
            summary=decision.summary,
            why_needed=decision.why_needed,
            tags=decision.tags,
            raw_input=(msg.raw_text or "")[:2000],
        )

        target_msg_id = await ctx.router_svc.publish_to_topic(
            bot_shim,  # type: ignore[arg-type]
            chat_id=chat_id,
            target_topic=target_topic,
            card_html=card_html,
            source_message_id=msg.id,
            has_media=has_media,
            reply_markup=routed_item_keyboard(saved_item.id, lang),
        )
        await ctx.db.update_routed_item_target(
            saved_item.id,
            target_thread_id=target_topic.thread_id,
            target_message_id=target_msg_id,
            target_topic_name=target_topic.name,
        )

        target_link = build_topic_message_link(chat_id, target_msg_id, target_topic.thread_id)
        new_badge = t(lang, "new_topic_badge") if decision.create_new_topic else ""
        link_html = (
            f' <a href="{html.escape(target_link)}">{t(lang, "goto_card")}</a>'
            if target_link
            else ""
        )
        notes_html = (
            f"\n⚠️ <i>{html.escape(payload.extraction_notes[0][:140])}</i>"
            if payload.extraction_notes
            else ""
        )
        await status_msg.edit(
            t(
                lang,
                "routed_status",
                topic=html.escape(target_topic.name),
                new_badge=new_badge,
                title=html.escape(decision.title),
                link_html=link_html,
                notes_html=notes_html,
            ),
            parse_mode="html",
            link_preview=False,
        )
        if settings.delete_inbox_after_route:
            try:
                await bot_shim.delete_message(chat_id, msg.id)
            except Exception:
                pass

    @client.on(events.ChatAction)
    async def on_chat_action(event: events.ChatAction.Event) -> None:
        if not event.is_group:
            return
        chat = await event.get_chat()
        is_forum = bool(getattr(chat, "forum", False))
        chat_title = getattr(chat, "title", "") or ""
        await ctx.db.upsert_chat(event.chat_id, chat_title, is_forum)
        if is_forum and (event.user_added or event.user_joined):
            if event.user_id == ctx.bot_id or ctx.bot_id in (event.user_ids or []):
                await bot_shim.sync_forum_topics(event.chat_id, ctx)
                settings = await ctx.db.get_settings()
                lang = await ctx.db.get_effective_language(event.chat_id)
                await ctx.router_svc.ensure_inbox_topic(
                    bot_shim,  # type: ignore[arg-type]
                    event.chat_id,
                    chat_title,
                    settings,
                    lang=lang,
                )

    @client.on(events.NewMessage())
    async def on_new_message(event: events.NewMessage.Event) -> None:
        msg = event.message
        if msg is None or msg.out:
            return

        chat = await event.get_chat()
        chat_id = int(event.chat_id)
        is_group = bool(event.is_group)
        is_private = bool(event.is_private)
        is_forum = bool(getattr(chat, "forum", False)) if is_group else False
        chat_title = getattr(chat, "title", "") or ""
        thread_id = extract_thread_id(msg) if is_forum else 0

        sender = await msg.get_sender()
        if getattr(sender, "bot", False):
            return
        user_id = int(getattr(sender, "id", 0) or msg.sender_id or 0)
        author_name = (utils.get_display_name(sender) if sender else "") or str(user_id)

        await ctx.db.upsert_known_user(
            user_id=user_id,
            username=getattr(sender, "username", "") or "",
            full_name=author_name,
            last_chat_id=chat_id,
        )

        ban = await ctx.db.get_active_ban(chat_id, user_id)
        if ban is not None and not await is_admin(chat_id, is_group, user_id):
            txt_chk = (msg.raw_text or "").strip()
            bot_u = ctx.bot_username.lower()
            mentioned = bool(bot_u and f"@{bot_u}" in txt_chk.lower())
            if is_private or txt_chk.startswith("/") or mentioned:
                lang_b = await ctx.db.get_effective_language(chat_id)
                try:
                    await msg.reply(format_ban_notice(ban, lang_b), parse_mode="html")
                except Exception:
                    pass
            return

        # Track group, topics, auto-create Inbox, and save non-command message history
        if is_group:
            await ctx.db.upsert_chat(chat_id, chat_title, is_forum)
            if is_forum:
                if chat_id not in synced_chats:
                    synced_chats.add(chat_id)
                    await bot_shim.sync_forum_topics(chat_id, ctx)

                action = getattr(msg, "action", None)
                if isinstance(action, MessageActionTopicCreate):
                    await ctx.db.upsert_topic(chat_id, msg.id, action.title)
                    return
                if isinstance(action, MessageActionTopicEdit):
                    if action.title:
                        await ctx.db.update_topic_meta(chat_id, thread_id or msg.id, name=action.title)
                    if action.closed is not None:
                        await ctx.db.mark_topic_closed(chat_id, thread_id or msg.id, bool(action.closed))
                    return

                chat_rec = await ctx.db.get_chat(chat_id)
                if chat_rec and not chat_rec.inbox_thread_id:
                    settings = await ctx.db.get_settings()
                    lang = await ctx.db.get_effective_language(chat_id)
                    await bot_shim.sync_forum_topics(chat_id, ctx)
                    chat_rec = await ctx.db.get_chat(chat_id)
                    if chat_rec and not chat_rec.inbox_thread_id:
                        await ctx.router_svc.ensure_inbox_topic(
                            bot_shim,  # type: ignore[arg-type]
                            chat_id,
                            chat_title,
                            settings,
                            lang=lang,
                        )

            raw_hist = (msg.raw_text or "").strip()
            if raw_hist and not raw_hist.startswith("/"):
                await ctx.db.save_message(
                    chat_id=chat_id,
                    thread_id=thread_id,
                    message_id=msg.id,
                    user_id=user_id,
                    author_name=author_name,
                    text=raw_hist,
                    is_bot=False,
                )

        raw_text = (msg.raw_text or "").strip()
        cmd_parsed = parse_command(raw_text, ctx.bot_username)

        # Handle /cancel and active Admin FSM
        fsm_key = (chat_id, user_id)
        if cmd_parsed and cmd_parsed[0] == "cancel":
            if fsm_key in admin_fsm:
                admin_fsm.pop(fsm_key, None)
                await msg.reply("✖️ Действие отменено.")
            return

        if fsm_key in admin_fsm and raw_text and not raw_text.startswith("/"):
            if not await is_admin(chat_id, is_group, user_id):
                admin_fsm.pop(fsm_key, None)
            else:
                mode = admin_fsm.pop(fsm_key)
                lang = await ctx.db.get_effective_language(chat_id)
                if mode == "prompt":
                    await ctx.db.update_settings({"system_prompt": raw_text})
                    s = await ctx.db.get_settings()
                    await msg.reply(
                        f"✅ <b>Системник сохранён!</b>\n\n<blockquote>{html.escape(raw_text[:600])}</blockquote>",
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_main_keyboard(s, lang)),
                    )
                elif mode == "api_key":
                    await ctx.db.update_settings({"openai_api_key": raw_text})
                    try:
                        await msg.delete()
                    except Exception:
                        pass
                    await client.send_message(
                        chat_id,
                        f"✅ API ключ обновлён (<code>{_mask_secret(raw_text)}</code>).",
                        reply_to=thread_id or None,
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_model_keyboard(lang)),
                    )
                elif mode == "base_url":
                    url = raw_text.rstrip("/")
                    if not url.startswith(("http://", "https://")):
                        admin_fsm[fsm_key] = "base_url"
                        await msg.reply("⚠️ URL должен начинаться с http:// или https://. Попробуйте снова или /cancel.")
                        return
                    await ctx.db.update_settings({"openai_base_url": url})
                    await msg.reply(
                        f"✅ Base URL обновлён: <code>{html.escape(url)}</code>",
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_model_keyboard(lang)),
                    )
                elif mode == "model":
                    await ctx.db.update_settings({"openai_model": raw_text})
                    await msg.reply(
                        f"✅ Модель обновлена: <code>{html.escape(raw_text)}</code>",
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_model_keyboard(lang)),
                    )
                elif mode == "new_topic":
                    if not is_group or not is_forum:
                        await msg.reply("⚠️ Создание веток доступно только в форум-группах.")
                        return
                    name_p, desc_p = raw_text.split("|", 1) if "|" in raw_text else (raw_text, "")
                    try:
                        tg_tp = await bot_shim.create_forum_topic(chat_id, name_p.strip()[:120])
                        topic = await ctx.db.upsert_topic(
                            chat_id,
                            tg_tp.message_thread_id,
                            tg_tp.name,
                            description=desc_p.strip()[:300],
                            created_by_bot=True,
                        )
                        await msg.reply(
                            f"✅ Ветка <b>«{html.escape(topic.name)}»</b> создана (<code>{topic.thread_id}</code>).",
                            parse_mode="html",
                        )
                    except Exception as exc:
                        await msg.reply(f"❌ Не удалось создать ветку: <code>{html.escape(str(exc))}</code>", parse_mode="html")
                elif mode == "ban_perm":
                    parts_b = raw_text.split(maxsplit=1)
                    target = await resolve_tl_ban_target(msg, parts_b[0] if parts_b else "")
                    if target is None:
                        admin_fsm[fsm_key] = "ban_perm"
                        await msg.reply("⚠️ Укажите числовой `user_id` или `@username`, либо /cancel.")
                        return
                    uid, uname = target
                    reason = parts_b[1].strip() if len(parts_b) > 1 else ""
                    scope_c = chat_id if is_group else 0
                    await ctx.db.ban_user(chat_id=scope_c, user_id=uid, author_name=uname, reason=reason, banned_by=user_id, duration_seconds=None)
                    bans = await ctx.db.list_active_bans(scope_c if scope_c else None)
                    await msg.reply(
                        f"🔨 Заблокирован навсегда: <b>{html.escape(uname)}</b> (<code>{uid}</code>)",
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_bans_keyboard(bans, lang)),
                    )
                elif mode == "ban_temp":
                    tokens_b = raw_text.split()
                    target = await resolve_tl_ban_target(msg, tokens_b[0]) if len(tokens_b) >= 2 else None
                    dur = parse_duration_seconds(tokens_b[1]) if len(tokens_b) >= 2 else None
                    if target is None or dur is None:
                        admin_fsm[fsm_key] = "ban_temp"
                        await msg.reply("⚠️ Формат: <code>user_id 30m [причина]</code>, либо /cancel.", parse_mode="html")
                        return
                    uid, uname = target
                    reason = " ".join(tokens_b[2:])
                    scope_c = chat_id if is_group else 0
                    ban = await ctx.db.ban_user(chat_id=scope_c, user_id=uid, author_name=uname, reason=reason, banned_by=user_id, duration_seconds=dur)
                    bans = await ctx.db.list_active_bans(scope_c if scope_c else None)
                    await msg.reply(
                        f"⏳ Временно заблокирован до <code>{ban.expires_at}</code>: <b>{html.escape(uname)}</b> (<code>{uid}</code>)",
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_bans_keyboard(bans, lang)),
                    )
                return

        # --- Commands ---
        if cmd_parsed is not None:
            cmd, args = cmd_parsed
            lang = await ctx.db.get_effective_language(chat_id)

            if cmd in {"start", "lang"}:
                await msg.reply(
                    t("ru", "choose_lang"),
                    buttons=markup_to_telethon_buttons(language_select_keyboard()),
                )
                return

            if cmd == "help":
                if is_private:
                    await msg.reply(t(lang, "welcome_private", uid=user_id), parse_mode="html")
                elif is_forum:
                    settings = await ctx.db.get_settings()
                    res = await ctx.router_svc.ensure_inbox_topic(
                        bot_shim,  # type: ignore[arg-type]
                        chat_id,
                        chat_title,
                        settings,
                        lang=lang,
                    )
                    st = t(lang, "inbox_active", name=html.escape(res.topic.name)) if res.ok and res.topic else f"⚠️ {html.escape(res.error)}"
                    await msg.reply(t(lang, "welcome_group", inbox_status=st), parse_mode="html")
                else:
                    await msg.reply(t(lang, "welcome_group", inbox_status=t(lang, "topics_disabled")), parse_mode="html")
                return

            if cmd in {"setup", "inbox"}:
                if not is_group or not is_forum:
                    await msg.reply(t(lang, "topics_disabled"), parse_mode="html")
                    return
                await bot_shim.sync_forum_topics(chat_id, ctx)
                settings = await ctx.db.get_settings()
                res = await ctx.router_svc.ensure_inbox_topic(
                    bot_shim,  # type: ignore[arg-type]
                    chat_id,
                    chat_title,
                    settings,
                    lang=lang,
                )
                if res.ok and res.topic:
                    verb = ("created" if res.created else "already active") if lang == "en" else ("создана" if res.created else "уже активна")
                    await msg.reply(
                        f"✅ {'Topic' if lang == 'en' else 'Ветка'} <b>«{html.escape(res.topic.name)}»</b> {verb} (<code>{res.topic.thread_id}</code>).",
                        parse_mode="html",
                    )
                else:
                    await msg.reply(f"❌ {html.escape(res.error)}", parse_mode="html")
                return

            if cmd == "topics":
                if not is_group:
                    await msg.reply("Доступно в группе.")
                    return
                await bot_shim.sync_forum_topics(chat_id, ctx)
                topics = await ctx.db.list_topics(chat_id, include_inbox=True)
                if not topics:
                    await msg.reply("Ветки ещё не зарегистрированы. Запустите /setup.")
                    return
                lines = ["🗂 <b>Topics:</b>" if lang == "en" else "🗂 <b>Известные ветки группы:</b>", ""]
                for tp in topics:
                    badge = "📥" if tp.is_inbox else ("🔒" if tp.is_closed else "💬")
                    desc = f" — {html.escape(tp.description)}" if tp.description else ""
                    lines.append(f"{badge} <b>{html.escape(tp.name)}</b> (<code>{tp.thread_id}</code>){desc}")
                await msg.reply("\n".join(lines)[:4000], parse_mode="html")
                return

            if cmd == "register_topic":
                if not is_group or not await is_admin(chat_id, is_group, user_id):
                    await msg.reply("⛔ Только администратор.")
                    return
                if not thread_id or not args:
                    await msg.reply("Использование внутри ветки: <code>/register_topic Название | описание</code>", parse_mode="html")
                    return
                name_p, desc_p = args.split("|", 1) if "|" in args else (args, "")
                tp = await ctx.db.upsert_topic(chat_id, thread_id, name_p.strip()[:120], description=desc_p.strip()[:300])
                await msg.reply(f"✅ Ветка сохранена: <b>{html.escape(tp.name)}</b> (<code>{tp.thread_id}</code>)", parse_mode="html")
                return

            if cmd in {"admin", "system", "set_system", "set_topic_system", "set_model", "test_model", "test_net", "bans", "ban", "tempban", "unban"}:
                if not await is_admin(chat_id, is_group, user_id):
                    if is_private:
                        await msg.reply(
                            f"⛔ Добавьте свой ID <code>{user_id}</code> в <code>ADMIN_USER_IDS</code> в <code>.env</code> "
                            "или откройте <code>/admin</code> в группе с правами администратора.",
                            parse_mode="html",
                        )
                    else:
                        await msg.reply("⛔ Только для администраторов группы.")
                    return

                settings = await ctx.db.get_settings()
                if cmd == "admin":
                    admin_fsm.pop(fsm_key, None)
                    await msg.reply(
                        _admin_summary_html(settings, lang),
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_main_keyboard(settings, lang)),
                    )
                elif cmd == "system":
                    await msg.reply(
                        f"📝 <b>Системник:</b>\n<pre>{html.escape(settings.system_prompt[:3600])}</pre>",
                        parse_mode="html",
                    )
                elif cmd == "set_system":
                    prompt_txt = args
                    if not prompt_txt and msg.is_reply:
                        rep = await msg.get_reply_message()
                        prompt_txt = (getattr(rep, "raw_text", "") or "").strip()
                    if not prompt_txt:
                        await msg.reply("Использование: <code>/set_system Текст системника</code>", parse_mode="html")
                        return
                    await ctx.db.update_settings({"system_prompt": prompt_txt})
                    await msg.reply(
                        f"✅ <b>Системник обновлён!</b>\n\n<blockquote>{html.escape(prompt_txt[:600])}</blockquote>",
                        parse_mode="html",
                    )
                elif cmd == "set_topic_system":
                    if not is_group or not thread_id or not args:
                        await msg.reply("Использование внутри ветки: <code>/set_topic_system инструкция</code>", parse_mode="html")
                        return
                    val = "" if args.lower() in {"clear", "reset", "off"} else args
                    tp = await ctx.db.update_topic_meta(chat_id, thread_id, system_prompt=val)
                    await msg.reply(
                        f"✅ Локальный системник ветки «{html.escape(tp.name if tp else str(thread_id))}» обновлён.",
                        parse_mode="html",
                    )
                elif cmd == "set_model":
                    parts = args.split()
                    if not parts:
                        await msg.reply("Использование: <code>/set_model model_name [base_url]</code>", parse_mode="html")
                        return
                    upd = {"openai_model": parts[0]}
                    if len(parts) > 1:
                        upd["openai_base_url"] = parts[1].rstrip("/")
                    s = await ctx.db.update_settings(upd)
                    await msg.reply(
                        f"✅ Модель: <code>{html.escape(s.openai_model)}</code>\nBase URL: <code>{html.escape(s.openai_base_url)}</code>",
                        parse_mode="html",
                    )
                elif cmd == "test_model":
                    wait = await msg.reply("⏳ Проверяю модель...")
                    res = await ctx.llm.test_connection(settings)
                    if res.ok:
                        await wait.edit(
                            f"✅ <b>Модель отвечает!</b> <code>{html.escape(res.model)}</code> ({res.latency_ms} мс): <code>{html.escape(res.reply_preview)}</code>",
                            parse_mode="html",
                        )
                    else:
                        await wait.edit(f"❌ <b>Ошибка:</b> <code>{html.escape(res.error)}</code>", parse_mode="html")
                elif cmd == "test_net":
                    wait = await msg.reply("⏳ Проверяю песочницу...")
                    report = await _run_sandbox_self_test(ctx, args or "https://api.github.com/zen", lang)
                    await wait.edit(report, parse_mode="html", link_preview=False)
                elif cmd == "bans":
                    scope_c = chat_id if is_group else None
                    bans = await ctx.db.list_active_bans(scope_c)
                    await msg.reply(_format_bans_html(bans, lang), parse_mode="html", buttons=markup_to_telethon_buttons(admin_bans_keyboard(bans, lang)))
                elif cmd == "ban":
                    parts_b = args.split(maxsplit=1) if args else []
                    target = await resolve_tl_ban_target(msg, parts_b[0] if parts_b else "")
                    reason = parts_b[1].strip() if len(parts_b) > 1 else ""
                    if target is None and msg.is_reply:
                        target = await resolve_tl_ban_target(msg, "")
                        reason = args
                    if target is None:
                        await msg.reply("Использование: <code>/ban user_id [причина]</code> или реплаем.", parse_mode="html")
                        return
                    uid, uname = target
                    scope_c = chat_id if is_group else 0
                    await ctx.db.ban_user(chat_id=scope_c, user_id=uid, author_name=uname, reason=reason, banned_by=user_id, duration_seconds=None)
                    await msg.reply(f"🔨 Заблокирован навсегда: <b>{html.escape(uname)}</b> (<code>{uid}</code>)", parse_mode="html")
                elif cmd == "tempban":
                    tokens_b = args.split()
                    target = await resolve_tl_ban_target(msg, tokens_b[0]) if len(tokens_b) >= 2 else None
                    dur = parse_duration_seconds(tokens_b[1]) if len(tokens_b) >= 2 else None
                    reason = " ".join(tokens_b[2:])
                    if (target is None or dur is None) and tokens_b and msg.is_reply:
                        dur = parse_duration_seconds(tokens_b[0])
                        target = await resolve_tl_ban_target(msg, "")
                        reason = " ".join(tokens_b[1:])
                    if target is None or dur is None:
                        await msg.reply("Использование: <code>/tempban user_id 30m [причина]</code> или реплаем <code>/tempban 1h</code>.", parse_mode="html")
                        return
                    uid, uname = target
                    scope_c = chat_id if is_group else 0
                    ban = await ctx.db.ban_user(chat_id=scope_c, user_id=uid, author_name=uname, reason=reason, banned_by=user_id, duration_seconds=dur)
                    await msg.reply(f"⏳ Временно заблокирован до <code>{ban.expires_at}</code>: <b>{html.escape(uname)}</b> (<code>{uid}</code>)", parse_mode="html")
                elif cmd == "unban":
                    target = await resolve_tl_ban_target(msg, args.split()[0] if args else "")
                    if target is None:
                        await msg.reply("Использование: <code>/unban user_id</code> или реплаем.", parse_mode="html")
                        return
                    uid, uname = target
                    scope_c = chat_id if is_group else 0
                    ok = await ctx.db.unban_user(scope_c, uid)
                    await msg.reply(f"✅ Разблокирован: <b>{html.escape(uname)}</b>" if ok else "Не найден в банах.", parse_mode="html")
                return

            if cmd == "find":
                if not is_group or not args:
                    await msg.reply("Использование в группе: <code>/find запрос</code>", parse_mode="html")
                    return
                items = await ctx.db.search_items(chat_id, args, limit=8)
                await msg.reply(ctx.assistant.format_search_results_html(args, items, lang=lang), parse_mode="html", link_preview=False)
                return

            if cmd == "index":
                if not is_group:
                    await msg.reply("Доступно в группе.")
                    return
                idx_html = await ctx.assistant.build_index_html(chat_id, lang=lang)
                await msg.reply(
                    idx_html,
                    parse_mode="html",
                    link_preview=False,
                    buttons=markup_to_telethon_buttons(index_keyboard(lang)),
                )
                return

            if cmd == "export":
                if not is_group:
                    await msg.reply("Доступно в группе.")
                    return
                md = await ctx.assistant.build_export_markdown(chat_id, chat_title or str(chat_id), lang=lang)
                bio = io.BytesIO(md.encode("utf-8"))
                bio.name = "knowledge_base.md"
                await client.send_file(
                    chat_id,
                    bio,
                    caption="📦 База знаний группы (Markdown)." if lang != "en" else "📦 Knowledge base (Markdown).",
                    reply_to=msg.id,
                )
                return

            if cmd == "digest":
                if not is_group:
                    await msg.reply("Доступно в группе.")
                    return
                chat_rec = await ctx.db.get_chat(chat_id)
                in_inbox = bool(chat_rec and chat_rec.inbox_thread_id and thread_id == chat_rec.inbox_thread_id)
                group_wide = (args.lower() in {"all", "group", "week", "неделя", "вся"}) or (thread_id == 0) or in_inbox
                wait = await msg.reply(t(lang, "digesting"))
                settings = await ctx.db.get_settings()
                try:
                    digest_txt = await ctx.assistant.build_digest(
                        chat_id=chat_id,
                        thread_id=thread_id,
                        settings=settings,
                        lang=lang,
                        group_wide=group_wide,
                    )
                    if group_wide and is_forum:
                        d_name = "📢 Digests" if lang == "en" else "📢 Дайджесты"
                        d_topic = await ctx.router_svc.ensure_named_topic(
                            bot_shim,  # type: ignore[arg-type]
                            chat_id,
                            d_name,
                            description="Group knowledge digests",
                        )
                        header = f"📢 <b>{'Group Digest' if lang == 'en' else 'Дайджест группы'}</b>\n\n"
                        sent = await bot_shim.send_message(
                            chat_id,
                            (header + html.escape(digest_txt))[:4000],
                            message_thread_id=d_topic.thread_id,
                            disable_web_page_preview=True,
                        )
                        lnk = build_topic_message_link(chat_id, sent.message_id, d_topic.thread_id)
                        lp = f' → <a href="{html.escape(lnk)}">{t(lang, "goto_card")}</a>' if lnk else ""
                        await wait.edit(f"✅ <b>Опубликовано в «{html.escape(d_topic.name)}»</b>{lp}", parse_mode="html", link_preview=False)
                    else:
                        await wait.edit(
                            html.escape(digest_txt[:4000]),
                            parse_mode="html",
                            buttons=markup_to_telethon_buttons(digest_publish_keyboard(thread_id, lang)) if is_forum else None,
                        )
                except Exception as exc:
                    await wait.edit(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")
                return

            if cmd == "compare":
                raw_cmp = args
                if msg.is_reply:
                    rep = await msg.get_reply_message()
                    raw_cmp = f"{raw_cmp} {getattr(rep, 'raw_text', '') or ''}".strip()
                urls = extract_urls(raw_cmp)
                if len(urls) < 2:
                    await msg.reply("Использование: <code>/compare https://url1 https://url2</code>", parse_mode="html")
                    return
                wait = await msg.reply("⏳ Загружаю обе ссылки из песочницы и сравниваю...")
                settings = await ctx.db.get_settings()
                try:
                    cmp_txt = await ctx.assistant.compare_urls(urls[0], urls[1], settings, lang=lang)
                    await wait.delete()
                    await send_chunks(msg, chat_id, thread_id, cmp_txt)
                except Exception as exc:
                    await wait.edit(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")
                return

            if cmd in {"ask", "search"}:
                q = args
                if not q and msg.is_reply:
                    rep = await msg.get_reply_message()
                    q = (getattr(rep, "raw_text", "") or "").strip()
                if not q:
                    await msg.reply("Использование: <code>/ask вопрос</code>", parse_mode="html")
                    return
                force_web = cmd == "search"
                wait = await msg.reply(t(lang, "searching") if force_web else t(lang, "thinking"))
                settings = await ctx.db.get_settings()
                try:
                    ans = await ctx.assistant.answer_question(
                        chat_id=chat_id,
                        thread_id=thread_id,
                        user_name=author_name,
                        question=q,
                        settings=settings,
                        force_web_search=force_web,
                        lang=lang,
                    )
                    await wait.delete()
                    await send_chunks(msg, chat_id, thread_id, ans)
                except Exception as exc:
                    await wait.edit(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")
                return

        # --- Inbox Auto-Routing ---
        if is_group and is_forum:
            chat_rec = await ctx.db.get_chat(chat_id)
            if chat_rec and chat_rec.inbox_thread_id and thread_id == chat_rec.inbox_thread_id:
                if not raw_text and not any([msg.document, msg.photo, msg.video, msg.audio, msg.voice]):
                    return
                lang = await ctx.db.get_effective_language(chat_id)
                status_msg = await msg.reply(t(lang, "analyzing"))
                try:
                    payload = await extract_payload_from_msg(msg)
                    dup = await ctx.db.find_duplicate_item(
                        chat_id,
                        normalized_url=payload.normalized_url,
                        file_hash=payload.file_hash,
                    )
                    if dup is not None:
                        _cache_put(chat_id, msg.id, msg, payload)
                        dup_link = build_topic_message_link(chat_id, dup.target_message_id, dup.target_thread_id)
                        link_part = (
                            f' (<a href="{html.escape(dup_link)}">{t(lang, "dup_open")}</a>)'
                            if dup_link
                            else ""
                        )
                        await status_msg.edit(
                            t(
                                lang,
                                "dup_found",
                                title=html.escape(dup.title),
                                topic=html.escape(dup.target_topic_name),
                                link_part=link_part,
                            ),
                            parse_mode="html",
                            link_preview=False,
                            buttons=markup_to_telethon_buttons(duplicate_override_keyboard(msg.id, lang)),
                        )
                        return

                    await route_inbox_msg(msg, payload, status_msg, chat_id, thread_id)
                except LLMConfigError as exc:
                    await status_msg.edit(f"⚠️ {html.escape(str(exc))}", parse_mode="html")
                except Exception as exc:
                    logger.exception("Telethon inbox routing error")
                    await status_msg.edit(f"❌ <code>{html.escape(str(exc)[:300])}</code>", parse_mode="html")
                return

        # --- Mention / Reply / Private Q&A ---
        should_answer = False
        question = raw_text
        if is_private and raw_text:
            should_answer = True
        elif is_group and raw_text:
            bot_uname = ctx.bot_username.lower()
            mentioned = bool(bot_uname and f"@{bot_uname}" in raw_text.lower())
            replied_to_bot = False
            if msg.is_reply:
                rep = await msg.get_reply_message()
                if rep is not None and rep.sender_id == ctx.bot_id and not isinstance(getattr(rep, "action", None), MessageActionTopicCreate):
                    replied_to_bot = True
            if mentioned or replied_to_bot:
                should_answer = True
                if bot_uname:
                    question = re.sub(rf"@{re.escape(bot_uname)}\b", "", raw_text, flags=re.IGNORECASE).strip() or "Помоги по теме."

        if should_answer:
            lang = await ctx.db.get_effective_language(chat_id)
            settings = await ctx.db.get_settings()
            try:
                ans = await ctx.assistant.answer_question(
                    chat_id=chat_id,
                    thread_id=thread_id,
                    user_name=author_name,
                    question=question,
                    settings=settings,
                    lang=lang,
                )
                await send_chunks(msg, chat_id, thread_id, ans)
            except Exception as exc:
                await msg.reply(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")

    @client.on(events.CallbackQuery)
    async def on_callback(event: events.CallbackQuery.Event) -> None:
        data = (event.data or b"").decode("utf-8", errors="replace")
        chat_id = int(event.chat_id)
        is_group = bool(event.is_group)
        user_id = int(event.sender_id or 0)
        msg = await event.get_message()

        ban = await ctx.db.get_active_ban(chat_id, user_id)
        if ban is not None and not await is_admin(chat_id, is_group, user_id):
            await event.answer("⛔ Доступ заблокирован / Access denied", alert=True)
            return

        if data.startswith("lang:set:"):
            chosen = normalize_lang(data.split(":")[2])
            if is_group and not await is_admin(chat_id, True, user_id):
                await event.answer(t(chosen, "lang_admin_only"), alert=True)
                return
            chat_obj = await event.get_chat()
            is_forum = bool(getattr(chat_obj, "forum", False)) if is_group else False
            chat_title = getattr(chat_obj, "title", "") or ("DM" if not is_group else "")
            await ctx.db.set_chat_language(chat_id, chosen, title=chat_title, is_forum=is_forum)
            if not is_group and (user_id in ctx.static_cfg.admin_user_ids or not ctx.static_cfg.admin_user_ids):
                await ctx.db.update_settings({"language": chosen})

            await event.answer("OK")
            if not is_group:
                body = t(chosen, "welcome_private", uid=user_id)
            elif is_forum:
                settings = await ctx.db.get_settings()
                res = await ctx.router_svc.ensure_inbox_topic(
                    bot_shim,  # type: ignore[arg-type]
                    chat_id,
                    chat_title,
                    settings,
                    lang=chosen,
                )
                st = t(chosen, "inbox_active", name=html.escape(res.topic.name)) if res.ok and res.topic else f"⚠️ {html.escape(res.error)}"
                body = t(chosen, "welcome_group", inbox_status=st)
            else:
                body = t(chosen, "welcome_group", inbox_status=t(chosen, "topics_disabled"))
            await event.edit(
                f"{t(chosen, 'lang_updated')}\n\n{body}",
                parse_mode="html",
                buttons=markup_to_telethon_buttons(language_select_keyboard()),
            )
            return

        if data.startswith("adm:"):
            if not await is_admin(chat_id, is_group, user_id):
                await event.answer("⛔ Только для администраторов.", alert=True)
                return
            action = data.split(":", 1)[1]
            settings = await ctx.db.get_settings()
            lang = await ctx.db.get_effective_language(chat_id)
            fsm_key = (chat_id, user_id)
            cb_thread_id = (extract_thread_id(msg) or None) if msg is not None else None

            if action == "tog_lang":
                new_lang = "en" if lang == "ru" else "ru"
                chat_obj = await event.get_chat()
                await ctx.db.set_chat_language(chat_id, new_lang, title=getattr(chat_obj, "title", "") or "", is_forum=bool(getattr(chat_obj, "forum", False)))
                if not is_group:
                    await ctx.db.update_settings({"language": new_lang})
                await event.edit(
                    _admin_summary_html(settings, new_lang),
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_main_keyboard(settings, new_lang)),
                )
                await event.answer("Language: EN" if new_lang == "en" else "Язык: RU")
                return

            if action == "home":
                admin_fsm.pop(fsm_key, None)
                await event.edit(
                    _admin_summary_html(settings, lang),
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_main_keyboard(settings, lang)),
                )
                await event.answer()
                return

            if action == "show_prompt":
                await event.answer()
                await client.send_message(
                    chat_id,
                    f"📝 <b>Системник:</b>\n<pre>{html.escape(settings.system_prompt[:3800])}</pre>",
                    reply_to=cb_thread_id,
                    parse_mode="html",
                )
                return

            fsm_prompts = {
                "prompt": ("prompt", "✏️ Отправьте новый системник следующим сообщением (отмена: /cancel)."),
                "set_key": ("api_key", "🔑 Отправьте новый API Key (отмена: /cancel)."),
                "set_url": ("base_url", "🌐 Отправьте новый OpenAI-compatible Base URL (отмена: /cancel)."),
                "set_model": ("model", "🧠 Отправьте имя модели (отмена: /cancel)."),
                "create_topic": ("new_topic", "➕ Отправьте название новой ветки (можно `Название | описание`, отмена: /cancel)."),
                "ban_perm": ("ban_perm", "🔨 Отправьте `user_id [причина]` или `@username [причина]` (отмена: /cancel)."),
                "ban_temp": ("ban_temp", "⏳ Отправьте `user_id <длительность 30m/2h/1d> [причина]` (отмена: /cancel)."),
            }
            if action in fsm_prompts:
                state_name, prompt_msg = fsm_prompts[action]
                admin_fsm[fsm_key] = state_name
                await event.answer()
                await client.send_message(chat_id, prompt_msg, reply_to=cb_thread_id)
                return

            if action == "model":
                await event.edit(
                    "🤖 <b>OpenAI-compatible модель:</b>\n\n"
                    f"• Модель: <code>{html.escape(settings.openai_model)}</code>\n"
                    f"• Base URL: <code>{html.escape(settings.openai_base_url)}</code>\n"
                    f"• API Key: <code>{_mask_secret(settings.openai_api_key)}</code>",
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_model_keyboard(lang)),
                )
                await event.answer()
                return

            if action == "test_model":
                await event.answer("Проверяю...")
                res = await ctx.llm.test_connection(settings)
                if res.ok:
                    await client.send_message(
                        chat_id,
                        f"✅ <b>Модель отвечает!</b> <code>{html.escape(res.model)}</code> ({res.latency_ms} мс): <code>{html.escape(res.reply_preview)}</code>",
                        reply_to=cb_thread_id,
                        parse_mode="html",
                    )
                else:
                    await client.send_message(
                        chat_id,
                        f"❌ <b>Ошибка:</b> <code>{html.escape(res.error)}</code>",
                        reply_to=cb_thread_id,
                        parse_mode="html",
                    )
                return

            if action == "sandbox":
                await event.edit(
                    "🛡 <b>Политика песочницы и сортировки:</b>",
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_sandbox_keyboard(settings, lang)),
                )
                await event.answer()
                return

            toggle_map = {
                "tog_inet": ("sandbox_internet_enabled", settings.sandbox_internet_enabled),
                "tog_qa_web": ("web_search_in_qa", settings.web_search_in_qa),
                "tog_auto_topics": ("auto_create_topics", settings.auto_create_topics),
                "tog_del_inbox": ("delete_inbox_after_route", settings.delete_inbox_after_route),
            }
            if action in toggle_map:
                field_name, cur_val = toggle_map[action]
                settings = await ctx.db.update_settings({field_name: not cur_val})
                await event.edit(buttons=markup_to_telethon_buttons(admin_sandbox_keyboard(settings, lang)))
                await event.answer("OK")
                return

            if action == "test_sandbox":
                await event.answer("Проверяю песочницу...")
                report = await _run_sandbox_self_test(ctx, "https://api.github.com/zen", lang)
                await client.send_message(chat_id, report, reply_to=cb_thread_id, parse_mode="html", link_preview=False)
                return

            if action == "topics":
                if is_group:
                    await bot_shim.sync_forum_topics(chat_id, ctx)
                    topics = await ctx.db.list_topics(chat_id, include_inbox=True)
                    t_block = "\n".join(f"{'📥' if tp.is_inbox else '💬'} <b>{html.escape(tp.name)}</b> (<code>{tp.thread_id}</code>)" for tp in topics[:25]) or "Нет веток."
                else:
                    t_block = "Откройте в группе."
                await event.edit(
                    f"🗂 <b>Ветки:</b>\n\n{t_block}",
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_topics_keyboard(is_group, lang)),
                )
                await event.answer()
                return

            if action == "ensure_inbox":
                if not is_group:
                    await event.answer("Только для групп", alert=True)
                    return
                chat_obj = await event.get_chat()
                res = await ctx.router_svc.ensure_inbox_topic(
                    bot_shim,  # type: ignore[arg-type]
                    chat_id,
                    getattr(chat_obj, "title", "") or "",
                    settings,
                    lang=lang,
                )
                await event.answer(f"Готово: {res.topic.name}" if res.ok and res.topic else res.error[:180], alert=True)
                return

            if action == "bans":
                scope_c = chat_id if is_group else None
                bans = await ctx.db.list_active_bans(scope_c)
                await event.edit(
                    _format_bans_html(bans, lang),
                    parse_mode="html",
                    buttons=markup_to_telethon_buttons(admin_bans_keyboard(bans, lang)),
                )
                await event.answer()
                return

            if action.startswith("unban:"):
                parts_u = action.split(":")
                if len(parts_u) == 3 and parts_u[1].lstrip("-").isdigit() and parts_u[2].lstrip("-").isdigit():
                    await ctx.db.unban_user(int(parts_u[1]), int(parts_u[2]))
                    scope_c = chat_id if is_group else None
                    bans = await ctx.db.list_active_bans(scope_c)
                    await event.edit(
                        _format_bans_html(bans, lang),
                        parse_mode="html",
                        buttons=markup_to_telethon_buttons(admin_bans_keyboard(bans, lang)),
                    )
                    await event.answer("✅ Разблокирован")
                return

            if action == "stats":
                stats = await ctx.db.get_stats(chat_id if is_group else None)
                bans = await ctx.db.list_active_bans(chat_id if is_group else None)
                await event.answer()
                await client.send_message(
                    chat_id,
                    f"📊 Веток: <b>{stats['topics']}</b> | Материалов: <b>{stats['routed_items']}</b> | Сообщений: <b>{stats['messages']}</b> | Банов: <b>{len(bans)}</b>",
                    reply_to=cb_thread_id,
                    parse_mode="html",
                )
                return

        if data.startswith("inbox:force:"):
            src_id = int(data.split(":")[2])
            cached = _FORCE_CACHE.pop((chat_id, src_id), None)
            if cached is None or msg is None:
                await event.answer("Кэш устарел, отправьте материал ещё раз.", alert=True)
                return
            orig_msg, payload = cached
            await event.answer("Разбираю...")
            await event.edit("⏳ Анализирую...")
            try:
                await route_inbox_msg(orig_msg, payload, msg, chat_id, extract_thread_id(orig_msg))
            except Exception as exc:
                await event.edit(f"❌ <code>{html.escape(str(exc)[:300])}</code>", parse_mode="html")
            return

        if data.startswith("reroute:"):
            parts = data.split(":")
            action = parts[1]
            item_id = int(parts[2])
            item = await ctx.db.get_routed_item(item_id)
            if item is None:
                await event.answer("Не найдено", alert=True)
                return
            if not await is_admin(chat_id, is_group, user_id) and user_id != item.author_id:
                await event.answer("Только автор или администратор.", alert=True)
                return
            lang = await ctx.db.get_effective_language(item.chat_id)
            if action == "menu":
                topics = await ctx.db.list_topics(item.chat_id, include_inbox=False)
                await event.edit(buttons=markup_to_telethon_buttons(reroute_topics_keyboard(item.id, topics, item.target_thread_id)))
                await event.answer()
            elif action == "cancel":
                await event.edit(buttons=markup_to_telethon_buttons(routed_item_keyboard(item.id, lang)))
                await event.answer()
            elif action == "to" and len(parts) >= 4:
                new_tid = int(parts[3])
                new_tp = await ctx.db.get_topic(item.chat_id, new_tid)
                if new_tp is None:
                    await event.answer("Ветка не найдена", alert=True)
                    return
                await event.answer(f"Переношу в {new_tp.name}...")
                await ctx.router_svc.reroute_existing_item(
                    bot_shim,  # type: ignore[arg-type]
                    item,
                    new_tp,
                    reply_markup=routed_item_keyboard(item.id, lang),
                    lang=lang,
                )
            return

        if data.startswith("item:"):
            parts = data.split(":")
            if len(parts) >= 3 and parts[2].isdigit():
                act = parts[1]
                item_id = int(parts[2])
                item = await ctx.db.get_routed_item(item_id)
                if item is None or msg is None:
                    await event.answer("Не найдено", alert=True)
                    return
                lang = await ctx.db.get_effective_language(item.chat_id)
                settings = await ctx.db.get_settings()
                cb_tid = extract_thread_id(msg) or item.target_thread_id or None
                if act == "spec":
                    await event.answer("Генерирую ТЗ...")
                    wait = await msg.reply("⏳ Генерирую задачу / ТЗ на основе материала...")
                    try:
                        spec_txt = await ctx.assistant.generate_item_spec(item, settings, lang=lang)
                        hdr = f"📝 <b>{'Developer Task / Spec' if lang == 'en' else 'Задача / ТЗ'}: {html.escape(item.title)}</b>\n\n"
                        await wait.edit((hdr + html.escape(spec_txt))[:4000], parse_mode="html", link_preview=False)
                    except Exception as exc:
                        await wait.edit(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")
                elif act == "review":
                    await event.answer("Оцениваю плюсы и риски...")
                    wait = await msg.reply("⏳ Оцениваю плюсы, минусы и риски...")
                    try:
                        rev_txt = await ctx.assistant.generate_item_review(item, settings, lang=lang)
                        hdr = f"⚖️ <b>{'Tech Review' if lang == 'en' else 'Плюсы и риски'}: {html.escape(item.title)}</b>\n\n"
                        await wait.edit((hdr + html.escape(rev_txt))[:4000], parse_mode="html", link_preview=False)
                    except Exception as exc:
                        await wait.edit(f"❌ <code>{html.escape(str(exc)[:250])}</code>", parse_mode="html")
            return

        if data.startswith("digest:pub:"):
            if msg is None or not is_group:
                return
            chat_obj = await event.get_chat()
            if not getattr(chat_obj, "forum", False):
                await event.answer("Topics disabled", alert=True)
                return
            lang = await ctx.db.get_effective_language(chat_id)
            d_name = "📢 Digests" if lang == "en" else "📢 Дайджесты"
            d_topic = await ctx.router_svc.ensure_named_topic(bot_shim, chat_id, d_name, description="Digests")  # type: ignore[arg-type]
            txt = msg.raw_text or ""
            await bot_shim.send_message(
                chat_id,
                f"📢 <b>{'Digest' if lang == 'en' else 'Дайджест'}</b>\n\n{html.escape(txt[:3800])}",
                message_thread_id=d_topic.thread_id,
                disable_web_page_preview=True,
            )
            await event.answer(f"✅ «{d_topic.name}»")
            return

        if data == "idx:pin":
            if not await is_admin(chat_id, is_group, user_id) or msg is None:
                await event.answer("⛔ Только для администраторов", alert=True)
                return
            try:
                await bot_shim.pin_chat_message(chat_id, msg.id, disable_notification=True)
                await event.answer("📌 Закреплено!")
            except Exception as exc:
                await event.answer(str(exc)[:180], alert=True)
