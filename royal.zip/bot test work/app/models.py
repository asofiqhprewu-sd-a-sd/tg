from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ChatRecord:
    chat_id: int
    title: str
    is_forum: bool
    inbox_thread_id: int | None = None
    system_prompt_override: str = ""
    language: str = "ru"
    created_at: str = ""


@dataclass
class TopicRecord:
    id: int
    chat_id: int
    thread_id: int
    name: str
    description: str = ""
    system_prompt: str = ""
    is_inbox: bool = False
    is_closed: bool = False
    created_by_bot: bool = False
    created_at: str = ""


@dataclass
class RoutedItemRecord:
    id: int
    chat_id: int
    source_message_id: int
    source_thread_id: int
    target_thread_id: int
    target_message_id: int | None
    target_topic_name: str
    author_id: int
    author_name: str
    item_kind: str
    title: str
    url: str
    normalized_url: str
    file_hash: str
    summary: str
    why_needed: str
    tags: list[str] = field(default_factory=list)
    raw_input: str = ""
    created_at: str = ""


@dataclass
class MessageRecord:
    id: int
    chat_id: int
    thread_id: int
    message_id: int
    user_id: int
    author_name: str
    text: str
    is_bot: bool = False
    created_at: str = ""


@dataclass
class KnownUserRecord:
    user_id: int
    username: str = ""
    full_name: str = ""
    last_chat_id: int = 0
    last_seen_at: str = ""


@dataclass
class BotAdminRecord:
    user_id: int
    username: str = ""
    full_name: str = ""
    role: str = "granted"  # "granted" | "revoked"
    updated_at: str = ""


@dataclass
class UserBanRecord:
    id: int
    chat_id: int
    user_id: int
    author_name: str = ""
    reason: str = ""
    banned_by: int = 0
    expires_at: str | None = None  # ISO UTC string or None for permanent ban
    created_at: str = ""
