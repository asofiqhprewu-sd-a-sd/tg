from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

DEFAULT_SYSTEM_PROMPT = (
    "Ты — умный ИИ-помощник командной Telegram-группы с ветками (форумом). "
    "Твоя главная задача: помогать участникам структурировать знания, изучать внешние ссылки, "
    "репозитории и файлы, понятно объяснять что это и зачем это нужно команде, и точно распределять "
    "материалы по тематическим веткам.\n\n"
    "Принципы:\n"
    "1. Отвечай по делу, структурированно и на русском языке (если пользователь не просит другой).\n"
    "2. При разборе ссылок, репозиториев и файлов выделяй: суть, ключевые возможности/стек, "
    "практическую пользу для команды и подходящую ветку.\n"
    "3. Не выдумывай факты о содержимом ссылок или файлов — опирайся только на извлечённые из песочницы данные."
)


def _parse_bool(val: str | None, default: bool) -> bool:
    if val is None or val.strip() == "":
        return default
    return val.strip().lower() in {"1", "true", "yes", "on", "да"}


def _parse_int_set(val: str | None) -> set[int]:
    if not val:
        return set()
    result: set[int] = set()
    for part in val.split(","):
        part = part.strip()
        if part and part.lstrip("-").isdigit():
            result.add(int(part))
    return result


@dataclass(frozen=True)
class StaticConfig:
    """Startup environment configuration."""

    bot_token: str
    admin_user_ids: set[int]
    openai_api_key: str
    openai_base_url: str
    openai_model: str
    github_token: str
    inbox_topic_name: str
    db_path: Path
    sandbox_work_dir: Path
    sandbox_internet_enabled: bool
    sandbox_proxy_url: str
    sandbox_timeout_seconds: int
    sandbox_max_download_bytes: int
    web_admin_enabled: bool
    web_admin_host: str
    web_admin_port: int
    web_admin_token: str
    telegram_proxy_url: str = ""
    telegram_transport: str = "auto"
    telegram_api_id: int = 0
    telegram_api_hash: str = ""
    telethon_session_path: str = "data/telethon_bot"
    mtproto_proxy_host: str = ""
    mtproto_proxy_port: int = 0
    mtproto_proxy_secret: str = ""

    @classmethod
    def from_env(cls) -> "StaticConfig":
        max_mb = int(os.getenv("SANDBOX_MAX_DOWNLOAD_MB", "15"))
        return cls(
            bot_token=os.getenv("BOT_TOKEN", "").strip(),
            admin_user_ids=_parse_int_set(os.getenv("ADMIN_USER_IDS") or "7100434873"),
            openai_api_key=os.getenv("OPENAI_API_KEY", "").strip(),
            openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip().rstrip("/"),
            openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip(),
            github_token=os.getenv("GITHUB_TOKEN", "").strip(),
            inbox_topic_name=os.getenv("INBOX_TOPIC_NAME", "📥 Входящие").strip() or "📥 Входящие",
            db_path=Path(os.getenv("DB_PATH", "data/bot.db")),
            sandbox_work_dir=Path(os.getenv("SANDBOX_WORK_DIR", "data/sandbox")),
            sandbox_internet_enabled=_parse_bool(os.getenv("SANDBOX_INTERNET_ENABLED"), True),
            sandbox_proxy_url=os.getenv("SANDBOX_PROXY_URL", "").strip(),
            sandbox_timeout_seconds=max(5, int(os.getenv("SANDBOX_TIMEOUT_SECONDS", "20"))),
            sandbox_max_download_bytes=max(1, max_mb) * 1024 * 1024,
            web_admin_enabled=_parse_bool(os.getenv("WEB_ADMIN_ENABLED"), True),
            web_admin_host=os.getenv("WEB_ADMIN_HOST", "127.0.0.1").strip(),
            web_admin_port=int(os.getenv("WEB_ADMIN_PORT", "8080")),
            web_admin_token=os.getenv("WEB_ADMIN_TOKEN", "").strip(),
            telegram_proxy_url=os.getenv("TELEGRAM_PROXY_URL", "").strip(),
            telegram_transport=os.getenv("TELEGRAM_TRANSPORT", "auto").strip().lower() or "auto",
            telegram_api_id=int(os.getenv("TELEGRAM_API_ID", "0").strip() or "0"),
            telegram_api_hash=os.getenv("TELEGRAM_API_HASH", "").strip(),
            telethon_session_path=os.getenv("TELETHON_SESSION_PATH", "data/telethon_bot").strip() or "data/telethon_bot",
            mtproto_proxy_host=os.getenv("MTPROTO_PROXY_HOST", "").strip(),
            mtproto_proxy_port=int(os.getenv("MTPROTO_PROXY_PORT", "0").strip() or "0"),
            mtproto_proxy_secret=os.getenv("MTPROTO_PROXY_SECRET", "").strip(),
        )


@dataclass
class RuntimeSettings:
    """Dynamic settings stored in SQLite and editable via Admin Panel."""

    system_prompt: str = DEFAULT_SYSTEM_PROMPT
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o-mini"
    openai_temperature: float = 0.3
    openai_max_tokens: int = 1500
    inbox_topic_name: str = "📥 Входящие"
    language: str = "ru"
    sandbox_internet_enabled: bool = True
    sandbox_proxy_url: str = ""
    sandbox_allowed_domains: str = ""
    sandbox_blocked_domains: str = ""
    auto_create_topics: bool = True
    delete_inbox_after_route: bool = False
    web_search_in_qa: bool = True
    web_admin_token: str = ""
    admin_domain: str = ""
    admin_path: str = ""

    @property
    def allowed_domains_list(self) -> list[str]:
        return [d.strip().lower() for d in self.sandbox_allowed_domains.split(",") if d.strip()]

    @property
    def blocked_domains_list(self) -> list[str]:
        return [d.strip().lower() for d in self.sandbox_blocked_domains.split(",") if d.strip()]
