from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from typing import Any

from openai import AsyncOpenAI, BadRequestError

from app.config import RuntimeSettings


class LLMConfigError(RuntimeError):
    """Raised when the OpenAI-compatible model is not configured."""


@dataclass
class LLMTestResult:
    ok: bool
    latency_ms: int
    model: str
    reply_preview: str = ""
    error: str = ""


def extract_json_object(text: str) -> dict[str, Any]:
    """Extract the first JSON object from model output, handling markdown fences."""
    raw = text.strip()
    if not raw:
        raise ValueError("Empty LLM response")

    # Strip ```json ... ``` or ``` ... ```
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        return json.loads(fenced.group(1))

    # Direct parse
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    # Fallback: scan for balanced braces
    start = raw.find("{")
    if start == -1:
        raise ValueError(f"No JSON object found in response: {raw[:200]}")

    depth = 0
    in_str = False
    escape = False
    for idx in range(start, len(raw)):
        ch = raw[idx]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = raw[start : idx + 1]
                    parsed = json.loads(candidate)
                    if isinstance(parsed, dict):
                        return parsed
                    break

    raise ValueError(f"Failed to parse JSON object from response: {raw[:200]}")


def _has_image_parts(messages: list[dict[str, Any]]) -> bool:
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, list):
            if any(part.get("type") == "image_url" for part in content if isinstance(part, dict)):
                return True
    return False


def _strip_image_parts(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    stripped: list[dict[str, Any]] = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, list):
            texts = [
                str(part.get("text", ""))
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            ]
            stripped.append({**msg, "content": "\n".join(t for t in texts if t) or "[Image attachment]"})
        else:
            stripped.append(msg)
    return stripped


class OpenAICompatibleClient:
    """Wrapper around AsyncOpenAI supporting any OpenAI-compatible API endpoint."""

    def __init__(self, timeout_seconds: float = 45.0) -> None:
        self.timeout_seconds = timeout_seconds

    def _build_client(self, settings: RuntimeSettings) -> AsyncOpenAI:
        base_url = (settings.openai_base_url or "https://api.openai.com/v1").strip().rstrip("/")
        api_key = (settings.openai_api_key or "").strip()

        is_default_openai = "api.openai.com" in base_url
        if not api_key or api_key.startswith("sk-replace"):
            if is_default_openai:
                raise LLMConfigError(
                    "Не задан OpenAI-compatible API ключ. Укажите его в /admin -> «🤖 Модель и API» или в .env."
                )
            # Local endpoints (Ollama/LM Studio/vLLM) accept dummy non-empty key
            api_key = "local-no-key"

        return AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=self.timeout_seconds,
            max_retries=2,
        )

    async def chat(
        self,
        settings: RuntimeSettings,
        messages: list[dict[str, Any]],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> str:
        client = self._build_client(settings)
        model = settings.openai_model or "gpt-4o-mini"
        try:
            try:
                resp = await client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=settings.openai_temperature if temperature is None else temperature,
                    max_tokens=settings.openai_max_tokens if max_tokens is None else max_tokens,
                )
            except BadRequestError:
                if not _has_image_parts(messages):
                    raise
                resp = await client.chat.completions.create(
                    model=model,
                    messages=_strip_image_parts(messages),
                    temperature=settings.openai_temperature if temperature is None else temperature,
                    max_tokens=settings.openai_max_tokens if max_tokens is None else max_tokens,
                )
            content = resp.choices[0].message.content or ""
            return content.strip()
        finally:
            await client.close()

    async def complete_json(
        self,
        settings: RuntimeSettings,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
        max_tokens: int = 1200,
    ) -> dict[str, Any]:
        client = self._build_client(settings)
        model = settings.openai_model or "gpt-4o-mini"
        try:
            try:
                resp = await client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    response_format={"type": "json_object"},
                )
            except BadRequestError:
                # Retry without response_format, and strip images if model lacks Vision
                try:
                    resp = await client.chat.completions.create(
                        model=model,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                    )
                except BadRequestError:
                    if not _has_image_parts(messages):
                        raise
                    resp = await client.chat.completions.create(
                        model=model,
                        messages=_strip_image_parts(messages),
                        temperature=temperature,
                        max_tokens=max_tokens,
                    )

            raw = (resp.choices[0].message.content or "").strip()
            return extract_json_object(raw)
        finally:
            await client.close()

    async def test_connection(self, settings: RuntimeSettings) -> LLMTestResult:
        t0 = time.perf_counter()
        model = settings.openai_model or "gpt-4o-mini"
        try:
            reply = await self.chat(
                settings,
                [
                    {"role": "system", "content": "Ответь кратко одним словом: OK"},
                    {"role": "user", "content": "ping"},
                ],
                temperature=0.0,
                max_tokens=24,
            )
            ms = int((time.perf_counter() - t0) * 1000)
            return LLMTestResult(
                ok=True,
                latency_ms=ms,
                model=model,
                reply_preview=reply[:80],
            )
        except Exception as exc:
            ms = int((time.perf_counter() - t0) * 1000)
            return LLMTestResult(
                ok=False,
                latency_ms=ms,
                model=model,
                error=str(exc)[:300],
            )
