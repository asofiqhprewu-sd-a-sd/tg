"""OpenAI-compatible LLM client module."""
