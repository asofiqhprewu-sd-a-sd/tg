from __future__ import annotations

import html as html_lib
import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlparse

from app.config import RuntimeSettings
from app.sandbox.net import SandboxHttpClient

YOUTUBE_HOSTS = {
    "youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "youtu.be",
    "youtube-nocookie.com",
}
VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")


@dataclass
class YouTubeInspection:
    video_id: str
    url: str
    title: str = ""
    author: str = ""
    length_seconds: int = 0
    view_count: str = ""
    description: str = ""
    transcript: str = ""
    transcript_lang: str = ""
    error: str = ""

    def to_prompt_text(self) -> str:
        parts = [
            f"YouTube-видео (ID: {self.video_id})",
            f"URL: {self.url}",
        ]
        if self.title:
            parts.append(f"Название: {self.title}")
        meta = []
        if self.author:
            meta.append(f"Канал: {self.author}")
        if self.length_seconds:
            mins, secs = divmod(self.length_seconds, 60)
            meta.append(f"Длительность: {mins}:{secs:02d}")
        if self.view_count:
            meta.append(f"Просмотры: {self.view_count}")
        if meta:
            parts.append(" | ".join(meta))
        if self.description:
            parts.append(f"\nОписание:\n{self.description[:1500]}")
        if self.transcript:
            parts.append(f"\nТранскрипт / субтитры ({self.transcript_lang or 'auto'}):\n{self.transcript[:8000]}")
        else:
            parts.append("\nТранскрипт недоступен (у видео отключены субтитры).")
        if self.error:
            parts.append(f"\nПредупреждение: {self.error}")
        return "\n".join(parts)


def extract_youtube_video_id(url: str) -> str | None:
    try:
        parsed = urlparse(url.strip())
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    if host not in YOUTUBE_HOSTS:
        return None

    segments = [s for s in parsed.path.split("/") if s]
    candidate = ""
    if host == "youtu.be":
        candidate = segments[0] if segments else ""
    else:
        qs = parse_qs(parsed.query)
        if "v" in qs and qs["v"]:
            candidate = qs["v"][0]
        elif len(segments) >= 2 and segments[0] in {"shorts", "live", "embed", "v"}:
            candidate = segments[1]

    return candidate if VIDEO_ID_RE.match(candidate) else None


def extract_player_response(page_html: str) -> dict[str, Any] | None:
    """Extract ytInitialPlayerResponse JSON object from YouTube watch HTML."""
    marker = "ytInitialPlayerResponse"
    idx = page_html.find(marker)
    if idx == -1:
        return None
    brace_start = page_html.find("{", idx)
    if brace_start == -1:
        return None

    depth = 0
    in_str = False
    escape = False
    end_limit = min(len(page_html), brace_start + 600_000)
    for pos in range(brace_start, end_limit):
        ch = page_html[pos]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(page_html[brace_start : pos + 1])
                        return obj if isinstance(obj, dict) else None
                    except json.JSONDecodeError:
                        return None
    return None


def parse_caption_xml(raw_xml: str, *, max_chars: int = 8500) -> str:
    """Parse YouTube timedtext XML (<text> or <p>/<s>) into clean continuous text."""
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return ""

    chunks: list[str] = []
    for elem in root.iter():
        if elem.tag in {"text", "p"}:
            txt = "".join(elem.itertext()).strip()
            txt = html_lib.unescape(txt).replace("\n", " ")
            txt = " ".join(txt.split())
            if txt:
                chunks.append(txt)
    joined = " ".join(chunks)
    return joined[:max_chars]


class YouTubeInspector:
    """Extracts YouTube video metadata and captions/transcript via sandboxed HTTP."""

    def __init__(self, http_client: SandboxHttpClient) -> None:
        self.http = http_client

    async def inspect(self, url: str, settings: RuntimeSettings) -> YouTubeInspection | None:
        video_id = extract_youtube_video_id(url)
        if not video_id:
            return None

        watch_url = f"https://www.youtube.com/watch?v={video_id}"
        info = YouTubeInspection(video_id=video_id, url=url)

        try:
            _, status, _, raw = await self.http.fetch_raw(
                watch_url,
                settings,
                headers={"Accept-Language": "ru,en;q=0.9"},
                max_bytes=3 * 1024 * 1024,
            )
            if status >= 400:
                info.error = f"YouTube вернул статус {status}"
                return info
            html_str = raw.decode("utf-8", errors="replace")
        except Exception as exc:
            info.error = str(exc)
            return info

        player = extract_player_response(html_str)
        if not player:
            # Fallback to regular HTML parsing
            page = await self.http.fetch_webpage(watch_url, settings, max_text_chars=3000)
            info.title = page.title
            info.description = page.description
            return info

        details = player.get("videoDetails") or {}
        info.title = str(details.get("title") or "")
        info.author = str(details.get("author") or "")
        info.description = str(details.get("shortDescription") or "")
        info.view_count = str(details.get("viewCount") or "")
        try:
            info.length_seconds = int(details.get("lengthSeconds") or 0)
        except (TypeError, ValueError):
            info.length_seconds = 0

        tracks = (
            player.get("captions", {})
            .get("playerCaptionsTracklistRenderer", {})
            .get("captionTracks", [])
        )
        if isinstance(tracks, list) and tracks:
            chosen = self._pick_track(tracks)
            base_url = str(chosen.get("baseUrl") or "")
            info.transcript_lang = str(chosen.get("languageCode") or "")
            if base_url:
                try:
                    _, c_status, _, c_raw = await self.http.fetch_raw(
                        base_url,
                        settings,
                        max_bytes=1024 * 1024,
                    )
                    if c_status == 200 and c_raw:
                        info.transcript = parse_caption_xml(c_raw.decode("utf-8", errors="replace"))
                except Exception:
                    pass

        return info

    @staticmethod
    def _pick_track(tracks: list[dict[str, Any]]) -> dict[str, Any]:
        # Prefer Russian manual, Russian auto, English manual, English auto, then first
        def score(tr: dict[str, Any]) -> tuple[int, int]:
            lang = str(tr.get("languageCode") or "").lower()
            is_asr = 1 if tr.get("kind") == "asr" else 0
            if lang.startswith("ru"):
                return (0, is_asr)
            if lang.startswith("en"):
                return (1, is_asr)
            return (2, is_asr)

        return min(tracks, key=score)
