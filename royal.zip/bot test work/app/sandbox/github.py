from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from urllib.parse import quote, urlparse

from app.config import RuntimeSettings
from app.sandbox.net import SandboxHttpClient

GITHUB_SKIP_OWNER_PATHS = {
    "settings",
    "explore",
    "topics",
    "trending",
    "collections",
    "events",
    "sponsors",
    "notifications",
    "login",
    "signup",
    "search",
    "marketplace",
    "orgs",
    "features",
    "enterprise",
    "pricing",
}

MANIFEST_FILENAMES = {
    "pyproject.toml",
    "requirements.txt",
    "package.json",
    "cargo.toml",
    "go.mod",
    "composer.json",
    "pom.xml",
    "dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
}


@dataclass
class RepoInspection:
    provider: str  # "github" | "gitlab"
    full_name: str
    url: str
    description: str = ""
    stars: int = 0
    forks: int = 0
    language: str = ""
    topics: list[str] = field(default_factory=list)
    license_name: str = ""
    default_branch: str = "main"
    top_files: list[str] = field(default_factory=list)
    readme_text: str = ""
    manifests_summary: str = ""
    error: str = ""

    def to_prompt_text(self) -> str:
        parts = [
            f"Репозиторий ({self.provider}): {self.full_name}",
            f"URL: {self.url}",
        ]
        if self.description:
            parts.append(f"Описание: {self.description}")
        meta = []
        if self.language:
            meta.append(f"Язык: {self.language}")
        if self.stars:
            meta.append(f"Звёзды: {self.stars}")
        if self.forks:
            meta.append(f"Форки: {self.forks}")
        if self.license_name:
            meta.append(f"Лицензия: {self.license_name}")
        if meta:
            parts.append(" | ".join(meta))
        if self.topics:
            parts.append(f"Темы/теги: {', '.join(self.topics[:12])}")
        if self.top_files:
            parts.append(f"Корневые файлы: {', '.join(self.top_files[:30])}")
        if self.manifests_summary:
            parts.append(f"\nКлючевые манифесты:\n{self.manifests_summary}")
        if self.readme_text:
            parts.append(f"\nREADME:\n{self.readme_text[:7000]}")
        if self.error:
            parts.append(f"\nПредупреждение при инспекции: {self.error}")
        return "\n".join(parts)


def parse_repo_url(url: str) -> tuple[str, str] | None:
    """Return ('github'|'gitlab', 'owner/repo') if URL points to a repository."""
    try:
        parsed = urlparse(url.strip())
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]

    segments = [seg for seg in parsed.path.strip("/").split("/") if seg]
    if host == "github.com":
        if len(segments) < 2:
            return None
        owner, repo = segments[0], segments[1]
        if owner.lower() in GITHUB_SKIP_OWNER_PATHS:
            return None
        if len(segments) >= 3 and segments[2] in {"issues", "pull", "pulls", "releases", "wiki", "actions"}:
            # Still useful to inspect parent repo if needed, or treat differently;
            # keep repo inspection for base repo URL or tree/blob URLs, skip issue threads
            return None
        repo = repo[:-4] if repo.endswith(".git") else repo
        return ("github", f"{owner}/{repo}")

    if host == "gitlab.com":
        if len(segments) < 2:
            return None
        # GitLab supports nested groups before /-/, e.g. group/sub/repo/-/tree/main
        if "-" in segments:
            idx = segments.index("-")
            repo_parts = segments[:idx]
            if len(segments) > idx + 1 and segments[idx + 1] in {"issues", "merge_requests"}:
                return None
        else:
            repo_parts = segments[:2]
        if len(repo_parts) < 2:
            return None
        repo_parts[-1] = repo_parts[-1][:-4] if repo_parts[-1].endswith(".git") else repo_parts[-1]
        return ("gitlab", "/".join(repo_parts))

    return None


class RepoInspector:
    """Inspects GitHub / GitLab repositories over sandboxed HTTP."""

    def __init__(self, http_client: SandboxHttpClient, github_token: str = "") -> None:
        self.http = http_client
        self.github_token = github_token.strip()

    async def inspect(self, url: str, settings: RuntimeSettings) -> RepoInspection | None:
        parsed = parse_repo_url(url)
        if parsed is None:
            return None
        provider, full_name = parsed
        if provider == "github":
            return await self._inspect_github(full_name, url, settings)
        return await self._inspect_gitlab(full_name, url, settings)

    def _github_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/vnd.github+json"}
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"
        return headers

    async def _inspect_github(
        self,
        full_name: str,
        original_url: str,
        settings: RuntimeSettings,
    ) -> RepoInspection:
        api_base = f"https://api.github.com/repos/{full_name}"
        headers = self._github_headers()

        info = RepoInspection(provider="github", full_name=full_name, url=original_url)
        try:
            _, status, _, raw = await self.http.fetch_raw(api_base, settings, headers=headers, max_bytes=1024 * 1024)
            if status == 200:
                data = json.loads(raw.decode("utf-8", errors="replace"))
                info.description = data.get("description") or ""
                info.stars = int(data.get("stargazers_count") or 0)
                info.forks = int(data.get("forks_count") or 0)
                info.language = data.get("language") or ""
                info.topics = [str(t) for t in (data.get("topics") or [])]
                lic = data.get("license") or {}
                info.license_name = lic.get("spdx_id") or lic.get("name") or ""
                info.default_branch = data.get("default_branch") or "main"
            else:
                info.error = f"GitHub API вернул статус {status}"
        except Exception as exc:
            info.error = f"GitHub API ошибка: {exc}"

        # Fetch README via API or raw fallback
        try:
            _, status, _, raw = await self.http.fetch_raw(
                f"{api_base}/readme", settings, headers=headers, max_bytes=1024 * 1024
            )
            if status == 200:
                readme_json = json.loads(raw.decode("utf-8", errors="replace"))
                if readme_json.get("encoding") == "base64" and readme_json.get("content"):
                    info.readme_text = base64.b64decode(readme_json["content"]).decode("utf-8", errors="replace")
        except Exception:
            pass

        if not info.readme_text:
            for branch in dict.fromkeys([info.default_branch, "main", "master"]):
                try:
                    raw_url = f"https://raw.githubusercontent.com/{full_name}/{branch}/README.md"
                    _, status, _, raw = await self.http.fetch_raw(raw_url, settings, max_bytes=512 * 1024)
                    if status == 200 and raw:
                        info.readme_text = raw.decode("utf-8", errors="replace")
                        break
                except Exception:
                    continue

        # Fetch root directory listing & key manifests
        try:
            _, status, _, raw = await self.http.fetch_raw(
                f"{api_base}/contents", settings, headers=headers, max_bytes=1024 * 1024
            )
            if status == 200:
                entries = json.loads(raw.decode("utf-8", errors="replace"))
                if isinstance(entries, list):
                    info.top_files = [
                        f"{e['name']}/" if e.get("type") == "dir" else str(e.get("name", ""))
                        for e in entries[:40]
                    ]
                    manifest_snippets: list[str] = []
                    for e in entries:
                        name = str(e.get("name", ""))
                        if name.lower() in MANIFEST_FILENAMES and e.get("download_url"):
                            try:
                                _, m_status, _, m_raw = await self.http.fetch_raw(
                                    str(e["download_url"]), settings, max_bytes=64 * 1024
                                )
                                if m_status == 200:
                                    txt = m_raw.decode("utf-8", errors="replace")[:1500]
                                    manifest_snippets.append(f"--- {name} ---\n{txt}")
                            except Exception:
                                pass
                            if len(manifest_snippets) >= 2:
                                break
                    info.manifests_summary = "\n\n".join(manifest_snippets)
        except Exception:
            pass

        # Fallback to HTML page if API was rate-limited and README failed
        if not info.description and not info.readme_text:
            page = await self.http.fetch_webpage(original_url, settings, max_text_chars=5000)
            if not page.error:
                info.description = info.description or page.description
                info.readme_text = page.text

        return info

    async def _inspect_gitlab(
        self,
        full_name: str,
        original_url: str,
        settings: RuntimeSettings,
    ) -> RepoInspection:
        encoded = quote(full_name, safe="")
        api_url = f"https://gitlab.com/api/v4/projects/{encoded}"
        info = RepoInspection(provider="gitlab", full_name=full_name, url=original_url)
        try:
            _, status, _, raw = await self.http.fetch_raw(api_url, settings, max_bytes=1024 * 1024)
            if status == 200:
                data = json.loads(raw.decode("utf-8", errors="replace"))
                info.description = data.get("description") or ""
                info.stars = int(data.get("star_count") or 0)
                info.forks = int(data.get("forks_count") or 0)
                info.topics = [str(t) for t in (data.get("topics") or [])]
                info.default_branch = data.get("default_branch") or "main"
        except Exception as exc:
            info.error = f"GitLab API ошибка: {exc}"

        try:
            raw_readme = f"https://gitlab.com/{full_name}/-/raw/{info.default_branch}/README.md"
            _, status, _, raw = await self.http.fetch_raw(raw_readme, settings, max_bytes=512 * 1024)
            if status == 200:
                info.readme_text = raw.decode("utf-8", errors="replace")
        except Exception:
            pass

        if not info.description and not info.readme_text:
            page = await self.http.fetch_webpage(original_url, settings, max_text_chars=5000)
            if not page.error:
                info.description = page.description
                info.readme_text = page.text
        return info
