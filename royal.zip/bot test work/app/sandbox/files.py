from __future__ import annotations

import hashlib
import io
import shutil
import uuid
import xml.etree.ElementTree as ET
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from bs4 import BeautifulSoup
from pypdf import PdfReader

from app.sandbox.net import _decode_bytes

TEXT_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".rst",
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".go",
    ".rs",
    ".java",
    ".kt",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".cs",
    ".php",
    ".rb",
    ".swift",
    ".sql",
    ".sh",
    ".bash",
    ".ps1",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".env",
    ".csv",
    ".tsv",
    ".xml",
    ".log",
    ".css",
    ".scss",
}

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_ZIP_EXTRACT_BYTES = 20 * 1024 * 1024


@dataclass
class InspectedFile:
    filename: str
    size_bytes: int
    sha256: str
    kind: str  # "text" | "pdf" | "docx" | "zip" | "html" | "image" | "binary"
    extracted_text: str
    error: str = ""


class FileSandbox:
    """Isolated per-task temporary filesystem sandbox for inspecting uploaded files."""

    def __init__(self, work_dir: Path, max_file_bytes: int = 15 * 1024 * 1024) -> None:
        self.work_dir = work_dir
        self.max_file_bytes = max_file_bytes

    @contextmanager
    def task_dir(self) -> Iterator[Path]:
        self.work_dir.mkdir(parents=True, exist_ok=True)
        task_path = (self.work_dir / uuid.uuid4().hex).resolve()
        task_path.mkdir(parents=True, exist_ok=True)
        try:
            yield task_path
        finally:
            shutil.rmtree(task_path, ignore_errors=True)

    @staticmethod
    def safe_filename(name: str) -> str:
        cleaned = Path(name or "file.bin").name.strip()
        return cleaned or "file.bin"

    def inspect_bytes(self, filename: str, data: bytes) -> InspectedFile:
        safe_name = self.safe_filename(filename)
        digest = hashlib.sha256(data).hexdigest()
        size = len(data)
        if size > self.max_file_bytes:
            return InspectedFile(
                filename=safe_name,
                size_bytes=size,
                sha256=digest,
                kind="binary",
                extracted_text="",
                error=f"Файл слишком большой ({size // (1024 * 1024)} МБ > лимит песочницы).",
            )

        with self.task_dir() as sandbox_dir:
            target_path = (sandbox_dir / safe_name).resolve()
            if target_path.parent != sandbox_dir:
                return InspectedFile(
                    filename=safe_name,
                    size_bytes=size,
                    sha256=digest,
                    kind="binary",
                    extracted_text="",
                    error="Обнаружен небезопасный путь файла.",
                )
            target_path.write_bytes(data)
            return self._inspect_path(target_path, safe_name, size, digest, sandbox_dir)

    def _inspect_path(
        self,
        file_path: Path,
        safe_name: str,
        size: int,
        digest: str,
        sandbox_dir: Path,
    ) -> InspectedFile:
        ext = file_path.suffix.lower()

        if ext == ".pdf":
            return self._read_pdf(file_path, safe_name, size, digest)
        if ext == ".docx":
            return self._read_docx(file_path, safe_name, size, digest)
        if ext == ".zip":
            return self._read_zip(file_path, safe_name, size, digest, sandbox_dir)
        if ext in {".html", ".htm"}:
            soup = BeautifulSoup(_decode_bytes(file_path.read_bytes()), "html.parser")
            for noisy in soup(["script", "style", "noscript"]):
                noisy.decompose()
            text = "\n".join(line.strip() for line in soup.get_text("\n").splitlines() if line.strip())
            return InspectedFile(
                filename=safe_name,
                size_bytes=size,
                sha256=digest,
                kind="html",
                extracted_text=text[:12000],
            )
        if ext in IMAGE_EXTENSIONS:
            return InspectedFile(
                filename=safe_name,
                size_bytes=size,
                sha256=digest,
                kind="image",
                extracted_text=f"Изображение {safe_name} ({size} байт).",
            )
        if ext in TEXT_EXTENSIONS or file_path.name.lower() in {"dockerfile", "makefile", "readme"}:
            text = _decode_bytes(file_path.read_bytes())
            return InspectedFile(
                filename=safe_name,
                size_bytes=size,
                sha256=digest,
                kind="text",
                extracted_text=text[:12000],
            )

        # Heuristic UTF-8 check for extensionless text files
        raw = file_path.read_bytes()
        if b"\x00" not in raw[:4096]:
            text = _decode_bytes(raw)
            return InspectedFile(
                filename=safe_name,
                size_bytes=size,
                sha256=digest,
                kind="text",
                extracted_text=text[:12000],
            )

        return InspectedFile(
            filename=safe_name,
            size_bytes=size,
            sha256=digest,
            kind="binary",
            extracted_text=f"Бинарный файл {safe_name} ({size} байт, расширение {ext or 'нет'}).",
        )

    def _read_pdf(self, file_path: Path, name: str, size: int, digest: str) -> InspectedFile:
        try:
            reader = PdfReader(str(file_path))
            chunks: list[str] = []
            total = 0
            for idx, page in enumerate(reader.pages[:25]):
                txt = (page.extract_text() or "").strip()
                if txt:
                    chunks.append(f"[Стр. {idx + 1}]\n{txt}")
                    total += len(txt)
                if total >= 12000:
                    break
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="pdf",
                extracted_text="\n\n".join(chunks)[:12000] or f"PDF-документ ({len(reader.pages)} стр., без текстового слоя).",
            )
        except Exception as exc:
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="pdf",
                extracted_text="",
                error=f"Ошибка чтения PDF: {exc}",
            )

    def _read_docx(self, file_path: Path, name: str, size: int, digest: str) -> InspectedFile:
        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                if "word/document.xml" not in zf.namelist():
                    return InspectedFile(
                        filename=name,
                        size_bytes=size,
                        sha256=digest,
                        kind="docx",
                        extracted_text="DOCX-файл без word/document.xml.",
                    )
                xml_bytes = zf.read("word/document.xml")
            root = ET.fromstring(xml_bytes)
            paragraphs: list[str] = []
            for p in root.iter():
                if p.tag.endswith("}p"):
                    texts = [t.text for t in p.iter() if t.tag.endswith("}t") and t.text]
                    if texts:
                        paragraphs.append("".join(texts))
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="docx",
                extracted_text="\n".join(paragraphs)[:12000],
            )
        except Exception as exc:
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="docx",
                extracted_text="",
                error=f"Ошибка чтения DOCX: {exc}",
            )

    def _read_zip(
        self,
        file_path: Path,
        name: str,
        size: int,
        digest: str,
        sandbox_dir: Path,
    ) -> InspectedFile:
        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                infos = zf.infolist()
                total_uncompressed = sum(i.file_size for i in infos)
                if total_uncompressed > MAX_ZIP_EXTRACT_BYTES:
                    return InspectedFile(
                        filename=name,
                        size_bytes=size,
                        sha256=digest,
                        kind="zip",
                        extracted_text="",
                        error="Архив превышает безопасный лимит распаковки песочницы (20 МБ).",
                    )

                extract_root = (sandbox_dir / "extracted").resolve()
                extract_root.mkdir(parents=True, exist_ok=True)
                file_names: list[str] = []
                priority_texts: list[str] = []

                for info in infos[:300]:
                    if info.is_dir():
                        continue
                    rel = Path(info.filename)
                    dest = (extract_root / rel).resolve()
                    # ZipSlip protection
                    if extract_root not in dest.parents and dest != extract_root:
                        return InspectedFile(
                            filename=name,
                            size_bytes=size,
                            sha256=digest,
                            kind="zip",
                            extracted_text="",
                            error=f"Заблокирован ZipSlip путь в архиве: {info.filename}",
                        )
                    file_names.append(info.filename)

                    low = rel.name.lower()
                    if (
                        low.startswith("readme")
                        or low in {"pyproject.toml", "package.json", "requirements.txt", "go.mod", "cargo.toml"}
                        or rel.suffix.lower() in {".md", ".py", ".ts", ".js", ".go", ".json"}
                    ) and info.file_size <= 256 * 1024 and len(priority_texts) < 5:
                        content = _decode_bytes(zf.read(info.filename))[:2000]
                        priority_texts.append(f"--- {info.filename} ---\n{content}")

            parts = [
                f"ZIP-архив {name}, файлов: {len(file_names)}",
                "Содержимое:\n" + "\n".join(f"- {fn}" for fn in file_names[:60]),
            ]
            if priority_texts:
                parts.append("Фрагменты ключевых файлов:\n" + "\n\n".join(priority_texts))
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="zip",
                extracted_text="\n\n".join(parts)[:12000],
            )
        except Exception as exc:
            return InspectedFile(
                filename=name,
                size_bytes=size,
                sha256=digest,
                kind="zip",
                extracted_text="",
                error=f"Ошибка чтения ZIP: {exc}",
            )
