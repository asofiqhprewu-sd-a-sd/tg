from __future__ import annotations

import asyncio
import ipaddress
import json
import re
import socket
import sys
import urllib.request
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

import aiohttp
from bs4 import BeautifulSoup

from app.config import RuntimeSettings

USER_AGENT = (
    "Mozilla/5.0 (compatible; GroupTopicAssistantBot/1.0; +https://core.telegram.org/bots)"
)
URL_REGEX = re.compile(r"https?://[^\s<>\"'`]+", re.IGNORECASE)
TRACKING_PARAMS = {
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "fbclid",
    "gclid",
    "yclid",
    "mc_cid",
    "mc_eid",
    "si",
    "feature",
}


class SandboxAccessError(RuntimeError):
    """Raised when sandbox policy or SSRF protection blocks a network request."""


@dataclass
class FetchedWebPage:
    url: str
    final_url: str
    status: int
    content_type: str
    title: str = ""
    description: str = ""
    text: str = ""
    raw_bytes: bytes = b""
    error: str = ""


@dataclass
class WebSearchHit:
    title: str
    url: str
    snippet: str


def extract_urls(text: str) -> list[str]:
    if not text:
        return []
    found: list[str] = []
    seen: set[str] = set()
    for match in URL_REGEX.findall(text):
        cleaned = match.rstrip(").,;!?]}>\"'")
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            found.append(cleaned)
    return found


def normalize_url(url: str) -> str:
    try:
        parsed = urlparse(url.strip())
    except ValueError:
        return url.strip()
    if parsed.scheme not in {"http", "https"}:
        return url.strip()

    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]

    # Canonicalize YouTube URLs for deduplication (youtu.be, m.youtube.com, shorts, live)
    if host in {"youtu.be", "youtube.com", "m.youtube.com", "music.youtube.com"}:
        segs = [s for s in parsed.path.split("/") if s]
        vid = ""
        if host == "youtu.be" and segs:
            vid = segs[0]
        else:
            qs_dict = dict(parse_qsl(parsed.query))
            if "v" in qs_dict:
                vid = qs_dict["v"]
            elif len(segs) >= 2 and segs[0] in {"shorts", "live", "embed", "v"}:
                vid = segs[1]
        if re.match(r"^[A-Za-z0-9_-]{11}$", vid):
            return f"https://youtube.com/watch?v={vid}"

    port = parsed.port
    netloc = host if (port is None or port in (80, 443)) else f"{host}:{port}"

    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    filtered_qs = [
        (k, v)
        for k, v in parse_qsl(parsed.query, keep_blank_values=False)
        if k.lower() not in TRACKING_PARAMS
    ]
    query = urlencode(filtered_qs)
    return urlunparse((parsed.scheme.lower(), netloc, path, "", query, ""))


def is_public_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str.split("%")[0])
    except ValueError:
        return False
    return not (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )


def _domain_matches(host: str, pattern: str) -> bool:
    host = host.lower().rstrip(".")
    pattern = pattern.lower().strip().lstrip(".")
    if not pattern:
        return False
    return host == pattern or host.endswith(f".{pattern}")


async def validate_url_target(url: str, settings: RuntimeSettings) -> None:
    """Validate URL scheme, domain allow/block lists, and public IP resolution (SSRF guard)."""
    if not settings.sandbox_internet_enabled:
        raise SandboxAccessError("Выход в интернет из песочницы отключён администратором.")

    parsed = urlparse(url)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise SandboxAccessError(f"Запрещённая схема URL: {parsed.scheme}")

    host = (parsed.hostname or "").lower()
    if not host:
        raise SandboxAccessError("Некорректный URL без хоста.")

    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise SandboxAccessError(f"Доступ к локальному хосту {host} запрещён песочницей.")

    for blocked in settings.blocked_domains_list:
        if _domain_matches(host, blocked):
            raise SandboxAccessError(f"Домен {host} заблокирован политикой песочницы.")

    allowed = settings.allowed_domains_list
    if allowed and not any(_domain_matches(host, pat) for pat in allowed):
        raise SandboxAccessError(f"Домен {host} не входит в белый список песочницы.")

    # If proxy is explicitly configured for sandbox egress, DNS happens at proxy;
    # still block literal private IP hosts directly.
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        if not is_public_ip(host):
            raise SandboxAccessError(f"Доступ к приватному/локальному IP {host} запрещён песочницей.")
        return

    if settings.sandbox_proxy_url:
        return

    loop = asyncio.get_running_loop()
    try:
        addr_info = await loop.getaddrinfo(
            host,
            parsed.port or (443 if parsed.scheme == "https" else 80),
            type=socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        raise SandboxAccessError(f"Не удалось разрешить DNS для {host}: {exc}") from exc

    ips = {item[4][0] for item in addr_info if item[4]}
    if not ips:
        raise SandboxAccessError(f"DNS не вернул IP-адресов для {host}.")
    for ip_str in ips:
        if not is_public_ip(ip_str):
            raise SandboxAccessError(
                f"Песочница заблокировала {host} (резолвится в приватный/служебный IP {ip_str})."
            )


def get_windows_system_proxy() -> str:
    """Return active Windows registry HTTP/HTTPS proxy (e.g. from VPN client), if enabled."""
    if sys.platform != "win32":
        return ""
    try:
        reg = urllib.request.getproxies_registry()
        return (reg.get("https") or reg.get("http") or "").strip()
    except Exception:
        return ""


class SandboxHttpClient:
    """SSRF-safe HTTP client for controlled sandbox internet access."""

    def __init__(
        self,
        *,
        timeout_seconds: int = 20,
        max_download_bytes: int = 15 * 1024 * 1024,
        max_redirects: int = 5,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.max_download_bytes = max_download_bytes
        self.max_redirects = max_redirects

    async def fetch_raw(
        self,
        url: str,
        settings: RuntimeSettings,
        *,
        headers: dict[str, str] | None = None,
        max_bytes: int | None = None,
    ) -> tuple[str, int, dict[str, str], bytes]:
        current_url = url
        byte_limit = max_bytes if max_bytes is not None else self.max_download_bytes
        req_headers = {"User-Agent": USER_AGENT, "Accept-Language": "ru,en;q=0.9"}
        if headers:
            req_headers.update(headers)

        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        proxy = settings.sandbox_proxy_url.strip() or get_windows_system_proxy() or None

        async with aiohttp.ClientSession(timeout=timeout) as session:
            for _ in range(self.max_redirects + 1):
                await validate_url_target(current_url, settings)
                async with session.get(
                    current_url,
                    headers=req_headers,
                    allow_redirects=False,
                    proxy=proxy,
                ) as resp:
                    if resp.status in {301, 302, 303, 307, 308}:
                        location = resp.headers.get("Location")
                        if not location:
                            break
                        current_url = urljoin(current_url, location)
                        continue

                    chunks: list[bytes] = []
                    total = 0
                    async for chunk in resp.content.iter_chunked(65536):
                        total += len(chunk)
                        if total > byte_limit:
                            chunks.append(chunk[: max(0, byte_limit - (total - len(chunk)))])
                            break
                        chunks.append(chunk)

                    resp_headers = {k.lower(): v for k, v in resp.headers.items()}
                    return str(resp.url), resp.status, resp_headers, b"".join(chunks)

        raise SandboxAccessError("Слишком много перенаправлений при загрузке URL.")

    async def fetch_webpage(
        self,
        url: str,
        settings: RuntimeSettings,
        *,
        max_text_chars: int = 10000,
    ) -> FetchedWebPage:
        try:
            final_url, status, headers, raw = await self.fetch_raw(
                url,
                settings,
                max_bytes=min(self.max_download_bytes, 4 * 1024 * 1024),
            )
        except Exception as exc:
            return FetchedWebPage(
                url=url,
                final_url=url,
                status=0,
                content_type="",
                error=str(exc),
            )

        content_type = headers.get("content-type", "").lower()
        if status >= 400:
            return FetchedWebPage(
                url=url,
                final_url=final_url,
                status=status,
                content_type=content_type,
                error=f"HTTP {status}",
            )

        if "application/json" in content_type or final_url.lower().endswith(".json"):
            text = _decode_bytes(raw)
            try:
                formatted = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
            except Exception:
                formatted = text
            return FetchedWebPage(
                url=url,
                final_url=final_url,
                status=status,
                content_type=content_type,
                title=urlparse(final_url).path.rsplit("/", 1)[-1] or final_url,
                text=formatted[:max_text_chars],
                raw_bytes=raw,
            )

        if (
            "text/plain" in content_type
            or "text/markdown" in content_type
            or final_url.lower().endswith((".md", ".txt", ".yaml", ".yml", ".toml", ".py"))
        ):
            text = _decode_bytes(raw)
            return FetchedWebPage(
                url=url,
                final_url=final_url,
                status=status,
                content_type=content_type,
                title=urlparse(final_url).path.rsplit("/", 1)[-1] or final_url,
                text=text[:max_text_chars],
                raw_bytes=raw,
            )

        if "html" in content_type or not content_type or b"<html" in raw[:1024].lower():
            html = _decode_bytes(raw)
            title, desc, body_text = parse_html_content(html, max_chars=max_text_chars)
            return FetchedWebPage(
                url=url,
                final_url=final_url,
                status=status,
                content_type=content_type,
                title=title,
                description=desc,
                text=body_text,
                raw_bytes=raw,
            )

        return FetchedWebPage(
            url=url,
            final_url=final_url,
            status=status,
            content_type=content_type,
            title=urlparse(final_url).path.rsplit("/", 1)[-1] or final_url,
            text=f"[Бинарный ресурс: {content_type}, размер ~{len(raw)} байт]",
            raw_bytes=raw,
        )

    async def search_web(
        self,
        query: str,
        settings: RuntimeSettings,
        *,
        limit: int = 5,
    ) -> list[WebSearchHit]:
        """Search public web via DuckDuckGo HTML endpoint from the sandbox."""
        search_url = f"https://html.duckduckgo.com/html/?{urlencode({'q': query})}"
        _, status, _, raw = await self.fetch_raw(
            search_url,
            settings,
            headers={"Accept": "text/html"},
            max_bytes=1024 * 1024,
        )
        if status >= 400:
            return []

        soup = BeautifulSoup(_decode_bytes(raw), "html.parser")
        hits: list[WebSearchHit] = []
        for res in soup.select(".result"):
            a_tag = res.select_one("a.result__a")
            if not a_tag:
                continue
            title = " ".join(a_tag.get_text(" ", strip=True).split())
            href = a_tag.get("href", "").strip()
            if "uddg=" in href:
                parsed = urlparse(href)
                qs = dict(parse_qsl(parsed.query))
                href = qs.get("uddg", href)
            snip_el = res.select_one(".result__snippet")
            snippet = " ".join(snip_el.get_text(" ", strip=True).split()) if snip_el else ""
            if title and href.startswith(("http://", "https://")):
                hits.append(WebSearchHit(title=title, url=href, snippet=snippet))
                if len(hits) >= limit:
                    break
        return hits


def parse_html_content(html: str, *, max_chars: int = 10000) -> tuple[str, str, str]:
    soup = BeautifulSoup(html, "html.parser")

    title = ""
    og_title = soup.find("meta", attrs={"property": "og:title"})
    if og_title and og_title.get("content"):
        title = str(og_title["content"]).strip()
    elif soup.title and soup.title.string:
        title = soup.title.string.strip()

    description = ""
    for attrs in (
        {"name": "description"},
        {"property": "og:description"},
        {"name": "twitter:description"},
    ):
        tag = soup.find("meta", attrs=attrs)
        if tag and tag.get("content"):
            description = str(tag["content"]).strip()
            if description:
                break

    for noisy in soup(["script", "style", "noscript", "svg", "iframe"]):
        noisy.decompose()

    # Prefer semantic main/article container when substantial
    container: Any = soup.find("article") or soup.find("main") or soup.body or soup
    raw_text = container.get_text("\n", strip=True)
    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
    cleaned = "\n".join(lines)
    if len(cleaned) < 120 and soup.body and container is not soup.body:
        raw_text = soup.body.get_text("\n", strip=True)
        lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
        cleaned = "\n".join(lines)

    return title[:300], description[:600], cleaned[:max_chars]


def _decode_bytes(raw: bytes) -> str:
    for enc in ("utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")
