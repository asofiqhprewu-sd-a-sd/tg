"""Sandboxed internet egress and file/repo inspection modules."""
