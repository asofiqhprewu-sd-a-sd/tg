from __future__ import annotations

import asyncio
import socket
import sys
import webbrowser

from app.config import StaticConfig
from app.db import Database


def _is_port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=1.0):
            return True
    except OSError:
        return False


async def generate() -> str:
    cfg = StaticConfig.from_env()
    db = Database(cfg.db_path)
    await db.connect(cfg)
    try:
        domain, path, token = await db.rotate_admin_site_access()
        url = f"http://{domain}:{cfg.web_admin_port}{path}/?token={token}"
        return url
    finally:
        await db.close()


def main() -> None:
    cfg = StaticConfig.from_env()
    url = asyncio.run(generate())
    print("=" * 64)
    print("НОВЫЙ ДОМЕН И ССЫЛКА ДЛЯ ВЫДАЧИ АДМИНКИ:")
    print(url)
    print("=" * 64)
    if not _is_port_open(cfg.web_admin_host, cfg.web_admin_port):
        print(
            f"[!] Порт {cfg.web_admin_port} сейчас не слушается — запустите бота (start.bat или python run.py), "
            "после чего ссылка откроется."
        )
    elif "--no-open" not in sys.argv:
        webbrowser.open(url)


if __name__ == "__main__":
    main()
