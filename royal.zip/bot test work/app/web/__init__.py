"""Lightweight aiohttp Web Admin Dashboard."""
